package com.truper.saen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class SaeNacionalesGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaeNacionalesGatewayApplication.class, args);
	}

}
