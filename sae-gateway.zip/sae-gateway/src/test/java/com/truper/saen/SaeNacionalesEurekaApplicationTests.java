package com.truper.saen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaeNacionalesGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
