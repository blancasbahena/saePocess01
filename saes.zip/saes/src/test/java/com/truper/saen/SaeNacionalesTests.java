package com.truper.saen;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.tomcat.util.digester.ArrayStack;
import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.feign.UserFeignClient;
import com.truper.saen.service.SaeApprovalServices;
import com.truper.saen.service.impl.EmailsServiceImpl;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@SpringBootTest
class SaeNacionalesTests {
	private SaeDao saeRepository;
	private SaeApprovalServices saeServices; 
	private UserFeignClient userFeignClient;
	@Autowired
	private EmailsServiceImpl service;
	private JWUtil jwutil; 
	private Optional<Sae> saeO;
	private User user;
	@BeforeEach
	void setUp() {
		saeServices =  mock(SaeApprovalServices.class);
		userFeignClient = mock(UserFeignClient.class); 
		jwutil = mock(JWUtil.class);
		saeRepository= mock(SaeDao.class);
		Sae sae= new Sae();
		sae.setFolio(100000l);
		CatSaeStatus estatus = new CatSaeStatus();
		estatus.setEstatus("created");
		estatus.setIdSaeStatus(1);
		sae.setStatus(estatus);
		sae.setEta(new Date());
		sae.setEtaSolicitada(new Date());
		user= new User();
		user.setId(10000l);
		user.setActive(true);
		user.setCreated(new Date());
		user.setEmail("lablancasb@truper.com");
		user.setModified(new Date());
		user.setName("Usuario de prueba");
		user.setPassword("$2a$10$UrNoIrD1DOH468CHOsdzWeTlcV4PZGvAZWsKiWQ.qgr4nWbizCHGi");
		user.setUserAD(false);
		user.setUserAPP(true);
		user.setUserName("junit05");
		sae.setUserModified(user);
		sae.setUnidades(20);
		sae.setIdProveedor(9999999);
		sae.setNombreProveedor("Proveedor Test Examaple");
		sae.setUserApproval(user);
		sae.setUserApprovalGte(user);
		sae.setUserApprovalLibera(user);
		sae.setUserApprovalOver(user);
		sae.setUserReject(user);
		sae.setUserRejectGte(user);
		sae.setUserRejectLibera(user);
		sae.setUserRejectOver(user);
		sae.setMsgReject("Test MSG Reject");
		sae.setMsgRejectGte("Test MSG Reject");
		sae.setMsgRejectLibera("Test MSG Reject");
		sae.setMsgRejectGte("Test MSG Reject");
		sae.setMsgRejectOver("Test MSG Reject");  
		
		saeO= Optional.of(sae);

	}
	@Test
	void contextLoads() {
		boolean enviarTest=false;
		when(saeRepository.findById(1l)).thenReturn(saeO);
		List<Integer> estatusDeRechazo=new ArrayList<Integer>();
		estatusDeRechazo.add(CatStatusSae.SAE_RECHAZA_PLANEACION.getId());
		estatusDeRechazo.add(CatStatusSae.SAE_RECHAZA_GTE_PLANEACION.getId());
		estatusDeRechazo.add(CatStatusSae.SAE_RECHAZA_OVER_STOCK_STATUS25.getId());
		estatusDeRechazo.add(CatStatusSae.SAE_RECHAZADO_LIBERACION.getId());
		estatusDeRechazo.stream().forEach(status ->{
		log.info("Proceso de prueba para el envio de correo");
		service.envioCorreoValidar(
				saeO.get().getFolio(), 
				saeO.get().getIdProveedor(),
				saeO.get().getNombreProveedor().toUpperCase(),
				saeO.get().getUserReject().getName() ,
				saeO.get().getUserApproval().getName() ,
				saeO.get().getUserRejectGte().getName() ,
				saeO.get().getUserApprovalGte().getName() ,
				saeO.get().getUserRejectOver().getName() ,
				saeO.get().getUserApprovalOver().getName() ,
				saeO.get().getUserRejectLibera().getName() ,
				saeO.get().getUserApprovalLibera().getName() ,
				enviarTest,
				saeO.get().getMsgReject(), 
				saeO.get().getMsgRejectGte(),
				saeO.get().getMsgRejectOver(),
				saeO.get().getMsgRejectLibera(),
				saeO.get().getUserApproval().getEmail(),
				status,false);});
		
		//verify(saeRepository,times(3)).findAll();
						
	}

}
