package com.truper.saen;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.truper.saen.common.Respuesta;
import com.truper.saen.dto.SaeZcomZmpDto;
import com.truper.saen.service.SaeServices;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class SaesEstatusbyFiltersTest {

	@Autowired
	private SaeServices saeServices;

	@Test
	public void listarOrdenByItem() {
		log.info("entra listarOrdenByItem");
		try {
			SaeZcomZmpDto info = new SaeZcomZmpDto();
			info.setIdProveedor(710273);
			Respuesta respuesta = saeServices.getSaesEstatusbyFilters(info);
			System.out.println("respuesta: "+ respuesta.getFolio());
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
