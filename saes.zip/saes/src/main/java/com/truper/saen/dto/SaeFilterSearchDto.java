package com.truper.saen.dto;

import java.util.Date;

import com.truper.saen.commons.dto.Prioridad;

import lombok.Data;

@Data
public class SaeFilterSearchDto {
	
	private Long folio;
	private Integer idProveedor;
	private String nombreProveedor;
	private String status;
	private Integer idStatus;
	private Date eta;
	private String centro;
	private Prioridad prioridad;
	private Short conteoRevisado;
	private String tipo;
	private String idPO;

}
