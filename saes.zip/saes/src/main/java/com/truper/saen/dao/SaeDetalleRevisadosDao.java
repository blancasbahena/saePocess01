package com.truper.saen.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;

@Repository
public interface SaeDetalleRevisadosDao extends JpaRepository<SaeDetalleRevisado, SaeDetalleId>{
	@Modifying
	@Transactional
	@Query(value= "DELETE FROM SaeDetalleRevisado WHERE  idSae = ?1 and idPO =?2 and idPosicion=?3", nativeQuery=true )
	Integer  deleteDetalleSaeById(Long idFolio, String idPO, String idPosicion);
}
