package com.truper.saen.dto;

import lombok.Data;

@Data
public class SaePrioridadDto {
	
	private Long idSae;
	private Integer idPrioridad;

}
