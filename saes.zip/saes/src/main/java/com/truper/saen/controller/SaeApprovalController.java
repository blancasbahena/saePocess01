package com.truper.saen.controller;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.commons.dto.SaeDto;
import com.truper.saen.commons.dto.UserDTO;
import com.truper.saen.commons.enums.Mensajes;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.feign.UserFeignClient;
import com.truper.saen.service.SaeApprovalServices;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/sae-approval")
public class SaeApprovalController {
	
	@org.springframework.beans.factory.annotation.Autowired(required=true)
	private SaeApprovalServices saeServices;
	@org.springframework.beans.factory.annotation.Autowired(required=true)
	private UserFeignClient userFeignClient;
	@Autowired
	private JWUtil jwutil; 
	
	@PostMapping(value="/planeacion/reject",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaPlaneacionReject(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems witg approval SAE";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusPlaneacionSAEReject(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> createSae(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems witg approval SAE";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.approvalSAE(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}

	@PostMapping(value="/planeacion/approval",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaPlaneacionApproval(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems witg approval SAE";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusPlaneacionSAEApproval(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	
	@PostMapping(value = "/overstock/reject", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaOverstockReject(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems with reject SAE in OverStock";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusOverStockSAEReject(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	
	@PostMapping(value="/overstock/approval",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaOverstockApproval(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems witg overstock approval SAE";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusOverstockApproval(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	
	@PostMapping(value = "/gteplaneacion/reject", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaGtePlaneacionReject(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems with reject SAE in Gerente Planeación";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusGtePlanecionReject(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	
	@PostMapping(value = "/liberacion/reject", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaLiberacion(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems with reject SAE in liberacion";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusLiberacion(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
	
	@PostMapping(value = "/liberacionRechazados/reject", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> modificaLiberacionRechazados(@RequestHeader("Authorization") String authorization, @RequestBody SaeDto dto){
		String msgError="Problems with reject SAE in liberacionRechazados";
		Map<String, Object> formData = new HashMap<>();
		try {
			if (authorization != null && authorization.startsWith("Bearer ")) {
				authorization = authorization.substring(7);
			}
			String userName = jwutil.extractUsername(authorization);
			ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,"Bearer " + authorization);
			if (response.getStatusCode() == HttpStatus.OK) {
				com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
						.getBody();
				if (responseVO.getTipoMensaje().equals("S")) {
					Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
					Object o = mapa.get("usuario");
					log.info("[POST /create] | INICIO -  {} - { {} }",userName,dto.toString());
					ObjectMapper objectMapper = new ObjectMapper();
					UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);
					log.info(userDTO.toString());				
					if(userDTO instanceof com.truper.saen.commons.dto.UserDTO) { 
						if (userDTO != null) {
							dto.setUserModified(userDTO);
							Boolean respuesta = saeServices.cambiaStatusLiberacionRechazados(dto);
							log.info("[POST /create] | FIN");
							formData.put("response", respuesta);
							return new ResponseEntity<>(ResponseVO.builder()
								.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
								.mensaje(Mensajes.MSG_EXITO.getMensaje())
								.folio(ResponseVO.getFolioActual())
								.data(formData)
								.build(),HttpStatus.OK);
						}
					}
				}
				
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			msgError= ex.getMessage();
		}
		formData.put("response", new Boolean (false));
		ResponseVO responseVO = ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(msgError)
				.folio(ResponseVO.getFolioActual())
				.build();
		return new ResponseEntity<>(responseVO,HttpStatus.OK );
	}
}
