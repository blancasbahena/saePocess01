package com.truper.saen.service.impl;

import org.springframework.stereotype.Service;

import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.service.GeneralService;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class GeneralServiceImpl implements GeneralService{

	@Override
	public CatSaeStatus getEstatus(CatStatusSae status) {
		log.info("Seteando el parametro del estatus");
		CatSaeStatus catECatSaeStatus = new CatSaeStatus();
		catECatSaeStatus.setIdSaeStatus(status.getId());
		return catECatSaeStatus;
	}
	

}
