package com.truper.saen.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truper.saen.commons.dto.DataDTO;
import com.truper.saen.commons.dto.EmailDTO;
import com.truper.saen.commons.dto.ParamsDTO;
import com.truper.saen.commons.entities.MensajesEmails;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.utils.UtilsString;
import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsProveedorDTO;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.enums.DataConstants;
import com.truper.saen.feign.CatalogsFeignClient;
import com.truper.saen.rabbit.PublisherService;
import com.truper.saen.service.EmailsService;
import com.truper.saen.dao.MensajesEmailsDao;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmailsServiceImpl implements EmailsService {
	@Autowired
	private PublisherService sender;
	@Autowired
	private MensajesEmailsDao mensajesEmailsDao;

	@Autowired
	private CatalogsFeignClient catalogsFeignClient;

	@Value("${catalogs.username}")
	private String username;

	@Value("${catalogs.password}")
	private String password;

	@Value("${email.debug}")
	private String debug;

	@Value("${email.sender}")
	private String senderEmail;

	@Override
	public void envioCorreoValidar(Long folio, Integer idProveedor, String nombreProveedor, String userReject,
			String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus,boolean aprobar) {
		log.info("Se inicia proceso de envio de correo : {} ", new Date());
		if (idProveedor != null && nombreProveedor != null && folio != null && idStatus != null) {
			try {
				envioCorreoCitasPorConfirmar(folio, idProveedor, nombreProveedor, userReject, userApproval,
						userRejectGte, userApprovalGte, userRejectOver, userApprovalOver, userRejectLibera,
						userApprovalLibera, enviarTest, msgReject, msgRejectGte, msgRejectOver, msgRejectLibera,
						correosGerenteOpcionales, idStatus,aprobar);
			} catch (Exception ex) {
				System.out.println("Problemas con envio " + ex.getMessage());
			}

		} else {

			System.out.println("Problemas con el proveedor ejemplo ID!NOMBRE_PROVEEDOR " + nombreProveedor);
		}
		log.info("Se termina con error  el  proceso de envio de correo : {} ", new Date());
	}

	private Integer envioCorreoCitasPorConfirmar(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject, String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus,boolean aprobar) throws Exception {
		EmailDTO dtoEmail = new EmailDTO();
		Integer plantilla = 0;
		DataDTO data = new DataDTO();
		boolean isGerente = false;
		if (idStatus == CatStatusSae.SAE_RECHAZA_PLANEACION.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_PLANEADOR;
			data.setPlaning(userApproval);
			data.setUserReject(userReject);
			data.setMsgReject(msgReject);

		}
		if (idStatus == CatStatusSae.SAE_APROBADO_LIBERACION.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_PLANEADOR;
			data.setPlaning(userApproval);
			data.setUserReject(userReject);
			data.setMsgReject(msgReject);
			if(aprobar) {
				isGerente = true;
				plantilla = DataConstants.ID_PLANTILLA_LIBERACION_APROBACION;
			}else {
				plantilla = DataConstants.ID_PLANTILLA_LIBERACION_RECHAZO;
			}
		}
		if (idStatus == CatStatusSae.SAE_RECHAZA_GTE_PLANEACION.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_GTEPLANEACION;
			data.setPlaning(userApprovalGte);
			data.setUserReject(userRejectGte);
			data.setMsgReject(msgRejectGte);
			isGerente = true;
		}
		if (idStatus == CatStatusSae.SAE_RECHAZA_OVER_STOCK_STATUS25.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_OVER_STOCK;
			data.setPlaning(userApprovalOver);
			data.setUserReject(userRejectOver);
			data.setMsgReject(msgRejectOver);
		}
		if (idStatus == CatStatusSae.SAE_RECHAZA_OVER_STOCK_STATUS26.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_OVER_STOCK;
			data.setPlaning(userApprovalOver);
			data.setUserReject(userRejectOver);
			data.setMsgReject(msgRejectOver);
		}
		if (idStatus == CatStatusSae.SAE_RECHAZADO_LIBERACION.getId()) {
			plantilla = DataConstants.ID_PLANTILLA_OVER_STOCK;
			data.setPlaning(userApprovalLibera);
			data.setUserReject(userRejectLibera);
			data.setMsgReject(msgRejectLibera);
		}
		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(plantilla);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = UtilsString.replaceString2String(respuesta.get().getSubjectEmail(),
					DataConstants.CONST_PROVEEDOR, nombreProveedor);

			subject = UtilsString.replaceString2String(subject, DataConstants.CONST_FOLIO, folio.toString());
			log.info("Parametro del proceso de envio de correo  subject : {}", subject);
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ", debug);
			params.setDebug(debugParam);

			data.setFolio(folio.toString());
			if (senderEmail != null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ", senderEmail);
			if (respuesta.get().getPlantilla() != null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			data.setSupplier(nombreProveedor);
			String emailsProveedor = null;
			try {
				if (isGerente) {
					emailsProveedor = obtenerCorreosProveedor(idProveedor);
				} else {
					emailsProveedor = correosGerenteOpcionales;
				}
				log.info("Parametro del  proceso de envio de correo  emailsProveedor : {}", emailsProveedor);
			} catch (Exception ex) {
				ex.printStackTrace();
				return 3;
			}
			if (emailsProveedor != null) {
				if(!emailsProveedor.equals("")) {
					to = emailsProveedor.trim().split(";");
					cc = respuesta.get().getCc().trim().split(";");
					dtoEmail.setTo(Arrays.asList(to));
					data.setTo(emailsProveedor.trim());
					if (debug != null) {
						if (debug.equals("true")) {
							String[] toDebug = respuesta.get().getCc().trim().split(";");
							dtoEmail.setTo(Arrays.asList(toDebug));
						}
						data.setDebug(debug.equals("true") ? true : false);
					}
					log.info("Parametro del  proceso de envio de correo  to : {} ", to);
					dtoEmail.setCc(Arrays.asList(cc));
					log.info("Parametro del  proceso de envio de correo  cc : {} ", cc);
					dtoEmail.setSubject(subject);
					params.setData(data);
					log.info("Parametro del  proceso de envio de correo  data : {} ", data);
					dtoEmail.setParams(params);
					log.info("Parametro del  proceso de envio de correo  params : {} ", params);
					Gson gson = new GsonBuilder().create();
					String envioCorreo = gson.toJson(dtoEmail);
					log.info("Parametro del  proceso de envio de correo  JSON : {} ", envioCorreo);
					if (enviarTest) {
						sender.send(envioCorreo);
					}
					log.info("Proceso con exito");
					return 1;
				}
			} else {
				return 3;
			}
		}
		return 2;

	}

	private String obtenerCorreosProveedor(Integer idProveedor) throws Exception {
		log.info("Servicio para obtener correos de proveedor  {}  - {}  ", idProveedor, new Date());
		RequestToken requestToken = new RequestToken();
		requestToken.setPassword(password);
		requestToken.setUsername(username);
		ResponseTokenDTO token = catalogsFeignClient.getToken(requestToken);
		if (token != null) {
			ResponseCatalogsProveedorDTO response = catalogsFeignClient.getDataProveedor(idProveedor.toString(),
					"Bearer " + token.getData().getToken());
			if (response.getData().getProveedor().getEmail() == null
					|| response.getData().getProveedor().getEmail().equals("")) {
				throw new Exception("Error al obtener los correos del proveedor");
			}
			log.info("Servicio para obtener correos    {}  - {}  ", response.getData().getProveedor().getEmail(),
					new Date());
			return response.getData().getProveedor().getEmail();
		} else {
			throw new Exception("Error al obtener token para el envio de correo");
		}
	}

	@Override
	public void envioCorreoCancelacion(Long folio, Integer idProveedor, String nombreProveedor, String userReject,
			String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus) {
		try {
			envioCorreoCancelacionRechazo(folio, idProveedor, nombreProveedor, userReject, userApproval, userRejectGte,
					userApprovalGte, userRejectOver, userApprovalOver, userRejectLibera, userApprovalLibera, enviarTest,
					msgReject, msgRejectGte, msgRejectOver, msgRejectLibera, correosGerenteOpcionales, idStatus);
		} catch (Exception ex) {
			System.out.println("Problemas con envio " + ex.getMessage());
		}

	}

	private Integer envioCorreoCancelacionRechazo(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject, String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus) throws Exception {
		EmailDTO dtoEmail = new EmailDTO();
		Integer plantilla = 0;
		DataDTO data = new DataDTO();
		boolean isGerente = false;

		plantilla = DataConstants.ID_PLANTILLA_CANCELACION;
		data.setPlaning(userApproval);
		data.setUserReject(userReject);
		data.setMsgReject(msgReject);

		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(plantilla);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = UtilsString.replaceString2String(respuesta.get().getSubjectEmail(),
					DataConstants.CONST_PROVEEDOR, nombreProveedor);

			subject = UtilsString.replaceString2String(subject, DataConstants.CONST_FOLIO, folio.toString());
			log.info("Parametro del proceso de envio de correo  subject : {}", subject);
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ", debug);
			params.setDebug(debugParam);

			data.setFolio(folio.toString());
			if (senderEmail != null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ", senderEmail);
			if (respuesta.get().getPlantilla() != null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			data.setSupplier(nombreProveedor);
			String emailsProveedor = null;
			try {
				if (isGerente) {
					emailsProveedor = obtenerCorreosProveedor(idProveedor);
				} else {
					emailsProveedor = correosGerenteOpcionales;
				}
				log.info("Parametro del  proceso de envio de correo  emailsProveedor : {}", emailsProveedor);
			} catch (Exception ex) {
				ex.printStackTrace();
				return 3;
			}
			if (emailsProveedor != null) {
				to = emailsProveedor.trim().split(";");
				cc = respuesta.get().getCc().trim().split(";");
				dtoEmail.setTo(Arrays.asList(to));
				data.setTo(emailsProveedor.trim());
				if (debug != null) {
					if (debug.equals("true")) {
						String[] toDebug = respuesta.get().getCc().trim().split(";");
						dtoEmail.setTo(Arrays.asList(toDebug));
					}
					data.setDebug(debug.equals("true") ? true : false);
				}
				log.info("Parametro del  proceso de envio de correo  to : {} ", to);
				dtoEmail.setCc(Arrays.asList(cc));
				log.info("Parametro del  proceso de envio de correo  cc : {} ", cc);
				dtoEmail.setSubject(subject);
				params.setData(data);
				log.info("Parametro del  proceso de envio de correo  data : {} ", data);
				dtoEmail.setParams(params);
				log.info("Parametro del  proceso de envio de correo  params : {} ", params);
				Gson gson = new GsonBuilder().create();
				String envioCorreo = gson.toJson(dtoEmail);
				log.info("Parametro del  proceso de envio de correo  JSON : {} ", envioCorreo);
				if (enviarTest) {
					sender.send(envioCorreo);
				}
				log.info("Proceso con exito");
				return 1;
			} else {
				return 3;
			}
		}
		return 2;

	}

	@Override
	public void envioCorreoAprobacion(Long folio, Integer idProveedor, String nombreProveedor, String userReject,
			String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus) {

		try {
			envioCorreoAprobCancelacion(folio, idProveedor, nombreProveedor, userReject, userApproval, userRejectGte,
					userApprovalGte, userRejectOver, userApprovalOver, userRejectLibera, userApprovalLibera, enviarTest,
					msgReject, msgRejectGte, msgRejectOver, msgRejectLibera, correosGerenteOpcionales, idStatus);
		} catch (Exception ex) {
			System.out.println("Problemas con envio " + ex.getMessage());
		}
	}

	private Integer envioCorreoAprobCancelacion(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject, String userApproval, String userRejectGte, String userApprovalGte, String userRejectOver,
			String userApprovalOver, String userRejectLibera, String userApprovalLibera, boolean enviarTest,
			String msgReject, String msgRejectGte, String msgRejectOver, String msgRejectLibera,
			String correosGerenteOpcionales, Integer idStatus) throws Exception {
		EmailDTO dtoEmail = new EmailDTO();
		Integer plantilla = 0;
		DataDTO data = new DataDTO();
		boolean isGerente = false;

		plantilla = DataConstants.ID_PLANTILLA_APROBACION_CANCELACION;
		data.setPlaning(userApproval);
		data.setUserReject(userReject);
		data.setMsgReject(msgReject);

		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(plantilla);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = UtilsString.replaceString2String(respuesta.get().getSubjectEmail(),
					DataConstants.CONST_PROVEEDOR, nombreProveedor);

			subject = UtilsString.replaceString2String(subject, DataConstants.CONST_FOLIO, folio.toString());
			log.info("Parametro del proceso de envio de correo  subject : {}", subject);
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ", debug);
			params.setDebug(debugParam);

			data.setFolio(folio.toString());
			if (senderEmail != null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ", senderEmail);
			if (respuesta.get().getPlantilla() != null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			data.setSupplier(nombreProveedor);
			String emailsProveedor = null;
			try {
				if (isGerente) {
					emailsProveedor = obtenerCorreosProveedor(idProveedor);
				} else {
					emailsProveedor = correosGerenteOpcionales;
				}
				log.info("Parametro del  proceso de envio de correo  emailsProveedor : {}", emailsProveedor);
			} catch (Exception ex) {
				ex.printStackTrace();
				return 3;
			}
			if (emailsProveedor != null) {
				to = emailsProveedor.trim().split(";");
				cc = respuesta.get().getCc().trim().split(";");
				dtoEmail.setTo(Arrays.asList(to));
				data.setTo(emailsProveedor.trim());
				if (debug != null) {
					if (debug.equals("true")) {
						String[] toDebug = respuesta.get().getCc().trim().split(";");
						dtoEmail.setTo(Arrays.asList(toDebug));
					}
					data.setDebug(debug.equals("true") ? true : false);
				}
				log.info("Parametro del  proceso de envio de correo  to : {} ", to);
				dtoEmail.setCc(Arrays.asList(cc));
				log.info("Parametro del  proceso de envio de correo  cc : {} ", cc);
				dtoEmail.setSubject(subject);
				params.setData(data);
				log.info("Parametro del  proceso de envio de correo  data : {} ", data);
				dtoEmail.setParams(params);
				log.info("Parametro del  proceso de envio de correo  params : {} ", params);
				Gson gson = new GsonBuilder().create();
				String envioCorreo = gson.toJson(dtoEmail);
				log.info("Parametro del  proceso de envio de correo  JSON : {} ", envioCorreo);
				if (enviarTest) {
					sender.send(envioCorreo);
				}
				log.info("Proceso con exito");
				return 1;
			} else {
				return 3;
			}
		}
		return 2;

	}

}
