package com.truper.saen.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class SaeZcomZmpDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String tipo;
	private List<Integer> status;
	private Integer idProveedor; 
	private String etaSolicitada; 
	private Integer folio;
	private Integer ida;
	private Integer po;
	private String planeador;
	private String idCentro;
	private String codigo;
	private long item;
	private Integer estatus;
	private String centro;
}
