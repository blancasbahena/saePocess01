package com.truper.saen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.CatTipoDeUnidad;

public interface TipoUnidadDao extends JpaRepository<CatTipoDeUnidad, Integer>{

}
