package com.truper.saen.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.truper.saen.commons.dto.Prioridad;

import lombok.Data;

@Data
public class SaeRevisadosCanceladosResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long folio;
	private Integer idProveedor;
	private String proveedor;
	private String eta;
	@JsonIgnore
	private Integer idaMin;
	private Integer totalCodigos;
	private Integer numeroUnidades;
	private String msgCancelaLibera;
	private Boolean citaReprogramada;
	private Prioridad prioridad;
	private Short conteoRevisado;
	private String tipo;
	private String tipoUnidad;
	private String msgRechazo;
	private String msgCancelaCita;
	private Integer estatus;
	private Integer idStatus;
	private String idPO; 
	private String centro;

}
