package com.truper.saen.service.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.aspectj.asm.internal.Relationship;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.PoDetalleDto;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.UserDTO;
import com.truper.saen.commons.entities.CatCentro;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Relationships;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.dao.CatPrioridadesDao;
import com.truper.saen.dao.CentroDao;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dao.SaeDetalleDao;
import com.truper.saen.dao.SaeDetalleRevisadosDao;
import com.truper.saen.dao.SaeRevisadosDao;
import com.truper.saen.dao.StatusDao;
import com.truper.saen.dao.UserDao;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.dto.ResponseWsPosApiDTO;
import com.truper.saen.dto.SaeCentroDto;
import com.truper.saen.dto.SaeDto;
import com.truper.saen.dto.SaeIntDto;
import com.truper.saen.dto.SaePrioridadDto;
import com.truper.saen.dto.SaeZcomZmpDto;
import com.truper.saen.feign.PosFeignClient;
import com.truper.saen.service.SaeFiltersServices;
import com.truper.saen.service.SaeServices;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SaeServicesImpl implements SaeServices {

	@Autowired
	private SaeDao saeDao;

	@Autowired
	private CentroDao centroDao;

	@Autowired
	private SaeDetalleDao saeDetalleDao;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private UserDao userDao;

	@Autowired
	private CatPrioridadesDao catPrioridadesDao;

	@Autowired
	private SaeRevisadosDao saerevisadosDao;

	@Autowired
	private SaeDetalleRevisadosDao detalleRevisadoDao;

	@Autowired
	private PosFeignClient posFeignClient;

	@Value("${pos-cp.user}")
	private String usuario;

	@Value("${pos-cp.password}")
	private String password;

	@Autowired
	private SaeFiltersServices saeFiltersServices;
	
	@Autowired
	private StatusDao statusDao;

	private ResponseWsPosApiDTO dataPos = null;

	@Override
	public Respuesta createSae(SaeIntDto info) {

		Respuesta resp = new Respuesta();

		if (info.getIdProveedor() != null && info.getIdProveedor() > 0) {
			Sae newSae = new Sae();

			CatSaeStatus status = new CatSaeStatus();
			status.setIdSaeStatus(CatStatusSae.SAE_CREADO.getId());
			newSae.setStatus(status);

			newSae.setIdProveedor(info.getIdProveedor());
			Date fecha = new Date();
			newSae.setCreated(fecha);
			newSae.setLastModified(fecha);

			List<User> users = userDao.findByUserName(info.getUser().toString());

			if (users.isEmpty()) {
				resp.setTipoMensaje(ResponseMessage.TIPO_ERROR.getMensaje());
				resp.setMensaje("El Usuario no es valido para crear un SAE");
				resp.setEstado(HttpStatus.BAD_REQUEST);
			}

			User user = users.get(0);

			newSae.setUserCreated(user);
			newSae.setUserModified(user);
			newSae.setNombreProveedor(info.getNombreProveedor());
			newSae = saeDao.save(newSae);

			SaeIntDto saeq = new SaeIntDto();
			saeq.setIdSae(newSae.getFolio());
			saeq.setUser(info.getUser());
			saeq.setIdProveedor(info.getIdProveedor());

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), "SAE creado con exito", "sae", saeq);
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_ERROR.getMensaje());
			resp.setMensaje("El Proveedor no es valido para crear un SAE");
			resp.setEstado(HttpStatus.BAD_REQUEST);

		}

		return resp;
	}

	@Override
	public Respuesta getSaeById(Long idSae) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(idSae).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			SaeDto saeDto = this.saeToSaeDto(sae);

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					saeDto);
			resp.setEstado(HttpStatus.OK);

		} else {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		}

		return resp;
	}

	@Override
	public Respuesta getSaesByStatus(Integer idStatus) {
		List<SaeDto> saesDto = new ArrayList<>();
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");

		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(idStatus);

		List<Sae> saes = saeDao.findByStatus(status);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (saes.isEmpty()) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			for (Sae sae : saes) {
				SaeDto sdto = saeToSaeDto(sae);
				saesDto.add(sdto);
			}
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"saes", saesDto);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta cancelarSae(SaeIntDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (sae != null) {

			CatSaeStatus status = new CatSaeStatus();
			status.setIdSaeStatus(CatStatusSae.SAE_CANCELADO.getId());
			sae.setStatus(status);

			sae.setComentarios(info.getComentarios());

			sae.setLastModified(new Date());

			User user = new User();
			user.setId(info.getUser());
			sae.setUserModified(user);
			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDao.save(sae);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"status", "SAE Cancelado");
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}

		return resp;
	}

	@Override
	public Respuesta rechazarSae(SaeIntDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (sae != null) {

			switch (sae.getStatus().getIdSaeStatus()) {
			case 14:
			case 17:
				sae.setMsgRejectCancel(info.getComentarios());

				SaeRevisado saeRev = saerevisadosDao.findById(sae.getFolio()).orElse(null);

				if (saeRev != null) {

					for (SaeDetalleRevisado detalle : saeRev.getSaeDetalles()) {
						detalleRevisadoDao.delete(detalle);
					}

					saerevisadosDao.delete(saeRev);

				}

				break;
			case 24:
			case 27:
				/** Aqui no debe incrementarse el contador **/
				sae.setMsgRejectReview(info.getComentarios());
				//sae.setConteoRevisado((short) (sae.getConteoRevisado() + 1));
			default:
				break;
			}

			CatSaeStatus status = new CatSaeStatus();
			status.setIdSaeStatus(info.getIdStatus());
			sae.setStatus(status);

			sae.setLastModified(new Date());

			User user = new User();
			user.setId(info.getIdUser());
			sae.setUserModified(user);
			sae.setUserRejectReview(user);
			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDao.save(sae);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"status", "SAE Rechazado");
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
	}

	@Override
	public Respuesta actualizarSae(SaeDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getFolio()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			// info.getIdStatus());
			CatSaeStatus status = new CatSaeStatus();
			status.setIdSaeStatus(info.getIdStatus());
			sae.setStatus(status);
			sae.setComentarios(info.getComentarios());

			sae.setLastModified(new Date());

			User user = userDao.findById(info.getUserModified().getId()).orElse(null);
			sae.setUserModified(user);

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDao.save(sae);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					sae);
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
	}

	@Override
	public Respuesta addPOsToSar(SaeDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getFolio()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			Set<SaeDetalle> posDetalle = new HashSet<>();

			for (PoDetalleDto detallePO : info.getSaeDetalles()) {
				SaeDetalle detalle = new SaeDetalle();
				SaeDetalleId detalleId = new SaeDetalleId();
				detalleId.setIdSae(info.getFolio());
				detalleId.setIdPosicion(detallePO.getIdDetalle().getIdPosicion().trim());
				detalleId.setIdPO(detallePO.getIdDetalle().getIdPO().trim());

				detalle.setIdDetalle(detalleId);
				detalle.setCondicionPago(detallePO.getCondicionPago());
				detalle.setMaterial(detallePO.getMaterial().trim());
				detalle.setCantidad(detallePO.getCantidad());
				detalle.setPlanner(detallePO.getPlaneadorProducto());

				// CatCentro centro = centroDao.findByCentro( detallePO.getCentro().trim()
				// ).get(0);

				// detalle.setCentro(centro.getIdCentro());

				posDetalle.add(detalle);

			}

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDetalleDao.saveAll(posDetalle);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					sae);
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
	}

	@Override
	public Respuesta getCurrentSae(Integer idProveedor) {
		Respuesta resp = new Respuesta();
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Sae> cq = cb.createQuery(Sae.class);

		Root<Sae> sae = cq.from(Sae.class);
		Predicate pred = cb.and(cb.equal(sae.get("idProveedor"), idProveedor),
				cb.equal(sae.get("status").get("idSaeStatus"), CatStatusSae.SAE_CREADO.getId()));

		cq.where(pred).orderBy(cb.desc(sae.get("created")));
		TypedQuery<Sae> query = entityManager.createQuery(cq);

		query.setFirstResult(0);
		query.setMaxResults(1);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = query.getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {
			Sae saeq = result.get(0);
			SaeIntDto saedto = new SaeIntDto();
			saedto.setIdSae(saeq.getFolio());
			saedto.setIdProveedor(idProveedor);
			saedto.setIdStatus(saeq.getStatus().getIdSaeStatus());
			saedto.setTipo(saeq.getTipo());

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					saedto);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta getSaeByIdProveedor(Integer idProveedor, Integer pagina, Integer rows) {
		Respuesta resp = new Respuesta();
		List<SaeDto> saesDto = new ArrayList<>();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		List<Sae> saes = saeDao.findByIdProveedor(idProveedor, pagina * rows, rows);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (saes.isEmpty()) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			for (Sae sae : saes) {
				SaeDto sdto = saeToSaeDto(sae);
				saesDto.add(sdto);
			}
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"saes", saesDto);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta getSaesEstatusbyFilters(SaeZcomZmpDto filters) {
		Respuesta resp = new Respuesta();
		List<SaeDto> saesDto = new ArrayList<>();
		List<Sae> saes = saeFiltersServices.getfiltersByFiltersProv(filters, null);
		if (saes.isEmpty()) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			for (Sae sae : saes) {
				SaeDto sdto = saeToSaeDto(sae);
				saesDto.add(sdto);
			}
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"saes", saesDto);
			resp.setEstado(HttpStatus.OK);
		}
		/*if(filters.getItem() != 0) {
			com.truper.saen.dto.User user = new com.truper.saen.dto.User();
			user.setUsername(usuario);
			user.setPassword(password);
			ResponseTokenDTO token = posFeignClient.getToken(user);
			log.info("Esto es el token {}",token.getToken());
			if (token.getToken() != null && !token.getToken().equals("")) {
				dataPos = posFeignClient.getDataFromWsPosApi(filters.getItem(), "Bearer " + token.getToken());
				log.info(dataPos.getMensaje());
				List<Sae> saes = saeFiltersServices.getfiltersByFiltersProv(filters, dataPos.getData().getOrdenes());
				if (saes.isEmpty()) {
					resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
					resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
					resp.setEstado(HttpStatus.NOT_FOUND);
				} else {
					for (Sae sae : saes) {
						SaeDto sdto = saeToSaeDto(sae);
						saesDto.add(sdto);
					}
					resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
							"saes", saesDto);
					resp.setEstado(HttpStatus.OK);
				}
			}			
		}else {
			List<Sae> saes = saeFiltersServices.getfiltersByFiltersProv(filters, null);
			if (saes.isEmpty()) {
				resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
				resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
				resp.setEstado(HttpStatus.NOT_FOUND);
			} else {
				for (Sae sae : saes) {
					SaeDto sdto = saeToSaeDto(sae);
					saesDto.add(sdto);
				}
				resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
						"saes", saesDto);
				resp.setEstado(HttpStatus.OK);
			}
		}*/
		
		return resp;
	}

	@Override
	public Respuesta getSaeByIdProveedor(Integer idProveedor) {
		Respuesta resp = new Respuesta();
		List<SaeDto> saesDto = new ArrayList<>();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		List<Sae> saes = saeDao.findByIdProveedor(idProveedor);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (saes.isEmpty()) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			for (Sae sae : saes) {
				SaeDto sdto = saeToSaeDto(sae);
				saesDto.add(sdto);
			}
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"saes", saesDto);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	public SaeDto saeToSaeDto(Sae sae) {

		if (sae == null) {
			return null;
		}
		SaeDto saeDto = new SaeDto();
		if(sae.getSaeDetalles() != null && !sae.getSaeDetalles().isEmpty()) {
			saeDto.setIdPO(sae.getSaeDetalles().get(0).getIdDetalle().getIdPO());
		}
		saeDto.setFolio(sae.getFolio());
		saeDto.setTipo(sae.getTipo());
		saeDto.setIdStatus(sae.getStatus().getIdSaeStatus());
		saeDto.setStatusSae(sae.getStatus().getEstatus());
		saeDto.setEta(sae.getEta());
		saeDto.setEtaSolicitada(sae.getEtaSolicitada());
		saeDto.setIdProveedor(sae.getIdProveedor());
		saeDto.setUnidades(sae.getUnidades());
		saeDto.setTipoUnidad(sae.getTipoDeUnidad() == null ? null : sae.getTipoDeUnidad().getTipoUnidad());
		saeDto.setIdaMin(sae.getIdaMin());
		saeDto.setTotalCodigos(sae.getTotalCodigos());
		saeDto.setMonto(sae.getMonto());
		saeDto.setConteoRevisado(sae.getConteoRevisado());
		saeDto.setConteoRechazado(sae.getConteoRechazado());
		saeDto.setIdConfirmador(sae.getIdConfirmador());
		saeDto.setFechaConfirmacion(sae.getFechaConfirmacion());
		saeDto.setRechazoConfirmacion(sae.getRechazoConfirmacion());
		saeDto.setCreated(sae.getCreated());
		saeDto.setCita(sae.getCita() == null ? null : sae.getCita().getFechaCita());
		saeDto.setNombreProveedor(sae.getNombreProveedor());
		saeDto.setDateApproval(sae.getDateApproval());
		saeDto.setMsgRejectGte(null);
		saeDto.setDate1erApproval(sae.getDate1erApproval());
		saeDto.setDateReject(null);
		saeDto.setMsgReject(null);
		switch (sae.getStatus().getIdSaeStatus()) {
		case 5:
			saeDto.setDateReject(sae.getDateReject());
			saeDto.setMsgReject(sae.getMsgReject());
			break;
		case 50:
			saeDto.setDateReject(sae.getDateRejectCancel());
			saeDto.setMsgReject(sae.getMsgRejectCancel());
			break;
		}

		Double pesoTotal = 0.0;
		Double volTotal = 0.0;

		for (SaeDetalle detalle : sae.getSaeDetalles()) {
			pesoTotal += detalle.getPeso() == null ? 0 : detalle.getPeso();
			volTotal += detalle.getVolumen() == null ? 0 : detalle.getVolumen();
		}

		saeDto.setPesoTotal(pesoTotal);
		saeDto.setVolTotal(volTotal);

		return saeDto;
	}

	@Override
	public Respuesta getTotalSaesByIdProveedor(Integer idProveedor) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Long total = saeDao.countSaesBy(idProveedor);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (total == null) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"total", total);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}
	
	@Override
	public Respuesta getEstatus() {
		Respuesta resp = new Respuesta();
		List<CatSaeStatus> estatus =statusDao.findAll();
		if (estatus == null) {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		} else {
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"estatusA", estatus);
			resp.setEstado(HttpStatus.OK);
		}
		return resp;
	}

	@Override
	public Respuesta actualizarPrioridadSae(SaePrioridadDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			sae.setLastModified(new Date());

			Optional<CatPrioridades> catPrioridad = catPrioridadesDao.findById(info.getIdPrioridad());
			if (catPrioridad.isPresent()) {
				sae.setPrioridades(catPrioridad.get());
			}

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDao.save(sae);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					sae.getFolio());
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
	}
	
	@Override
	public Respuesta actualizarCentroSae(SaeCentroDto info) {
		Respuesta resp = new Respuesta();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeDao.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			sae.setLastModified(new Date());
			sae.setCentro(info.getCentro());

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeDao.save(sae);
			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
					sae.getFolio());
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
	}

	@Override
	public Respuesta eliminaPos(Long idSae) {
		// TODO Auto-generated method stub
		return null;
	}

}
