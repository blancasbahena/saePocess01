package com.truper.saen.dto;

import lombok.Data;

@Data
public class SaeCentroDto {
	
	private Long idSae;
	private String centro;

}
