package com.truper.saen.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;

@Repository
public interface SaeDao extends JpaRepository<Sae, Long> {

	List<Sae> findByStatus(CatSaeStatus status);

	@Query(value="SELECT * FROM SAE s WHERE s.idProveedor = ?1 ORDER BY s.folio DESC OFFSET ?2 ROWS FETCH NEXT ?3 ROWS ONLY",nativeQuery = true )
	List<Sae> findByIdProveedor(Integer idProveedor,Integer offset,Integer rows);
	
	List<Sae> findByIdProveedor(Integer idProveedor);
	
	/*@Query(value="select DISTINCT s.* from Sae s \r\n" + 
			" left join SaeDetalle sd on s.folio =sd.idSae  \r\n" + 
			" left join SaeDetalleRevisado sdr on s.folio =sdr.idSae \r\n" + 
			" where s.idProveedor  = :idProveedor \r\n" + 
			" and (:folio is null or :folio = s.folio)\r\n" + 
			" and (:idpo is null or :idpo = sd.idPO or :idpo = sdr.idPO)\r\n" + 
			" and (:listPo is null or sd.idPO in (:listPo) or sdr.idPO in (:listPo))",nativeQuery = true )
	List<Sae> findByFilters(@Param("idProveedor")long idProveedor, @Param("folio")String folio,@Param("idpo")String idpo,@Param("listPo") List<Long> listPo);*/
	
	@Query( "SELECT COUNT(s) FROM Sae s WHERE s.idProveedor = ?1 " )
	Long countSaesBy( Integer idProveedor ); 
	
	@Modifying
	@Transactional
	@Query(value= "DELETE FROM SaeDetalle WHERE  idSae = ?1 ", nativeQuery=true )
	Integer  deleteSaeById(Long idFolio);
}
