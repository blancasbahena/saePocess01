package com.truper.saen.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.truper.saen.dto.EmailTemplateDTO;
import com.truper.saen.dto.ResponseEmailVO;
import com.truper.saen.dto.ResponseTokenDTO;

@FeignClient(name = "apiEmail", url = "${url.ws.email}")
public interface WsEmailFeignClient {
	
	String AUTH_TOKEN = "Authorization";
	
	@PostMapping("${url.ws.send.email.token}")
	ResponseTokenDTO getToken(@RequestParam("username") String username, @RequestParam("password") String password);
	
	@PostMapping(value = "${url.ws.send.email.simple}")
	ResponseEmailVO sendEmailSimple(@RequestBody EmailTemplateDTO emailTemplateDTO, @RequestHeader(AUTH_TOKEN) String bearerToken);

}
