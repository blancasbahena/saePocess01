package com.truper.saen.service;

import com.truper.saen.commons.dto.SaeDto;

public interface SaeApprovalServices {
	boolean approvalSAE(SaeDto dto);
	boolean cambiaStatusPlaneacionSAEApproval(SaeDto dto);
	boolean cambiaStatusPlaneacionSAEReject(SaeDto dto);
	boolean cambiaStatusOverStockSAEReject(SaeDto dto);
	boolean cambiaStatusGtePlanecionReject(SaeDto dto);
	boolean cambiaStatusLiberacionReject(SaeDto dto);
	boolean cambiaStatusLiberacion(SaeDto dto);
	boolean cambiaStatusLiberacionRechazados(SaeDto dto);
	boolean cambiaStatusOverstockApproval(SaeDto dto);
}
