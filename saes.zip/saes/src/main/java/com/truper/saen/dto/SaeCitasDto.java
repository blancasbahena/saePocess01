package com.truper.saen.dto;

import java.io.Serializable;

import com.truper.saen.commons.dto.Prioridad;

import lombok.Data;

@Data
public class SaeCitasDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long folio;
	private Integer idProveedor;
	private String proveedor;
	private Integer diasParaEta;
	private String eta;
	private String etaSolicitada;
	private Integer idaMin;
	private Double bo;
	private Double os;
	private Integer totalCodigos;
	private String tipoUnidad;
	private Integer numeroUnidades;
	private String centro;
	private Prioridad prioridad;
	private Short conteoRevisado;
	private String tipo;
	private String idPO;
	
}
