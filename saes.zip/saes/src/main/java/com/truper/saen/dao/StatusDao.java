package com.truper.saen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.CatSaeStatus;

public interface StatusDao extends JpaRepository<CatSaeStatus, Integer>{

}
