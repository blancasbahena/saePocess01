package com.truper.saen.service;

public interface ISaeDetalleLiberadosService {
	
	void crearDetalleLiberado( Long folio);

}
