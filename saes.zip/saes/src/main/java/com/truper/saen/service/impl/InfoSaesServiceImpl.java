package com.truper.saen.service.impl;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.truper.saen.commons.dto.UserDTO;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dao.UserDao;
import com.truper.saen.dto.ApprovalBovedaDto;
import com.truper.saen.feign.UserFeignClient;
import com.truper.saen.service.InfoSaesService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InfoSaesServiceImpl implements InfoSaesService {

	@Autowired
	private UserFeignClient userFeignClient;

	@Autowired
	private UserDao userRepository;
	@Autowired
	private JWUtil jwutil;
	
	@Autowired
	private SaeDao saeDao;

	@Override
	public User obtenerUsuario(String authorization) {
		if (authorization != null && authorization.startsWith("Bearer ")) {
			authorization = authorization.substring(7);
		}
		@SuppressWarnings("static-access")
		String userName = jwutil.extractUsername(authorization);
		ResponseEntity<com.truper.saen.commons.dto.ResponseVO> response = userFeignClient.getUser(userName, 0l,
				"Bearer " + authorization);
		if (response.getStatusCode() == HttpStatus.OK) {
			com.truper.saen.commons.dto.ResponseVO responseVO = (com.truper.saen.commons.dto.ResponseVO) response
					.getBody();
			if (responseVO.getTipoMensaje().equals("S")) {
				Map<String, Object> mapa = (Map<String, Object>) responseVO.getData();
				Object o = mapa.get("usuario");
				log.info("[POST /create] | INICIO -  {} - { {} }", userName);
				ObjectMapper objectMapper = new ObjectMapper();
				UserDTO userDTO = objectMapper.convertValue(o, UserDTO.class);

				Optional<User> user = userRepository.findById(userDTO.getId());

				if (user.isPresent()) {
					return user.get();
				}

			}
		}
		return null;

	}

	@Override
	public void log(String operation) {
		Date inicio = new Date();
		Date fin = new Date();
		log.info(operation, " - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

	}

	@Override
	public Sae getSae(Long id) {
		Optional<Sae> optional = saeDao.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

}
