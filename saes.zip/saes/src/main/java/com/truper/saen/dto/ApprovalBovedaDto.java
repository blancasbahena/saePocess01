package com.truper.saen.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class ApprovalBovedaDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long folio;
	private Integer idStatus;
	private Integer unidades;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date eta;
	private String msgReject;
	private String sucursalCentro;
	
	

}
