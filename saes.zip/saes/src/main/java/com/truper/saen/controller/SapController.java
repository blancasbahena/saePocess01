package com.truper.saen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dto.SaePrioridadDto;
import com.truper.saen.service.SapService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/sae-sap")
public class SapController {
	
	@Autowired
	private SapService sapService;
	
	@PutMapping( value = "/actualizaPo", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> actualizaPo(@RequestHeader("Authorization") String token, @RequestBody  SaePrioridadDto info ){
		log.info("[PUT /actualizar/{}] | INICIO -  {} - { {} }",info.getIdSae(),info,JWUtil.extractUsername(token.substring(7)));
		//sapService.actualizaPo();	
		log.info("[PUT /actualizar/{}] | FIN",info.getIdSae());
		return null;
	}

}
