package com.truper.saen.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.dto.ResponseCatalogsProveedorDTO;
import com.truper.saen.dto.ResponseTokenDTO;

@FeignClient(name = "apiCatalogs", url = "${catalogs.host}")
public interface CatalogsFeignClient {

	String AUTH_TOKEN = "Authorization";

	@PostMapping("${catalogs.path-token}")
	ResponseTokenDTO getToken(@RequestBody RequestToken requestToken);

	@GetMapping(value = "${catalogs.path-data-proveedor}")
	ResponseCatalogsProveedorDTO getDataProveedor(@PathVariable String idProveedor,
			@RequestHeader(value = "Authorization", required = true) String bearerToken);
	
	
	@GetMapping(value = "${catalogs.path-prioridad}")
	ResponseCatalogsPrioridadDTO getPrioridadByTipo(@PathVariable String tipo,
			@RequestHeader(value = "Authorization", required = true) String bearerToken);
}
