package com.truper.saen.service.impl;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dao.SaeDetalleDao;
import com.truper.saen.dao.SaeDetalleRevisadosDao;
import com.truper.saen.dao.SaeRevisadosDao;
import com.truper.saen.dao.UserDao;
import com.truper.saen.dto.ApprovalBovedaDto;
import com.truper.saen.service.EmailsService;
import com.truper.saen.service.ISaeDetalleLiberadosService;
import com.truper.saen.service.InfoSaesService;
import com.truper.saen.service.OperationSaeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j  
@Service
public class OperationSaeServiceImpl implements OperationSaeService {

	@Autowired 
	private InfoSaesService infoSaesService;
	@Autowired
	private SaeDao saeDao;
	@Autowired
	private SaeRevisadosDao saeRevisadosDao;
	@Autowired
	private SaeDetalleDao saeDetalleDao;
	@Autowired
	private SaeDetalleRevisadosDao saeDetalleRevisadosDao;
	@Autowired
	private EmailsService emailServices;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private ISaeDetalleLiberadosService saeDetalleLiberadosService;

			
	@Override
	public Respuesta operationSae(String authorization, ApprovalBovedaDto info) {
		infoSaesService.log("Operation Sae");
		Respuesta resp = new Respuesta();

		Sae sae = getSae(info);
		User usuario = infoSaesService.obtenerUsuario(authorization);

		Sae saeDB = updateSae(info, authorization, CatStatusSae.SAE_APROBADO_LIBERACION.getId(), sae);
		resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
				sae.getFolio());
		
		saeDao.save(saeDB);
		emailServices.envioCorreoValidar(
				saeDB.getFolio(),
				saeDB.getIdProveedor(),
				validaNombre(saeDB.getNombreProveedor()).toUpperCase(),
				regresaNombre(saeDB.getUserReject()),
				regresaNombre(saeDB.getUserApproval()),
				regresaNombre(saeDB.getUserRejectGte()),
				regresaNombre(saeDB.getUserApprovalGte()),
				regresaNombre(saeDB.getUserRejectOver()),
				regresaNombre(saeDB.getUserApprovalOver()),
				regresaNombre(saeDB.getUserRejectLibera()),
				regresaNombre(saeDB.getUserApprovalLibera()),
				true,
				saeDB.getMsgReject(),
				saeDB.getMsgRejectGte(),
				saeDB.getMsgRejectOver(),
				saeDB.getMsgRejectLibera(),
				saeDB.getUserApproval()!=null ?
						(saeDB.getUserApproval().getEmail()!=null ? 
								saeDB.getUserApproval().getEmail().trim(): "")
						: "",
						saeDB.getStatus().getIdSaeStatus().intValue(),true);
		resp.setEstado(HttpStatus.OK);
		infoSaesService.log("Operation Sae Fin ");
		return resp;
	}

	private Sae updateSae(ApprovalBovedaDto info, String authorization, Integer idStatus, Sae saeDb) {
		User usuario = infoSaesService.obtenerUsuario(authorization);
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(idStatus);
		saeDb.setStatus(status);
		saeDb.setUserModified(usuario);
		// saeDao.save(saeDb);
		return saeDb;

	}

	Long deleteDetalleSae(Long idFolio) {
		saeDao.deleteSaeById(idFolio);
		return idFolio;
	}

	Sae getSae(ApprovalBovedaDto info) {
		Optional<Sae> optional = saeDao.findById(info.getFolio());
		Sae saeDb = null;
		if (optional.isPresent()) {
			saeDb = optional.get();
		}
		return saeDb;
	}

	SaeRevisado getSaeRevisado(ApprovalBovedaDto info) {
		Optional<SaeRevisado> optional = saeRevisadosDao.findById(info.getFolio());
		SaeRevisado saeDb = null;
		if (optional.isPresent()) {
			saeDb = optional.get();
		}
		return saeDb;
	}

	SaeDetalle getDetalleSae(ApprovalBovedaDto info, String idPO, String idPosicion) {
		SaeDetalleId saeDetalleId = new SaeDetalleId();
		saeDetalleId.setIdSae(info.getFolio());
		saeDetalleId.setIdPO(idPO);
		saeDetalleId.setIdPosicion(idPosicion);

		Optional<SaeDetalle> optional = saeDetalleDao.findById(saeDetalleId);
		SaeDetalle saeDb = null;
		if (optional.isPresent()) {
			saeDb = optional.get();
		}
		return saeDb;
	}

	SaeDetalleRevisado getDetalleSaeRevisado(ApprovalBovedaDto info, String idPO, String idPosicion) {

		SaeDetalleId saeDetalleId = new SaeDetalleId();
		saeDetalleId.setIdSae(info.getFolio());
		saeDetalleId.setIdPO(idPO);
		saeDetalleId.setIdPosicion(idPosicion);

		Optional<SaeDetalleRevisado> optional = saeDetalleRevisadosDao.findById(saeDetalleId);
		SaeDetalleRevisado saeDb = null;
		if (optional.isPresent()) {
			saeDb = optional.get();
		}
		return saeDb;
	}

	@Override

	public Boolean deleteSaeDetalle(String authorization, ApprovalBovedaDto info) {
		infoSaesService.log("Operation Sae");
		Sae sae = getSae(info);
		
		saeDetalleLiberadosService.crearDetalleLiberado(info.getFolio());
		sae.setDateRejectCancela(new Date());
		sae.setMsgRejectCancela(info.getMsgReject());
		User usuario = infoSaesService.obtenerUsuario(authorization);
		sae.setUserRejectCancela(usuario);
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(CatStatusSae.SAE_CANCELADO.getId());
		sae.setStatus(status);
		saeDao.save(sae);

		// Sae saeDB = updateSae(info, authorization,
		// CatStatusSae.SAE_CANCELADO_DEFINITAVAMENTE.getId(), sae);
		Long idFolio = deleteDetalleSae(info.getFolio());
		Optional<Sae> optional = saeDao.findById(info.getFolio());
		boolean enviarTest=true;
		emailServices.envioCorreoCancelacion(
				optional.get().getFolio(),
				optional.get().getIdProveedor(),
				validaNombre(optional.get().getNombreProveedor()).toUpperCase(),
				regresaNombre(optional.get().getUserRejectCancela()),
				regresaNombre(optional.get().getUserApproval()),
				regresaNombre(optional.get().getUserRejectGte()),
				regresaNombre(optional.get().getUserApprovalGte()),
				regresaNombre(optional.get().getUserRejectOver()),
				regresaNombre(optional.get().getUserApprovalOver()),
				regresaNombre(optional.get().getUserRejectLibera()),
				regresaNombre(optional.get().getUserApprovalLibera()),
				enviarTest,
				optional.get().getMsgRejectCancela(),
				optional.get().getMsgRejectGte(),
				optional.get().getMsgRejectOver(),
				optional.get().getMsgRejectLibera(),
				optional.get().getUserApproval()!=null ?
						(optional.get().getUserApproval().getEmail()!=null ? 
						optional.get().getUserApproval().getEmail().trim(): "")
						: "",
						info.getIdStatus().intValue());
		
		infoSaesService.log("Operation Sae Fin ");
		return true;
	}

	@Override
	@Transactional
	public Boolean aprovalRevisados(String authorization, ApprovalBovedaDto info) {

		SaeRevisado saeRevisado = getSaeRevisado(info);
		saeRevisado.setEtaSolicitada(info.getEta());
		saeRevisado.setUnidades(info.getUnidades());
		saeRevisadosDao.save(saeRevisado);

		Sae saeDb = getSae(info);

		SaeRevisado saeRevisadosDb = getSaeRevisado(info);

		saeDb.setEtaSolicitada(info.getEta());
		saeDb.setUnidades(info.getUnidades());
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(CatStatusSae.SAE_APROBADO_LIBERACION.getId());
		saeDb.setStatus(status);
		saeDb.setFolio(saeRevisado.getFolio());
		saeDb.setEta(saeRevisado.getEta());
		saeDb.setEtaSolicitada(saeRevisado.getEtaSolicitada());
		saeDb.setUnidades(saeRevisado.getUnidades());
		saeDb.setTipoDeUnidad(saeRevisado.getTipoDeUnidad());
		saeDb.setCreated(new Date());
		String userName =  JWUtil.extractUsername(authorization.substring(7));
		List<User> users = userDao.findByUserName(userName);
		User user = users.get(0);
		log.info("userId:",user.getId());
		User usuario = infoSaesService.obtenerUsuario(authorization);
		saeDb.setUserModified(usuario);
		saeDb.setTipo(saeRevisado.getTipo());
		saeDb.setIdProveedor(saeRevisado.getIdProveedor());
		saeDb.setStatus(status);
		saeDao.save(saeDb);

		if (saeRevisadosDb.getSaeDetalles() != null && !saeRevisadosDb.getSaeDetalles().isEmpty()) {

			for (int i = 0; i < saeRevisadosDb.getSaeDetalles().size(); i++) {
				SaeDetalleRevisado detalleRevisado = getDetalleSaeRevisado(info,
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPO(),
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPosicion());

				SaeDetalle saeDetalleDB = getDetalleSae(info,
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPO(),
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPosicion());

				Boolean esNuevo = detalleRevisado.getEsNuevo();
				Boolean esBorrado = detalleRevisado.getEsBorrado();
				Boolean esModificado = detalleRevisado.getEsModificado();

				if (esNuevo != null) {
					if (esNuevo) {
						
						if (detalleRevisado!=null) {
							SaeDetalleId saeDetalleId = new SaeDetalleId();
							saeDetalleId.setIdSae(info.getFolio());
							saeDetalleId.setIdPO(saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPO());
							saeDetalleId.setIdPosicion(saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPosicion());
							
							SaeDetalle saeNuevo= new SaeDetalle();
							saeNuevo.setIdDetalle(saeDetalleId);
							
							saeNuevo.setCondicionPago(detalleRevisado.getCondicionPago()!=null?detalleRevisado.getCondicionPago():"");
							saeNuevo.setNumOrdenSecundaria(detalleRevisado.getNumOrdenSecundaria()!=null?detalleRevisado.getNumOrdenSecundaria():"");
							saeNuevo.setCantidadUnidadMedida(detalleRevisado.getCantidadUnidadMedida()!=null?detalleRevisado.getCantidadUnidadMedida():0);
							saeNuevo.setFactorCantidadUnidadMedida(detalleRevisado.getFactorCantidadUnidadMedida()!=null?detalleRevisado.getFactorCantidadUnidadMedida():0);
							saeNuevo
									.setDescripcionComplementoFactura(detalleRevisado.getDescripcionComplementoFactura()!=null?detalleRevisado.getDescripcionComplementoFactura():"");
							saeNuevo.setOrigen(detalleRevisado.getOrigen()!=null?detalleRevisado.getOrigen():"");
							saeNuevo.setTipo(detalleRevisado.getTipo()!=null?detalleRevisado.getTipo():"");
							saeNuevo.setCodigo(detalleRevisado.getCodigo()!=null?detalleRevisado.getCodigo():"");
							saeNuevo.setDescripcion(detalleRevisado.getDescripcion()!=null?detalleRevisado.getDescripcion():"");
							saeNuevo.setPlaneadorProducto(detalleRevisado.getPlaneadorProducto()!=null?detalleRevisado.getPlaneadorProducto():"");
							saeNuevo.setFamilia(detalleRevisado.getFamilia()!=null?detalleRevisado.getFamilia():"");
							saeNuevo.setPlanner(detalleRevisado.getPlanner()!=null?detalleRevisado.getPlanner():"");
							saeNuevo.setCantidad(detalleRevisado.getCantidad()!=null?detalleRevisado.getCantidad():0);
							saeNuevo.setCentro(detalleRevisado.getCentro()!=null?detalleRevisado.getCentro():"");
							saeNuevo.setPicoPlan(detalleRevisado.getPicoPlan()!=null?detalleRevisado.getPicoPlan():0);
							saeNuevo.setPicoReal(detalleRevisado.getPicoReal()!=null?detalleRevisado.getPicoReal():0);;
							saeNuevo.setMonto(detalleRevisado.getMonto()!=null?detalleRevisado.getMonto():0);
							saeNuevo.setFechaPI(detalleRevisado.getFechaPI()!=null?detalleRevisado.getFechaPI():null);
							saeNuevo.setDifPIEvsETA(detalleRevisado.getDifPIEvsETA()!=null?detalleRevisado.getDifPIEvsETA():0);
							saeNuevo.setMaterial(detalleRevisado.getMaterial()!=null?detalleRevisado.getMaterial():"");
							saeNuevo.setPeso(detalleRevisado.getPeso()!=null?detalleRevisado.getPeso():0);
							saeNuevo.setVolumen(detalleRevisado.getVolumen()!=null?detalleRevisado.getVolumen():0);
							saeNuevo.setBo(detalleRevisado.getBo()!=null?detalleRevisado.getBo():0);
							saeNuevo.setOs(detalleRevisado.getOs()!=null?detalleRevisado.getOs():0);
							saeNuevo.setSs(detalleRevisado.getSs()!=null?detalleRevisado.getSs():0);
							saeNuevo.setIdaMin(detalleRevisado.getIdaMin()!=null?detalleRevisado.getIdaMin():0);
							saeNuevo.setFechaEntrega(detalleRevisado.getFechaEntrega()!=null?detalleRevisado.getFechaEntrega():null);
							saeDetalleDao.save(saeNuevo);
						}
						
					}

				}

				if (esBorrado != null) {
					if (esBorrado) {
						saeDetalleDao.deleteDetalleSaeById(info.getFolio(),
								saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPO(),
							saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPosicion());
					}
				}

				if (esModificado != null) {
					if (esModificado) {
						saeDetalleDB.setPeso(detalleRevisado.getPesoModificado());
						saeDetalleDB.setVolumen(detalleRevisado.getVolumenModificado());
						saeDetalleDB.setCantidad(detalleRevisado.getCantidadModificado());
						saeDetalleDao.save(saeDetalleDB);
					}
				}

			}

		}

	if (saeRevisadosDb.getSaeDetalles() != null && !saeRevisadosDb.getSaeDetalles().isEmpty()) {

			for (int i = 0; i < saeRevisadosDb.getSaeDetalles().size(); i++) {
				SaeDetalleRevisado detalleRevisado = getDetalleSaeRevisado(info,
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPO(),
						saeRevisado.getSaeDetalles().get(i).getIdDetalle().getIdPosicion());
				
				saeDetalleRevisadosDao.delete(detalleRevisado);	

			}
			
			saeRevisadosDao.delete(saeRevisadosDb);

		}

		return true;
	}

	@Override
	public Boolean rejectRevisados(String authorization, ApprovalBovedaDto info) {
		log.info("Rechazar en revisado");
		Sae saeDb = getSae(info);
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(CatStatusSae.SAE_ENVIADO_A_REVISION.getId());
		saeDb.setStatus(status);
		saeDb.setConteoRevisado((short) (saeDb.getConteoRevisado()+1));

		saeDb.setDateRejectReview(new Date());
		saeDb.setMsgRejectReview(info.getMsgReject());
		User usuario = infoSaesService.obtenerUsuario(authorization);
		saeDb.setUserRejectReview(usuario);
		saeDao.save(saeDb);

		return true;
	}
	
	private String validaNombre(String cadena) {
		if(cadena!=null) {
			return cadena;
		}
		return "";
	}
	private String regresaNombre(User user) {
		if(user!=null) {
			if(user.getName()!=null) {
				return user.getName(); 
			}
		}
		return "";
	}

	@Override
	public Boolean rejectCancelados(String authorization, ApprovalBovedaDto info) {
		log.info("Rechazar en cancelados");
		Sae saeDb = getSae(info);
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(CatStatusSae.SAE_APROBADO_LIBERACION.getId());
		saeDb.setStatus(status);

		saeDb.setDateRejectCancel(new Date());
		saeDb.setMsgRejectCancel(info.getMsgReject());
		User usuario = infoSaesService.obtenerUsuario(authorization);
		saeDb.setUserRejectCancel(usuario);
		saeDao.save(saeDb);
		return true;
	}

	@Override
	public Boolean cancelacionAprobacion(String authorization, ApprovalBovedaDto info) {
		infoSaesService.log("Operation Sae");
		Sae sae = getSae(info);
		saeDetalleLiberadosService.crearDetalleLiberado(info.getFolio());
		sae.setDateRejectCancela(new Date());
		sae.setMsgRejectCancela(info.getMsgReject());
		User usuario = infoSaesService.obtenerUsuario(authorization);
		sae.setUserRejectCancela(usuario);
		CatSaeStatus status = new CatSaeStatus();
		status.setIdSaeStatus(CatStatusSae.SAE_CANCELADO.getId());
		sae.setStatus(status);
		saeDao.save(sae);

		deleteDetalleSae(info.getFolio());
		Optional<Sae> optional = saeDao.findById(info.getFolio());
		boolean enviarTest=true;
		emailServices.envioCorreoAprobacion(
				optional.get().getFolio(),
				optional.get().getIdProveedor(),
				validaNombre(optional.get().getNombreProveedor()).toUpperCase(),
				regresaNombre(optional.get().getUserRejectCancela()),
				regresaNombre(optional.get().getUserApproval()),
				regresaNombre(optional.get().getUserRejectGte()),
				regresaNombre(optional.get().getUserApprovalGte()),
				regresaNombre(optional.get().getUserRejectOver()),
				regresaNombre(optional.get().getUserApprovalOver()),
				regresaNombre(optional.get().getUserRejectLibera()),
				regresaNombre(optional.get().getUserApprovalLibera()),
				enviarTest,
				optional.get().getMsgRejectCancela(),
				optional.get().getMsgRejectGte(),
				optional.get().getMsgRejectOver(),
				optional.get().getMsgRejectLibera(),
				optional.get().getUserApproval()!=null ?
						(optional.get().getUserApproval().getEmail()!=null ? 
						optional.get().getUserApproval().getEmail().trim(): "")
						: "",
						info.getIdStatus().intValue());
		
		infoSaesService.log("Operation Sae Fin ");
		return true;
	}
	

}
