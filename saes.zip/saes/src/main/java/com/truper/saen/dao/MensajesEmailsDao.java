package com.truper.saen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.MensajesEmails;

public interface MensajesEmailsDao extends JpaRepository<MensajesEmails, Integer> {

}

