package com.truper.saen.service;

import java.util.List;

import com.truper.saen.commons.dto.SapDto;

public interface SapService {
	
	void actualizaPo(List<SapDto> sapDetalle);

}
