package com.truper.saen.service;

import java.util.List;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.dto.SaeDetailSearch;
import com.truper.saen.dto.SaeFilterDto;
import com.truper.saen.dto.SaeZcomZmpDto;

public interface SaeFiltersServices {

	Respuesta filtersByZMP(SaeZcomZmpDto info);
	
	Respuesta filtersByZCOM(SaeZcomZmpDto info);

	Respuesta filtersByGTE(SaeZcomZmpDto info);

	Respuesta filtersByRevisados(SaeZcomZmpDto info);
 
	Respuesta filtersByCancelados(SaeZcomZmpDto info);

	Respuesta filtersByCitas(SaeZcomZmpDto info);

	Respuesta filterSaeDetail(SaeDetailSearch info);
	
	

	List<Sae> getfiltersByFiltersProv(SaeZcomZmpDto info, List<Long> ordenes);

}


