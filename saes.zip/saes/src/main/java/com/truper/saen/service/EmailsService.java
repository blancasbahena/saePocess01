package com.truper.saen.service;

public interface EmailsService {
	void envioCorreoValidar(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject,String userApproval,String userRejectGte,String userApprovalGte,String userRejectOver,String userApprovalOver,
			String userRejectLibera,String userApprovalLibera,boolean enviarTest,
			String msgReject, String msgRejectGte,String msgRejectOver,String msgRejectLibera,String correosGerenteOpcionales, Integer idStatus,boolean aprobar); 
	
	
	
	void envioCorreoCancelacion(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject,String userApproval,String userRejectGte,String userApprovalGte,String userRejectOver,String userApprovalOver,
			String userRejectLibera,String userApprovalLibera,boolean enviarTest,
			String msgReject, String msgRejectGte,String msgRejectOver,String msgRejectLibera,String correosGerenteOpcionales, Integer idStatus); 
	
	
	void envioCorreoAprobacion(Long folio, Integer idProveedor, String nombreProveedor,
			String userReject,String userApproval,String userRejectGte,String userApprovalGte,String userRejectOver,String userApprovalOver,
			String userRejectLibera,String userApprovalLibera,boolean enviarTest,
			String msgReject, String msgRejectGte,String msgRejectOver,String msgRejectLibera,String correosGerenteOpcionales, Integer idStatus); 
}
