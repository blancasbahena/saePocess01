package com.truper.saen.dto;

import java.io.Serializable;

import com.truper.saen.commons.dto.Prioridad;

import lombok.Data;

@Data
public class SaeFilterDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long folio;
	private Integer idProveedor;
	private String proveedor;
	private Integer diasCreacionSae;
	private String etaSolicitada;
	private Integer idaMin;
	private Double bo;
	private Double os;
	private Integer totalCodigos;
	private String tipoUnidad;
	private Integer numeroUnidades;
	private Double monto;
	private String msgRejectGte;
	private String msgReject;
	private String msgRejectOver;
	private Prioridad prioridad;
	private String tipo;
	private Integer diasAprobacionPlaneacion;
	private String centro;
	private String idCentro;
	private Short conteoRevisado;
	private Integer status;
	private String idPO;
}
