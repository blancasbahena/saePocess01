package com.truper.saen.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dto.SaeCentroDto;
import com.truper.saen.dto.SaeDto;
import com.truper.saen.dto.SaeIntDto;
import com.truper.saen.dto.SaePrioridadDto;
import com.truper.saen.dto.SaeZcomZmpDto;
import com.truper.saen.service.SaeServices;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/sae")
public class SaeController {
	
	@Autowired
	private SaeServices saeServices;

	@PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> createSae(@RequestHeader("Authorization") String token, @RequestBody SaeIntDto info){
		
		log.info("[POST /create] | INICIO -  {} - { {} }",JWUtil.extractUsername(token.substring(7)),info);
		Respuesta respuesta = saeServices.createSae(info);
		log.info("[POST /create] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@GetMapping( value = "/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getSaeById(@RequestHeader("Authorization") String token, @PathVariable Long idSae ){
		log.info("[GET /idSae] | INICIO -  {} ",JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getSaeById(idSae);
		log.info("[GET /idSae] | FIN");
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@GetMapping( value = "/status/{idStatus}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getSaeById(@RequestHeader("Authorization") String token,@PathVariable Integer idStatus ){
		log.info("[GET /status/{}] | INICIO -  {} ",idStatus,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getSaesByStatus(idStatus);
		log.info("[GET /status/{}] | FIN",idStatus);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	
	@PutMapping( value = "/rechazar/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> rechazarSae(@RequestHeader("Authorization") String token,@PathVariable Long idSae,@RequestBody  SaeIntDto info ){
		log.info("[PUT /rechazar/{}] | INICIO -  {} - { {} }",idSae,info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.rechazarSae(info);
		log.info("[PUT /rechazar/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	@PutMapping( value = "/cancelar/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> cancelarSae(@RequestHeader("Authorization") String token,@PathVariable Long idSae,@RequestBody  SaeIntDto info ){
		log.info("[PUT /cancelar/{}] | INICIO -  {} - { {} }",idSae,info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.cancelarSae(info);
		log.info("[PUT /cancelar/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	@PutMapping( value = "/actualizar/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> actualizarSae(@RequestHeader("Authorization") String token,@PathVariable Long idSae, @RequestBody  SaeDto info ){
		log.info("[PUT /actualizar/{}] | INICIO -  {} - { {} }",idSae,info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.actualizarSae(info);
		log.info("[PUT /actualizar/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	@GetMapping( value = "/currentSae/{idProveedor}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getCurrentSar(@RequestHeader("Authorization") String token,@PathVariable Integer idProveedor){
		log.info("[GET /currentSae/{}] | INICIO -  {} ",idProveedor,JWUtil.extractUsername(token.substring(7)));
		
		Respuesta respuesta = saeServices.getCurrentSae(idProveedor);
		
		log.info("[GET /currentSae/{}] | FIN",idProveedor);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@GetMapping( value = "/proveedor/{idProveedor}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getSaeByIdProveedor(@RequestHeader("Authorization") String token, @PathVariable Integer idProveedor){
		log.info("[GET /proveedor/{}] | INICIO -  {} ",idProveedor,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getSaeByIdProveedor(idProveedor);
		log.info("[GET /proveedor/{}] | FIN",idProveedor);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@PostMapping( value = "/proveedor/filters", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getSaeByIdProveedor(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		log.info("[GET /proveedor/filters] | INICIO -  {} ",info.getIdProveedor());
		Respuesta respuesta = saeServices.getSaesEstatusbyFilters(info);
		log.info("[GET /proveedor/filters] | FIN",info.getIdProveedor());
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@GetMapping( value = "/proveedor/estatus", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getEstatusFilters(@RequestHeader("Authorization") String token){
		log.info("[GET estatus] | INICIO -  {} ",JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getEstatus();
		log.info("[GET estatus] | FIN");
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@GetMapping( value = "/proveedor/{idProveedor}/pagina/{pagina}/saes/{saes}", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getSaeByIdProveedor(@RequestHeader("Authorization") String token, @PathVariable Integer idProveedor,
			@PathVariable Integer pagina, @PathVariable Integer saes){
		log.info("[GET /proveedor/{}] | INICIO -  {} ",idProveedor,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getSaeByIdProveedor(idProveedor,pagina,saes);
		log.info("[GET /proveedor/{}] | FIN",idProveedor);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	@GetMapping( value = "/proveedor/{idProveedor}/totalSaes", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> getTotalSaesByIdProveedor(@RequestHeader("Authorization") String token, @PathVariable Integer idProveedor){
		log.info("[GET /proveedor/{}/totalSaes] | INICIO -  {} ",idProveedor,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.getTotalSaesByIdProveedor(idProveedor);
		log.info("[GET /proveedor/{}/totalSaes] | FIN",idProveedor);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
		
	}
	
	
	@PutMapping( value = "/actualizarPrioridadSae", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> actualizarPrioridadSae(@RequestHeader("Authorization") String token, @RequestBody  SaePrioridadDto info ){
		log.info("[PUT /actualizar/{}] | INICIO -  {} - { {} }",info.getIdSae(),info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.actualizarPrioridadSae(info);
		log.info("[PUT /actualizar/{}] | FIN",info.getIdSae());
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	@PutMapping( value = "/actualizarCentroSae", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> actualizarCentroSae(@RequestHeader("Authorization") String token, @RequestBody  SaeCentroDto info ){
		log.info("[PUT /actualizar/{}] | INICIO -  {} - { {} }",info.getIdSae(),info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = saeServices.actualizarCentroSae(info);
		log.info("[PUT /actualizar/{}] | FIN",info.getIdSae());
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
}
