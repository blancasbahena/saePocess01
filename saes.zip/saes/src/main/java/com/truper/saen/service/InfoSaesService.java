package com.truper.saen.service;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.User;
import com.truper.saen.dto.ApprovalBovedaDto;

public interface InfoSaesService {
	
	 User obtenerUsuario(String authorization);
	 
	 void log(String operation);
	 
	 Sae getSae(Long id);

}
