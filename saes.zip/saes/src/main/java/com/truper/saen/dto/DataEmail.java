package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataEmail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String proveedor;
	private String planeador;
	private String folio;
	private String comentarioRechazo;
	private String usuarioRechazo;
	
	private boolean debug;
	private String debugToEmails;

}
