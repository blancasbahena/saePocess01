package com.truper.saen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.dto.SaeDetailSearch;
import com.truper.saen.dto.SaeZcomZmpDto;
import com.truper.saen.service.SaeFiltersServices;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/sae-filters")
public class SaeFiltersController {
	
	@Autowired
	private SaeFiltersServices saeFiltersServices;
	
	@PostMapping(value = "/zmp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByZMP(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
			
		log.info("[POST /sae-filters/zmp] | INICIO -  {} ", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByZMP(info);
		log.info("[POST /sae-filters/zmp] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
		
	}
	
	@PostMapping(value = "/zcom", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByZCOM(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		
		log.info("[POST /sae-filters/zcom] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByZCOM(info);
		log.info("[POST /sae-filters/zcom] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PostMapping(value = "/gte", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByGTE(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		
		log.info("[POST /sae-filters/gte] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByGTE(info);
		log.info("[POST /sae-filters/gte] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PostMapping(value = "/revisados", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByRevisados(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		
		log.info("[POST /sae-filters/revisados] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByRevisados(info);
		log.info("[POST /sae-filters/revisados] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PostMapping(value = "/cancelados", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByCancelados(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		
		log.info("[POST /sae-filters/cancelados] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByCancelados(info);
		log.info("[POST /sae-filters/cancelados] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	} 
	@PostMapping(value = "/citas", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filtersByCitas(@RequestHeader("Authorization") String token, @RequestBody SaeZcomZmpDto info){
		
		log.info("[POST /sae-filters/citas] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filtersByCitas(info);
		log.info("[POST /sae-filters/citas] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@PostMapping(value = "/saeDetail", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> filterToViewDetail(@RequestHeader("Authorization") String token, @RequestBody SaeDetailSearch info ){
		log.info("[POST /sae-filters/saeDetail] | INICIO -  {}", info.toString());
		Respuesta respuesta = saeFiltersServices.filterSaeDetail(info);
		log.info("[POST /sae-filters/saeDetail] | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

}
