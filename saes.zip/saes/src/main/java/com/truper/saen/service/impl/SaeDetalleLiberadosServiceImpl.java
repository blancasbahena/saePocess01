package com.truper.saen.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleLiberados;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dao.SaeDetalleDao;
import com.truper.saen.dao.SaeDetalleLiberadosDao;
import com.truper.saen.service.ISaeDetalleLiberadosService;


@Service
public class SaeDetalleLiberadosServiceImpl implements ISaeDetalleLiberadosService{

	@Autowired
	private SaeDetalleLiberadosDao dao;
	@Autowired
	private SaeDetalleDao saeDetalleDao;
	
	@Autowired
	private SaeDao saeDao;
	
	@Override
	public void crearDetalleLiberado(Long folio) {
		
		
		Optional<Sae> saeDB = saeDao.findById(folio);
		
		if (saeDB.isPresent()) {
			for (int i = 0; i < saeDB.get().getSaeDetalles().size(); i++) {
				SaeDetalleId saeDetalleId = new SaeDetalleId();
				saeDetalleId.setIdSae(folio);
				saeDetalleId.setIdPO( saeDB.get().getSaeDetalles().get(i).getIdDetalle().getIdPO());
				saeDetalleId.setIdPosicion( saeDB.get().getSaeDetalles().get(i).getIdDetalle().getIdPosicion());

				Optional<SaeDetalle> optional = saeDetalleDao.findById(saeDetalleId);
				if (optional.isPresent()) {
					SaeDetalle detalleRevisado = optional.get();
					SaeDetalleLiberados saeNuevo= new SaeDetalleLiberados();
					saeNuevo.setIdDetalle(saeDetalleId);
					
					saeNuevo.setCondicionPago(detalleRevisado.getCondicionPago()!=null?detalleRevisado.getCondicionPago():"");
					saeNuevo.setNumOrdenSecundaria(detalleRevisado.getNumOrdenSecundaria()!=null?detalleRevisado.getNumOrdenSecundaria():"");
					saeNuevo.setCantidadUnidadMedida(detalleRevisado.getCantidadUnidadMedida()!=null?detalleRevisado.getCantidadUnidadMedida():0);
					saeNuevo.setFactorCantidadUnidadMedida(detalleRevisado.getFactorCantidadUnidadMedida()!=null?detalleRevisado.getFactorCantidadUnidadMedida():0);
					saeNuevo
							.setDescripcionComplementoFactura(detalleRevisado.getDescripcionComplementoFactura()!=null?detalleRevisado.getDescripcionComplementoFactura():"");
					saeNuevo.setOrigen(detalleRevisado.getOrigen()!=null?detalleRevisado.getOrigen():"");
					saeNuevo.setTipo(detalleRevisado.getTipo()!=null?detalleRevisado.getTipo():"");
					saeNuevo.setCodigo(detalleRevisado.getCodigo()!=null?detalleRevisado.getCodigo():"");
					saeNuevo.setDescripcion(detalleRevisado.getDescripcion()!=null?detalleRevisado.getDescripcion():"");
					saeNuevo.setPlaneadorProducto(detalleRevisado.getPlaneadorProducto()!=null?detalleRevisado.getPlaneadorProducto():"");
					saeNuevo.setFamilia(detalleRevisado.getFamilia()!=null?detalleRevisado.getFamilia():"");
					saeNuevo.setPlanner(detalleRevisado.getPlanner()!=null?detalleRevisado.getPlanner():"");
					saeNuevo.setCantidad(detalleRevisado.getCantidad()!=null?detalleRevisado.getCantidad():0);
					saeNuevo.setCentro(detalleRevisado.getCentro()!=null?detalleRevisado.getCentro():"");
					saeNuevo.setPicoPlan(detalleRevisado.getPicoPlan()!=null?detalleRevisado.getPicoPlan():0);
					saeNuevo.setPicoReal(detalleRevisado.getPicoReal()!=null?detalleRevisado.getPicoReal():0);;
					saeNuevo.setMonto(detalleRevisado.getMonto()!=null?detalleRevisado.getMonto():0);
					saeNuevo.setFechaPI(detalleRevisado.getFechaPI()!=null?detalleRevisado.getFechaPI():null);
					saeNuevo.setDifPIEvsETA(detalleRevisado.getDifPIEvsETA()!=null?detalleRevisado.getDifPIEvsETA():0);
					saeNuevo.setMaterial(detalleRevisado.getMaterial()!=null?detalleRevisado.getMaterial():"");
					saeNuevo.setPeso(detalleRevisado.getPeso()!=null?detalleRevisado.getPeso():0);
					saeNuevo.setVolumen(detalleRevisado.getVolumen()!=null?detalleRevisado.getVolumen():0);
					saeNuevo.setBo(detalleRevisado.getBo()!=null?detalleRevisado.getBo():0);
					saeNuevo.setOs(detalleRevisado.getOs()!=null?detalleRevisado.getOs():0);
					saeNuevo.setSs(detalleRevisado.getSs()!=null?detalleRevisado.getSs():0);
					saeNuevo.setIdaMin(detalleRevisado.getIdaMin()!=null?detalleRevisado.getIdaMin():0);
					saeNuevo.setFechaEntrega(detalleRevisado.getFechaEntrega()!=null?detalleRevisado.getFechaEntrega():null);
					saeNuevo.setUnidadMedidaProducto(detalleRevisado.getUnidadMedidaProducto()!=null?detalleRevisado.getUnidadMedidaProducto():null);
					saeNuevo.setDiasConsumoDisponible(detalleRevisado.getDiasConsumoDisponible() != null ? detalleRevisado.getDiasConsumoDisponible() : null);
					
					dao.save(saeNuevo);
				}
				
			}
		}

	
		
		
	}

}
