package com.truper.saen.service.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.ws.Holder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sap.document.sap.rfc.functions.ZMMINFOBUFFER;
import com.sap.document.sap.rfc.functions.ZMMINFOBUFFER_Service;
import com.sap.document.sap.rfc.functions.ZSDRETURN;
import com.sap.document.sap.rfc.functions.ZSTBUFFEREBELN;
import com.sap.document.sap.rfc.functions.ZTTBUFFEREBELN;
import com.sap.document.sap.rfc.functions.ZTTINFOBUFFERS;
import com.truper.saen.commons.dto.SapDto;
import com.truper.saen.service.SapService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SapServiceImpl implements SapService {

	@Value("${ws.soap.usr}")
	private String USR_WS_SOAP;
	@Value("${ws.soap.pass}")
	private String PASS_WS_SOAP;
	@Value("${ws.soap.urlIndicadores}")
	private String URL_INDICADORES;

	@Override
	public void actualizaPo(List<SapDto> sapDetalle) {

		List<ZSTBUFFEREBELN> item = sapDetalle.stream().map(sarDet -> {
			ZSTBUFFEREBELN po = new ZSTBUFFEREBELN();
			po.setEBELN(sarDet.getIdPO());
			po.setEBELP(sarDet.getIdPosicion());
			return po;
		}).collect(Collectors.toList());

		log.info("## Request SAE with {} elements", item.size());
		java.net.Authenticator.setDefault(new java.net.Authenticator() {
			@Override
			protected java.net.PasswordAuthentication getPasswordAuthentication() {
				return new java.net.PasswordAuthentication(USR_WS_SOAP, PASS_WS_SOAP.toCharArray());
			}
		});
		ZMMINFOBUFFER_Service service;
		try {
			service = new ZMMINFOBUFFER_Service(new URL(URL_INDICADORES));
			ZTTBUFFEREBELN zttbufferebeln = new ZTTBUFFEREBELN();
			Holder<ZTTINFOBUFFERS> eINFOBUFFERS = new Holder<>();
			Holder<ZSDRETURN> eRETURN = new Holder<>();

			zttbufferebeln.getItem().addAll(item);
			ZMMINFOBUFFER function = service.getZMMINFOBUFFER();
			function.zmmINFOBUFFER(zttbufferebeln, new ZTTBUFFEREBELN(), eINFOBUFFERS, eRETURN);

			if (eRETURN.value.getTYPE().equals("S")) {
				log.info(eRETURN.value.getMESSAGE());
			} else {
				log.info("Ocurrio un error");
				log.info(eRETURN.value.getMESSAGE());
			}

			log.info("## SAP Response with {} elements", eINFOBUFFERS.value.getItem().size());

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
