package com.truper.saen.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmailTemplateDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private List<String> cc;
	private String template;
	private List<String> bcc;
	private String sender;
	private String subject;
	private List<String> to;
	@JsonProperty(value = "params")
	private ParametrosEmailDTO params;
}

