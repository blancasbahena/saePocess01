package com.truper.saen.service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.dto.ApprovalBovedaDto;
import com.truper.saen.dto.SaeIntDto;

public interface PlaneacionService {

	Respuesta rejecApprovalSae(String authorization,ApprovalBovedaDto info);
	
	Respuesta rejecRevisadoSae(String authorization,SaeIntDto info);
	
	Respuesta aceptRevisadoSae(String authorization,ApprovalBovedaDto info);
}
