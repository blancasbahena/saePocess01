package com.truper.saen.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dto.ApprovalBovedaDto;
import com.truper.saen.dto.SaeIntDto;
import com.truper.saen.service.GeneralService;
import com.truper.saen.service.InfoSaesService;
import com.truper.saen.service.PlaneacionService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PlaneacionServiceImpl implements PlaneacionService {
	@Autowired 
	private InfoSaesService infoSaesService;
	@Autowired
	private GeneralService generalService;
	@Autowired
	private SaeDao saeDao;
	
	@Override
	public Respuesta rejecApprovalSae(String authorization, ApprovalBovedaDto info) {
		Respuesta resp = new Respuesta();
		log.info("Iniciando proceso de rechazo en pleaneacion");
		User usuario = infoSaesService.obtenerUsuario(authorization);
		CatSaeStatus status = generalService.getEstatus(CatStatusSae.SAE_RECHAZA_PLANEACION);
		Sae sae = infoSaesService.getSae(info.getFolio());
		sae.setStatus(status);
		sae.setUserReject(usuario);
		sae.setMsgReject(info.getMsgReject());
		sae.setDateReject(new Date());
		saeDao.save(sae);
		resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
				"status", "SAE Rechazado");
		resp.setEstado(HttpStatus.OK);
		
		return resp;
	}

	@Override
	public Respuesta rejecRevisadoSae(String authorization, SaeIntDto info) {
		Respuesta resp = new Respuesta();
		log.info("Iniciando proceso de rechazo en pleaneacion");
		User usuario = infoSaesService.obtenerUsuario(authorization);
		CatSaeStatus status=null;
		Sae sae = infoSaesService.getSae(info.getIdSae());
		Long statusActual= sae.getStatus().getEstatus()!=null?sae.getStatus().getIdSaeStatus().intValue():0l;
		
		if (statusActual==CatStatusSae.SAE_PENDIENTE_APROBACION.getId()) {			
			 status = generalService.getEstatus(CatStatusSae.SAE_RECHAZA_PLANEACION);
		}else {
			if (statusActual==CatStatusSae.SAE_ENVIADO_A_REVISION.getId()) {			
				 status = generalService.getEstatus(CatStatusSae.SAE_APROBADO_LIBERACION);
			}
		}
		
		sae.setStatus(status);
		sae.setUserReject(usuario);
		sae.setMsgReject(info.getComentarios());
		sae.setDateReject(new Date());
		saeDao.save(sae);
		resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
				"status", "SAE Rechazado");
		resp.setEstado(HttpStatus.OK);
		
		return resp;
	}

	@Override
	public Respuesta aceptRevisadoSae(String authorization, ApprovalBovedaDto info) {
		Respuesta resp = new Respuesta();
		log.info("Iniciando proceso de rechazo en pleaneacion");
		User usuario = infoSaesService.obtenerUsuario(authorization);
		CatSaeStatus status=null;
		if (info.getIdStatus()==CatStatusSae.SAE_PENDIENTE_APROBACION.getId()) {			
			 status = generalService.getEstatus(CatStatusSae.SAE_REVISADO_PENDIENTE_APROBACION);
		}else {
			if (info.getIdStatus()==CatStatusSae.SAE_ENVIADO_A_REVISION.getId()) {			
				 status = generalService.getEstatus(CatStatusSae.SAE_REVISADO_PENDIENTE_APROBACION_G);
			}
		}
		Sae sae = infoSaesService.getSae(info.getFolio());
		sae.setStatus(status);
		sae.setUserReject(usuario);
		sae.setMsgReject(info.getMsgReject());
		sae.setDateReject(new Date());
		saeDao.save(sae);
		return resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
				sae.getFolio());
	}

}
