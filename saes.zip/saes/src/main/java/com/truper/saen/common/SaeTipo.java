package com.truper.saen.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SaeTipo {
	
	TIPO_ZCOM('N',"SAE ZCOM"),
	TIPO_ZMP('M',"SAE ZMP");
	
	private char tipo;
	private String descripcion;
	
}
