package com.truper.saen.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.entities.CatCentro;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeCitas;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.dao.CatPrioridadesDao;
import com.truper.saen.dao.StatusDao;
import com.truper.saen.dto.CatalogsPrioridad;
import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.dto.ResponseCatalogsProveedorDTO;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.dto.SaeCitasDto;
import com.truper.saen.dto.SaeDetailSearch;
import com.truper.saen.dto.SaeFilterDto;
import com.truper.saen.dto.SaeFilterSearchDto;
import com.truper.saen.dto.SaeRevisadosCanceladosResponseDto;
import com.truper.saen.dto.SaeZcomZmpDto;
import com.truper.saen.feign.CatalogsFeignClient;
import com.truper.saen.service.SaeFiltersServices;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SaeFiltersServicesImpl implements SaeFiltersServices {

	@Autowired
	private EntityManager em;

	@Autowired
	private CatPrioridadesDao catPrioridadesDao;
	
	@Autowired
	private CatalogsFeignClient catalogsFeignClient;
	
	@Value("${catalogs.username}")
	private String catUsername;

	@Value("${catalogs.password}")
	private String catPassword;
	
	@Autowired
	private  StatusDao statusDao;
	
	private List<CatalogsPrioridad> prioridades = new ArrayList<>();

	private static Predicate addEstatus(CriteriaBuilder cb, Root<Sae> news, List<Integer> status) {
		In<Object> in = cb.in(news.get("status"));

		for (Integer id : status) {
			in = in.value(id);
		}

		return in;
	}
	
	private static Predicate addProvedor(CriteriaBuilder cb, Root<Sae> news, Integer idProv) {
		In<Object> in = cb.in(news.get("idProveedor"));
			in = in.value(idProv);

		return in;
	}

	private static Predicate addEstatusRevisados(CriteriaBuilder cb, Root<SaeRevisado> news, List<Integer> status) {
		In<Object> in = cb.in(news.get("sae").get("status"));

		for (Integer id : status) {
			in = in.value(id);
		}

		return in;
	}

	@Override
	public Respuesta filtersByZMP(SaeZcomZmpDto info) {

		log.info("[Service /filtersByZMP] | INICIO -  {} - FECHA / HORA - {} ", info.toString(), Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);

		Predicate predicateSae = null;

		predicateSae = cb.equal(rootSae.get("tipo"), "M");

		if (info.getStatus() != null) {
			Predicate predicate = addEstatus(cb, rootSae, info.getStatus());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

	/*	if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		} */

		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByZMP");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByZMP - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeFilterDto> saeFiltersZMP = new ArrayList<>();

			
			
			RequestToken requestToken = new RequestToken();
			requestToken.setPassword(catPassword);
			requestToken.setUsername(catUsername);
			ResponseTokenDTO token = catalogsFeignClient.getToken(requestToken);
			if (token != null) {
			
				ResponseCatalogsPrioridadDTO response = catalogsFeignClient.getPrioridadByTipo("M","Bearer " + token.getData().getToken() );
				
				if(  response != null) {
					prioridades = response.getData().getPrioridad();
				}
				
			}
			
			result.forEach(obj -> {

				Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getIdaMin();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);
				
				Integer diasMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getDiasConsumoDisponible();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);

				Double bo = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getBo();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double os = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getOs();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double monto = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getMonto();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				SaeFilterDto saeFilterDto = new SaeFilterDto();
				if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
					saeFilterDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
				}
				saeFilterDto.setFolio(obj.getFolio());
				saeFilterDto.setIdProveedor(obj.getIdProveedor());
				saeFilterDto.setProveedor(obj.getNombreProveedor());
				saeFilterDto.setDiasCreacionSae(Fechas.numeroDiasEntreDosFechas(obj.getCreated(), new Date()));
				saeFilterDto.setEtaSolicitada(
						obj.getEtaSolicitada() != null ? Fechas.getDateToString(obj.getEtaSolicitada()) : "");
				saeFilterDto.setIdaMin(idaMin);
				saeFilterDto.setBo(bo);
				saeFilterDto.setOs(os);
				saeFilterDto.setTipo(obj.getTipo());
				saeFilterDto.setMsgRejectGte(obj.getMsgRejectGte());
				saeFilterDto.setTotalCodigos(obj.getTotalCodigos());
				saeFilterDto.setTipoUnidad(obj.getTipoDeUnidad() != null ? obj.getTipoDeUnidad().getTipoUnidad() : "");
				saeFilterDto.setNumeroUnidades(obj.getUnidades());
				saeFilterDto.setMonto(monto);
				//saeFilterDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), saeFilterDto.getIdaMin()));
				saeFilterDto.setPrioridad(getPrioridadZMP(obj.getPrioridades(), diasMin, prioridades));
				saeFilterDto.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
				saeFilterDto.setCentro(obj.getCentro());
				saeFiltersZMP.add(saeFilterDto);

			});

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersZMP", saeFiltersZMP);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta filtersByZCOM(SaeZcomZmpDto info) {

		log.info("[Service /filtersByZCOM] | INICIO -  {} - FECHA / HORA - {} ", info.toString(),
				Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);

		Predicate predicateSae = null;

		predicateSae = cb.equal(rootSae.get("tipo"), "N");

		if (info.getStatus() != null) {
			Predicate predicate = addEstatus(cb, rootSae, info.getStatus());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		/* if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		} */
		
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByZCOM");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByZCOM - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeFilterDto> saeFiltersZCOM = new ArrayList<>();

			result.forEach(obj -> {

				Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getIdaMin();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);

				Double bo = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getBo();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double os = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getOs();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double monto = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getMonto();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();
				
				SaeFilterDto saeFilterDto = new SaeFilterDto();
				if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
					saeFilterDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
				}
				saeFilterDto.setFolio(obj.getFolio());
				saeFilterDto.setIdProveedor(obj.getIdProveedor());
				saeFilterDto.setProveedor(obj.getNombreProveedor());
				saeFilterDto.setDiasCreacionSae(Fechas.numeroDiasEntreDosFechas(obj.getCreated(), new Date()));
				saeFilterDto.setEtaSolicitada(
						obj.getEtaSolicitada() != null ? Fechas.getDateToString(obj.getEtaSolicitada()) : "");
				saeFilterDto.setIdaMin(idaMin);
				saeFilterDto.setBo(bo);
				saeFilterDto.setOs(os);
				saeFilterDto.setTotalCodigos(obj.getTotalCodigos());
				saeFilterDto.setTipoUnidad(obj.getTipoDeUnidad() != null ? obj.getTipoDeUnidad().getTipoUnidad() : "");
				saeFilterDto.setNumeroUnidades(obj.getUnidades());
				saeFilterDto.setMonto(monto);
				saeFilterDto.setMsgRejectGte(obj.getMsgRejectGte());
				saeFilterDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), saeFilterDto.getIdaMin()));
				saeFilterDto.setTipo(obj.getTipo());
				saeFilterDto.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
				saeFilterDto.setCentro(obj.getCentro());
				saeFiltersZCOM.add(saeFilterDto);

			});

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersZCOM", saeFiltersZCOM);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta filtersByGTE(SaeZcomZmpDto info) {

		log.info("[Service /filtersByGTE] | INICIO -  {} - FECHA / HORA - {} ", info.toString(), Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		List<SaeFilterDto> saeFiltersGTE = getfiltersByGTE(info);

		if (saeFiltersGTE == null || saeFiltersGTE.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersGTE", saeFiltersGTE);
			resp.setEstado(HttpStatus.OK);
		}
		return resp;
	}
	
	@Override
	public List<Sae> getfiltersByFiltersProv(SaeZcomZmpDto info,List<Long> ordenes) {

		log.info("[Service /filtersByGTE] | INICIO -  {} - FECHA / HORA - {} ", info.toString(), Fechas.getHoraLogeo());

		List<SaeFilterDto> saeFiltersGTE = new ArrayList<>();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);

		Predicate predicateSae = addProvedor(cb, rootSae, info.getIdProveedor());

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		if (info.getEstatus() != null) {
			Optional<CatSaeStatus> estatus =statusDao.findById(info.getEstatus());
			Predicate predicate = cb.equal(rootSae.get("status"), estatus.get());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		if (info.getCodigo() != null) {
			Predicate predicate = cb.equal(detalle.get("codigo"), info.getCodigo());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		if (info.getItem() != 0) {
			Predicate predicate = cb.equal(detalle.get("codigo"), info.getItem());
			predicateSae = cb.and(predicateSae, predicate);
		}
		
		/*if (ordenes != null) {
			/*In<Object> in = cb.in(detalle.get("idDetalle").get("idPO"));

			for (Long id : ordenes) {
				in = in.value(id);
			}*
			Expression<String> parentExpression = detalle.get("idDetalle").get("idPO");
			Predicate predicate = parentExpression.in(ordenes);//cb.equal(detalle.get("idDetalle").get("idPO"), ordenes);
			predicateSae = cb.and(predicateSae, predicate);
		}*/

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByGTE");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByGTE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return result;
	}

	private List<SaeFilterDto> getfiltersByGTE(SaeZcomZmpDto info) {

		log.info("[Service /filtersByGTE] | INICIO -  {} - FECHA / HORA - {} ", info.toString(), Fechas.getHoraLogeo());

		List<SaeFilterDto> saeFiltersGTE = new ArrayList<>();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);

		Predicate predicateSae = addEstatus(cb, rootSae, info.getStatus());

		if (info.getTipo() != null) {
			Predicate predicate = cb.equal(rootSae.get("tipo"), info.getTipo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		/* if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		} */
		
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getCodigo() != null) {
			Predicate predicate = cb.equal(detalle.get("codigo"), info.getCodigo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByGTE");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByGTE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {
			saeFiltersGTE = null;
		} else {

			for (Sae obj : result) {

				Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getIdaMin();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);

				Double bo = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getBo();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double os = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getOs();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double monto = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getMonto();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				SaeFilterDto saeFilterDto = new SaeFilterDto();
				if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
					saeFilterDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
				}
				saeFilterDto.setFolio(obj.getFolio());
				saeFilterDto.setIdProveedor(obj.getIdProveedor());
				saeFilterDto.setProveedor(obj.getNombreProveedor());
				saeFilterDto.setDiasCreacionSae(Fechas.numeroDiasEntreDosFechas(obj.getCreated(), new Date()));
				saeFilterDto.setEtaSolicitada(
						obj.getEtaSolicitada() != null ? Fechas.getDateToString(obj.getEtaSolicitada()) : "");
				saeFilterDto.setIdaMin(idaMin);
				saeFilterDto.setBo(bo);
				saeFilterDto.setMsgReject(obj.getMsgReject());
				saeFilterDto.setMsgRejectGte(obj.getMsgRejectGte());
				saeFilterDto.setMsgRejectOver(obj.getMsgRejectOver());
				saeFilterDto.setOs(os);
				saeFilterDto.setTotalCodigos(obj.getTotalCodigos());
				saeFilterDto.setTipoUnidad(obj.getTipoDeUnidad() != null ? obj.getTipoDeUnidad().getTipoUnidad() : "");
				saeFilterDto.setNumeroUnidades(obj.getUnidades());
				saeFilterDto.setMonto(monto);
				saeFilterDto.setTipo(obj.getTipo());
				saeFilterDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), saeFilterDto.getIdaMin()));
				saeFilterDto.setDiasAprobacionPlaneacion(obj.getDateApproval() != null
						? Fechas.numeroDiasEntreDosFechas(obj.getDateApproval(), new Date())
						: 0);
				//saeFilterDto.setCentro(obj.getCentros() != null ? obj.getCentros().getDescripcion() : "");
				saeFilterDto.setIdCentro(obj.getCentros() != null ? obj.getCentros().getIdCentro() : "");
				saeFilterDto.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
				saeFilterDto.setStatus(obj.getStatus() != null ? obj.getStatus().getIdSaeStatus() : 0);
				saeFilterDto.setCentro(obj.getCentro());
				saeFiltersGTE.add(saeFilterDto);

				if (obj.getStatus().getIdSaeStatus() == CatStatusSae.SAE_RECHAZADO_LIBERACION.getId()) {
					saeFilterDto.setMsgRejectOver(obj.getMsgRejectLibera());
				}

			}
			;
		}
		return saeFiltersGTE;
	}

	@Override
	public Respuesta filtersByRevisados(SaeZcomZmpDto info) {

		log.info("[Service /filtersByRevisados] | INICIO -  {} - FECHA / HORA - {} ", info.toString(),
				Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SaeRevisado> criteriaSae = cb.createQuery(SaeRevisado.class);
		Root<SaeRevisado> rootSae = criteriaSae.from(SaeRevisado.class);

		Join<SaeRevisado, SaeDetalleRevisado> detalle = rootSae.join("saeDetalles", JoinType.LEFT);
		// Join<SaeRevisado, Sae> infoSae = rootSae.join("sae", JoinType.LEFT);
		// Join<Sae, SaeDetalle> detalles = rootSae.join("saeDetalles", JoinType.LEFT);

		//

		Predicate predicateSae = addEstatusRevisados(cb, rootSae, info.getStatus());

		if (info.getTipo() != null) {
			Predicate predicate = cb.equal(rootSae.get("tipo"), info.getTipo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		/* if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		} */
		
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<SaeRevisado> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByRevisados");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<SaeRevisado> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByRevisados - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		List<SaeFilterDto> saeNormal = getfiltersByGTE(info);
		if (result.isEmpty() && (saeNormal == null || saeNormal.isEmpty())) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeRevisadosCanceladosResponseDto> saeFiltersRevisados = new ArrayList<>();
			if (!result.isEmpty()) {
				result.forEach(obj -> {

					Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
						try {
							return y.getIdaMin();
						} catch (Exception e) {
							return 0;
						}
					}).min().orElse(0);

					SaeRevisadosCanceladosResponseDto saeRevisadosCanceladosResponseDto = new SaeRevisadosCanceladosResponseDto();
					if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
						saeRevisadosCanceladosResponseDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
					}
					saeRevisadosCanceladosResponseDto.setFolio(obj.getFolio());
					saeRevisadosCanceladosResponseDto.setIdProveedor(obj.getIdProveedor());
					saeRevisadosCanceladosResponseDto.setProveedor(obj.getSae().getNombreProveedor());
					saeRevisadosCanceladosResponseDto
							.setEta(obj.getEta() != null ? Fechas.getDateToString(obj.getEta()) : "");
					saeRevisadosCanceladosResponseDto.setIdaMin(idaMin);
					saeRevisadosCanceladosResponseDto.setTotalCodigos(obj.getSae().getTotalCodigos());
					saeRevisadosCanceladosResponseDto.setNumeroUnidades(obj.getUnidades());
					saeRevisadosCanceladosResponseDto.setTipo(obj.getTipo());
					saeRevisadosCanceladosResponseDto.setPrioridad(getPrioridad(obj.getSae().getPrioridades(),
							obj.getTipo(), saeRevisadosCanceladosResponseDto.getIdaMin()));
					saeRevisadosCanceladosResponseDto.setConteoRevisado(
							obj.getSae().getConteoRevisado() != null ? obj.getSae().getConteoRevisado() : 0);
					saeRevisadosCanceladosResponseDto.setMsgCancelaLibera(obj.getSae().getMsgRejectOver());
					saeRevisadosCanceladosResponseDto.setTipoUnidad(obj.getTipoDeUnidad().getTipoUnidad());
					saeRevisadosCanceladosResponseDto.setIdStatus(obj.getSae().getStatus()!= null ? obj.getSae().getStatus().getIdSaeStatus() : 0);
					saeRevisadosCanceladosResponseDto.setCentro(obj.getCentro());
					switch (obj.getSae().getStatus().getIdSaeStatus()) {
					case 14:
					case 17:
						saeRevisadosCanceladosResponseDto.setMsgRechazo(obj.getSae().getMsgRejectReview());
						break;
					}
					saeRevisadosCanceladosResponseDto.setEstatus(obj.getSae().getStatus().getIdSaeStatus());
					
					saeFiltersRevisados.add(saeRevisadosCanceladosResponseDto);

				});
			}
			/*
			if (saeNormal != null && !saeNormal.isEmpty()) {
				for (SaeFilterDto sae : saeNormal) {
					SaeRevisadosCanceladosResponseDto saeRevisadosCanceladosResponseDto = new SaeRevisadosCanceladosResponseDto();
					saeRevisadosCanceladosResponseDto.setFolio(sae.getFolio());
					saeRevisadosCanceladosResponseDto.setIdProveedor(sae.getIdProveedor());
					saeRevisadosCanceladosResponseDto.setProveedor(sae.getProveedor());
					saeRevisadosCanceladosResponseDto.setEta(sae.getEtaSolicitada());
					saeRevisadosCanceladosResponseDto.setIdaMin(sae.getIdaMin());
					saeRevisadosCanceladosResponseDto.setTotalCodigos(sae.getTotalCodigos());
					saeRevisadosCanceladosResponseDto.setNumeroUnidades(sae.getNumeroUnidades());
					saeRevisadosCanceladosResponseDto.setTipo(sae.getTipo());
					saeRevisadosCanceladosResponseDto.setPrioridad(sae.getPrioridad());
					saeRevisadosCanceladosResponseDto.setConteoRevisado(sae.getConteoRevisado());
					saeRevisadosCanceladosResponseDto.setMsgCancelaLibera(sae.getMsgRejectOver());
					saeRevisadosCanceladosResponseDto.setTipoUnidad(sae.getTipoUnidad());
					saeRevisadosCanceladosResponseDto.setMsgRechazo(sae.getMsgReject());

					saeFiltersRevisados.add(saeRevisadosCanceladosResponseDto);

				}

			}
			
			List<SaeRevisadosCanceladosResponseDto> saeFiltersRevisadosF = saeFiltersRevisados.stream().distinct().collect(Collectors.toList());
			 */
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersRevisados", saeFiltersRevisados);

			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta filtersByCancelados(SaeZcomZmpDto info) {

		log.info("[Service /filtersByCancelados] | INICIO -  {} - FECHA / HORA - {} ", info.toString(),
				Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);

		Predicate predicateSae = addEstatus(cb, rootSae, info.getStatus());

		if (info.getTipo() != null) {
			Predicate predicate = cb.equal(rootSae.get("tipo"), info.getTipo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

   		/* if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}*/
		
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByCancelados");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByCancelados - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeRevisadosCanceladosResponseDto> saeFiltersCancelados = new ArrayList<>();

			result.forEach(obj -> {

				Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getIdaMin();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);

				SaeRevisadosCanceladosResponseDto saeRevisadosCanceladosResponseDto = new SaeRevisadosCanceladosResponseDto();
				if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
					saeRevisadosCanceladosResponseDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
				}
				saeRevisadosCanceladosResponseDto.setFolio(obj.getFolio());
				saeRevisadosCanceladosResponseDto.setIdProveedor(obj.getIdProveedor());
				saeRevisadosCanceladosResponseDto.setProveedor(obj.getNombreProveedor());
				saeRevisadosCanceladosResponseDto
						.setEta(obj.getEtaSolicitada() != null ? Fechas.getDateToString(obj.getEtaSolicitada())
								: Fechas.getDateToString(obj.getEta()));
				saeRevisadosCanceladosResponseDto.setIdaMin(idaMin);
				saeRevisadosCanceladosResponseDto.setTotalCodigos(obj.getTotalCodigos());
				saeRevisadosCanceladosResponseDto.setNumeroUnidades(obj.getUnidades());
				saeRevisadosCanceladosResponseDto.setTipo(obj.getTipo());
				saeRevisadosCanceladosResponseDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(),
						saeRevisadosCanceladosResponseDto.getIdaMin()));
				saeRevisadosCanceladosResponseDto.setMsgCancelaLibera(obj.getMsgCancelaLibera());
				saeRevisadosCanceladosResponseDto
						.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
				saeRevisadosCanceladosResponseDto.setMsgCancelaCita(obj.getMsgCancelaCita());
				saeRevisadosCanceladosResponseDto.setCentro(obj.getCentro());
				saeFiltersCancelados.add(saeRevisadosCanceladosResponseDto);

			});

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersCancelados", saeFiltersCancelados);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	@Override
	public Respuesta filtersByCitas(SaeZcomZmpDto info) {

		log.info("[Service /filtersByCitas] | INICIO -  {} - FECHA / HORA - {} ", info.toString(),
				Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);
		Join<Sae, SaeCitas> citas = rootSae.join("cita", JoinType.LEFT);

		Predicate predicateSae = null;

		predicateSae = cb.and(addEstatus(cb, rootSae, info.getStatus()), cb.equal(citas.get("idStatus"), 0));

		if (info.getTipo() != null) {
			Predicate predicate = cb.equal(rootSae.get("tipo"), info.getTipo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIda() != null) {
			Predicate predicate = cb.equal(detalle.get("idaMin"), info.getIda());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getIdProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getIdProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		/* if (info.getIdCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centros").get("idCentro"), info.getIdCentro());
			predicateSae = cb.and(predicateSae, predicate);
		} */
		
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(rootSae.get("centro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEtaSolicitada());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta Solicitada>");
			}

			Predicate predicate = cb.equal(rootSae.get("etaSolicitada"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPlaneador() != null) {
			Predicate predicate = cb.equal(detalle.get("planner"), info.getPlaneador());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filtersByCitas");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filtersByCitas - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeCitasDto> saeFiltersCitas = new ArrayList<>();

			result.forEach(obj -> {

				Integer idaMin = obj.getSaeDetalles().stream().mapToInt(y -> {
					try {
						return y.getIdaMin();
					} catch (Exception e) {
						return 0;
					}
				}).min().orElse(0);

				Double bo = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getBo();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				Double os = obj.getSaeDetalles().stream().mapToDouble(y -> {
					try {
						return y.getOs();
					} catch (Exception e) {
						return 0.0;
					}
				}).sum();

				SaeCitasDto saeCitasDto = new SaeCitasDto();
				if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
					saeCitasDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
				}
				saeCitasDto.setFolio(obj.getFolio());
				saeCitasDto.setIdProveedor(obj.getIdProveedor());
				saeCitasDto.setProveedor(obj.getNombreProveedor());
				saeCitasDto.setDiasParaEta(
						obj.getEta() != null ? Fechas.numeroDiasEntreDosFechas(new Date(), obj.getEta()) + 1 : 0);
				saeCitasDto.setEta(obj.getEta() != null ? Fechas.getDateToString(obj.getEta()) : "");
				saeCitasDto.setIdaMin(idaMin);
				saeCitasDto.setBo(bo);
				saeCitasDto.setEtaSolicitada(
						obj.getEtaSolicitada() != null ? Fechas.getDateToString(obj.getEtaSolicitada()) : "");
				saeCitasDto.setOs(os);
				saeCitasDto.setTotalCodigos(obj.getTotalCodigos());
				saeCitasDto.setTipoUnidad(obj.getTipoDeUnidad() != null ? obj.getTipoDeUnidad().getTipoUnidad() : "");
				saeCitasDto.setNumeroUnidades(obj.getUnidades());
				saeCitasDto.setTipo(obj.getTipo());
				//saeCitasDto.setCentro(obj.getCentros() != null ? obj.getCentros().getDescripcion() : "");
				saeCitasDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), saeCitasDto.getIdaMin()));
				saeCitasDto.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
				saeFiltersCitas.add(saeCitasDto);
				saeCitasDto.setCentro(obj.getCentro());
			});

			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filtersCitas", saeFiltersCitas);
			resp.setEstado(HttpStatus.OK);
		}

		return resp;
	}

	 Prioridad getPrioridad(CatPrioridades catPrioridades, String tipo, Integer idaMin) {

		Prioridad prioridad = new Prioridad();

		if (catPrioridades != null) {
			prioridad.setIdPrioridad(catPrioridades.getIdPrioridad());
			prioridad.setDescripcion(catPrioridades.getDescripcion());
			prioridad.setColor(catPrioridades.getColor());
			return prioridad;
		}

		Optional<CatPrioridades> catPrioridad = null;

		if (tipo == null) {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
			return prioridad;
		}

		if (tipo.equals("M") && idaMin <= 15) {
			catPrioridad = catPrioridadesDao.findById(1);
		} else if (tipo.equals("M") && (idaMin >= 16 && idaMin <= 30)) {
			catPrioridad = catPrioridadesDao.findById(2);
		} else if (tipo.equals("M") && (idaMin >= 31 && idaMin <= 45)) {
			catPrioridad = catPrioridadesDao.findById(3);
		} else if (tipo.equals("M") && idaMin >= 46) {
			catPrioridad = catPrioridadesDao.findById(4);
		} else if (tipo.equals("N") && idaMin <= 10) {
			catPrioridad = catPrioridadesDao.findById(5);
		} else if (tipo.equals("N") && (idaMin >= 11 && idaMin <= 30)) {
			catPrioridad = catPrioridadesDao.findById(6);
		} else if (tipo.equals("N") && (idaMin > 30)) {
			catPrioridad = catPrioridadesDao.findById(7);
		}

		if (catPrioridad.isPresent()) {
			prioridad.setIdPrioridad(catPrioridad.get().getIdPrioridad());
			prioridad.setDescripcion(catPrioridad.get().getDescripcion());
			prioridad.setColor(catPrioridad.get().getColor());
		} else {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
		}
		return prioridad;
	}

	private Prioridad getPrioridadZMP(CatPrioridades catPrioridades, Integer valor, List<CatalogsPrioridad> prioridades) {
		
		Prioridad prioridad = new Prioridad();

		if (catPrioridades != null) {
			prioridad.setIdPrioridad(catPrioridades.getIdPrioridad());
			prioridad.setDescripcion(catPrioridades.getDescripcion());
			prioridad.setColor(catPrioridades.getColor());
			return prioridad;
		}
		
		for (CatalogsPrioridad catprioridad : prioridades) {
			if( valor >= catprioridad.getRangoMin() && valor <= catprioridad.getRangoMax() ) {
				prioridad.setColor(catprioridad.getColor());
				prioridad.setDescripcion(catprioridad.getDescripcion());
				prioridad.setIdPrioridad(catprioridad.getIdPrioridad());
				return prioridad;
			}
		}
		
		if( prioridad.getIdPrioridad() == null ) {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
		}
		
		return prioridad;
	}
	 
	@Override
	public Respuesta filterSaeDetail(SaeDetailSearch info) {

		log.info("[Service /filterSaeDetail] | INICIO -  {} - FECHA / HORA - {} ", info.toString(),
				Fechas.getHoraLogeo());

		Respuesta resp = new Respuesta();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Sae> criteriaSae = cb.createQuery(Sae.class);
		Root<Sae> rootSae = criteriaSae.from(Sae.class);

		Join<Sae, SaeDetalle> detalle = rootSae.join("saeDetalles", JoinType.LEFT);
		Join<Sae, CatCentro> centros = rootSae.join("centros", JoinType.LEFT);

		Predicate predicateSae = null;

		if (info.getTipoSar() != null && info.getTipoSar() == 1) {
			predicateSae = cb.equal(rootSae.get("tipo"), "M");
			Predicate predicate = cb.equal(rootSae.get("tipo"), "N");
			predicateSae = cb.or(predicateSae, predicate);

		} else if (info.getTipoSar() != null && info.getTipoSar() == 2) {
			predicateSae = cb.equal(rootSae.get("tipo"), "N");
		} else {

			predicateSae = cb.equal(rootSae.get("tipo"), "M");
		}

		if (info.getFolio() != null) {
			Predicate predicate = cb.equal(rootSae.get("folio"), info.getFolio());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getPo() != null) {
			Predicate predicate = cb.equal(detalle.get("idDetalle").get("idPO"), info.getPo());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getMaterial() != null) {
			Predicate predicate = cb.equal(detalle.get("material"), info.getMaterial());
			predicateSae = cb.and(predicateSae, predicate);
		}
		if (info.getCentro() != null) {
			Predicate predicate = cb.equal(centros.get("idCentro"), info.getCentro());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getProveedor() != null) {
			Predicate predicate = cb.equal(rootSae.get("idProveedor"), info.getProveedor());
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getEta() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = formatter.parse(info.getEta());
			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta>");
			}

			Predicate predicate = cb.equal(rootSae.get("eta"), date);
			predicateSae = cb.and(predicateSae, predicate);
		}

		if (info.getSucursal() != null) {
			Predicate predicate = cb.equal(centros.get("idCentro"), info.getSucursal());
			predicateSae = cb.and(predicateSae, predicate);
		}

		criteriaSae.select(rootSae).where(predicateSae).distinct(true);
		TypedQuery<Sae> query = em.createQuery(criteriaSae);

		Date inicio = new Date();
		log.info("[INICIO - SELECT] | filterSaeDetail");
		log.info("[QUERY] | {} ", query.unwrap(org.hibernate.Query.class).getQueryString());
		List<Sae> result = em.createQuery(criteriaSae).getResultList();
		Date fin = new Date();
		log.info("[FIN - SELECT] | filterSaeDetail - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (result.isEmpty()) {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información por filtros no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		} else {

			List<SaeFilterSearchDto> saeDetailsFilters = new ArrayList<>();
			result.forEach(obj -> {

				saeDetailsFilters.add(searchDetailMapDaoToDto(obj));

			});
			List<SaeFilterSearchDto> saeDetailsFiltersPriority = null;
			if (info.getPrioridad() != null) {
				saeDetailsFiltersPriority = saeDetailsFilters.stream()
						.filter(sae -> sae.getPrioridad().getIdPrioridad() == info.getPrioridad())
						.collect(Collectors.toList());
			} else {
				saeDetailsFiltersPriority = saeDetailsFilters;
			}
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					"filterSaeDetail", saeDetailsFiltersPriority);
			resp.setEstado(HttpStatus.OK);
		}
		return resp;
	}

	private Integer calcularIdaMin(List<SaeDetalle> obj) {
		return obj.stream().mapToInt(y -> {
			try {
				return y.getIdaMin();
			} catch (Exception e) {
				return 0;
			}
		}).min().orElse(0);
	}

	private SaeFilterSearchDto searchDetailMapDaoToDto(Sae obj) {
		if (obj == null)
			return null;
		SaeFilterSearchDto saeFilterDto = new SaeFilterSearchDto();
		saeFilterDto.setIdStatus(obj.getStatus().getIdSaeStatus());
		saeFilterDto.setFolio(obj.getFolio());
		saeFilterDto.setConteoRevisado(obj.getConteoRevisado() != null ? obj.getConteoRevisado() : 0);
		saeFilterDto.setIdProveedor(obj.getIdProveedor());
		saeFilterDto.setTipo(obj.getTipo());
		if (obj.getCentros() != null)
			saeFilterDto.setCentro(obj.getCentros().getIdCentro());
		if (obj.getStatus().getEstatus() != null)
			saeFilterDto.setStatus(obj.getStatus().getEstatus());
		saeFilterDto.setNombreProveedor(obj.getNombreProveedor());
		if (obj.getEta() != null || obj.getEtaSolicitada() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				if (obj.getEtaSolicitada() != null) {
					date = formatter.parse(Fechas.getDateToString(obj.getEtaSolicitada()));
				} else if (obj.getEta() != null) {
					date = formatter.parse(Fechas.getDateToString(obj.getEta()));
				} else {
					date = null;
				}

			} catch (ParseException e) {
				log.info("Error al intentar convertir la fecha <Eta>");
			}
			saeFilterDto.setEta(date);
		}
		if (obj.getIdaMin() != null) {
			saeFilterDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), obj.getIdaMin()));
		} else {
			Integer idaMin = calcularIdaMin(obj.getSaeDetalles());
			saeFilterDto.setPrioridad(getPrioridad(obj.getPrioridades(), obj.getTipo(), idaMin));
		}
		if(obj.getSaeDetalles() != null && !obj.getSaeDetalles().isEmpty()) {
			saeFilterDto.setIdPO(obj.getSaeDetalles().get(0).getIdDetalle().getIdPO());
		}
		return saeFilterDto;
	}
}