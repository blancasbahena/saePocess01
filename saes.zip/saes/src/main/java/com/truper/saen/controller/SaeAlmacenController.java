package com.truper.saen.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.commons.enums.Mensajes;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dto.ApprovalBovedaDto;
import com.truper.saen.service.OperationSaeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/sae-approval-almacen")
public class SaeAlmacenController {
	
	@Autowired
	private OperationSaeService operationSaeService;


	
	@PostMapping(value="/approval",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> approval(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = operationSaeService.operationSae(token,info);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	
	@PostMapping(value="/reject",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> reject(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Boolean respuesta = operationSaeService.deleteSaeDetalle(token,info);
		Map<String, Object> formData = new HashMap<>();
		formData.put("response", respuesta);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_EXITO.getMensaje())
				.folio(ResponseVO.getFolioActual())
				.data(formData)
				.build(),HttpStatus.OK);
	
	}
	
	
	@PostMapping(value="/approvalRevisados",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> approvalRevisados(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Boolean respuesta = operationSaeService.aprovalRevisados(token,info);
		Map<String, Object> formData = new HashMap<>();
		formData.put("response", respuesta);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_EXITO.getMensaje())
				.folio(ResponseVO.getFolioActual())
				.data(formData)
				.build(),HttpStatus.OK);
	
	}
	
	
	@PostMapping(value="/rejectRevisados",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> rejectRevisados(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Boolean respuesta = operationSaeService.rejectRevisados(token,info);
		Map<String, Object> formData = new HashMap<>();
		formData.put("response", respuesta);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_EXITO.getMensaje())
				.folio(ResponseVO.getFolioActual())
				.data(formData)
				.build(),HttpStatus.OK);
	
	}
	
	@PostMapping(value="/rejectCancelados",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> rejectCancelados(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Boolean respuesta = operationSaeService.rejectCancelados(token,info);
		Map<String, Object> formData = new HashMap<>();
		formData.put("response", respuesta);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_EXITO.getMensaje())
				.folio(ResponseVO.getFolioActual())
				.data(formData)
				.build(),HttpStatus.OK);
	
	}
	
	
	@PostMapping(value="/aprobacionCancelacion",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> aprobacionCancelacion(@RequestHeader("Authorization") String token, @RequestBody  ApprovalBovedaDto info ){
		log.info("[PUT /operation/{}] | INICIO -  {} - { {} }",info,JWUtil.extractUsername(token.substring(7)));
		Boolean respuesta = operationSaeService.cancelacionAprobacion(token,info);
		Map<String, Object> formData = new HashMap<>();
		formData.put("response", respuesta);
		log.info("[PUT /operation/{}] | FIN",info);
		return new ResponseEntity<>(ResponseVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_EXITO.getMensaje())
				.folio(ResponseVO.getFolioActual())
				.data(formData)
				.build(),HttpStatus.OK);
	
	}

}
