package com.truper.saen.service;

import com.truper.saen.commons.dto.SaeDto;

public interface SaeGerenteService {

	Boolean rejectGerentePlaneacion(String token, SaeDto dto);
}
