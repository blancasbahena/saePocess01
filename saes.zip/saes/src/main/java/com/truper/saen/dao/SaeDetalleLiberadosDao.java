package com.truper.saen.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleLiberados;

@Repository
public interface SaeDetalleLiberadosDao extends JpaRepository<SaeDetalleLiberados, SaeDetalleId>{
}
