package com.truper.saen;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.security.core.userdetails.UserDetails;

import com.truper.saen.configuration.JWUtil;
import com.truper.saen.configuration.UserDetailsServices;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableEurekaClient
@EnableFeignClients
@SpringBootApplication
public class SaesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaesApiApplication.class, args);
		UserDetailsServices service = new UserDetailsServices();
		UserDetails principal_2 = service.loadUserByUsername("example");
		JWUtil jwutil = new JWUtil();
		
		log.info("Este es un servicio de log4j {} ",jwutil.generaToken(principal_2));
	}

}