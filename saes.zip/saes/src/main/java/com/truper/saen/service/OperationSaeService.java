package com.truper.saen.service;
import com.truper.saen.common.Respuesta;
import com.truper.saen.dto.ApprovalBovedaDto;

public interface OperationSaeService {
	
	Respuesta operationSae(String authorization,ApprovalBovedaDto info);
	
	
	Boolean deleteSaeDetalle(String authorization,ApprovalBovedaDto info);
	
	
	Boolean aprovalRevisados(String authorization,ApprovalBovedaDto info);
	
	
	Boolean rejectRevisados(String authorization,ApprovalBovedaDto info);
	
	
	Boolean rejectCancelados(String authorization,ApprovalBovedaDto info);
	
	
	Boolean cancelacionAprobacion(String authorization,ApprovalBovedaDto info);


}
