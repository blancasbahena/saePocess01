package com.truper.saen.rabbit;
import java.util.Date;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class PublisherService {
	  @Autowired
	  private AmqpTemplate rabbitTemplateAMQ;

	  @Autowired
	  private Queue queue;

	  public void send(String json) {
		try {
			log.info("## ## ## Sending  Message(s) to the Queue {} ", new Date());
		    log.info("## ## ## Sending {} Message(s) to the Queue", json);
		    MessageProperties props = new MessageProperties();
		    log.info("Se generan MessageProperties");
		    props.getHeaders().put(MessageHeaders.CONTENT_TYPE, MessageProperties.CONTENT_TYPE_JSON);
		    log.info("Se generan getHeaders");
		    Message message = new Message(new Gson().toJson(json).getBytes(), props);
		    log.info("Se generan Message");
		    rabbitTemplateAMQ.convertAndSend(queue.getName(), message);
		    log.info("## ## ## {} Message(s) sent to the RabbitMQ Queue ");
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	  }

}

