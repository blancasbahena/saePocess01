package com.truper.saen.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.truper.saen.commons.dto.PoDetalleDto;
import com.truper.saen.commons.dto.UserDTO;

import lombok.Data;

@Data
public class SaeDto implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -4580759465506493661L;
	private Long folio;
	
	private String tipo;
	
	private Integer idStatus;
	
	private Date eta;
	
	private Date etaSolicitada;
	
	private Integer idProveedor;
	
	private Integer idSucursal;
	
	private Integer idTipoUnidad;
	
	private Integer unidades;
	
	private Integer idaMin;
	
	private Double bo;
	
	private Double os;
	
	private Integer totalCodigos;
	
	private Double monto;
	
	private Short conteoRevisado;
	
	private Short conteoRechazado;
	
	private Integer idConfirmador;
	
	private Date fechaConfirmacion;
	
	private Date rechazoConfirmacion;
	
	@JsonFormat(pattern="dd-MM-yyyy", timezone = "America/Mexico_City")
	private Date created;
	
	private String statusSae;
	
	private String TipoUnidad;
	 
	private Date lastModified;
	
	private UserDTO userModified;
	
	private UserDTO userCreated;
	
	private String comentarios;
	
	private List<PoDetalleDto> saeDetalles;
	
	private Double pesoTotal;
	
	private Double volTotal;
	
	@JsonFormat(pattern="dd-MM-yyyy", timezone = "America/Mexico_City")
	private Date cita;
	
	private String nombreProveedor;
	
	/** campos para rechazo aprobar sae */
	private UserDTO userReject;
	
	private UserDTO userApproval;
	
	private Date dateReject;
	
	private Date dateApproval;
	
	private Date date1erApproval;
	
	private String msgReject;
	
	private UserDTO userRejectGte;
	
	private Date dateRejectGte;
	
	private String msgRejectGte; 
	
	private String idPO;
	
}
