package com.truper.saen.service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.dto.SaeCentroDto;
import com.truper.saen.dto.SaeDto;
import com.truper.saen.dto.SaeIntDto;
import com.truper.saen.dto.SaePrioridadDto;
import com.truper.saen.dto.SaeZcomZmpDto;

public interface SaeServices {

	Respuesta createSae(SaeIntDto info);
	
	Respuesta getSaeById(Long idSae);
	
	Respuesta getSaeByIdProveedor(Integer idProveedor,Integer pagina,Integer rows);
	
	Respuesta getSaeByIdProveedor(Integer idProveedor);
	
	Respuesta getSaesByStatus( Integer idStatus );
	
	Respuesta cancelarSae(SaeIntDto info);
	
	Respuesta rechazarSae(SaeIntDto info);
	
	Respuesta actualizarSae(SaeDto info);
	
	Respuesta addPOsToSar(SaeDto info);
	
	Respuesta getCurrentSae(Integer idProveedor);
	
	Respuesta getTotalSaesByIdProveedor( Integer idProveedor );
	
	Respuesta actualizarPrioridadSae(SaePrioridadDto info);
	
	Respuesta actualizarCentroSae(SaeCentroDto info);
	
	Respuesta eliminaPos(Long idSae);

	Respuesta getSaesEstatusbyFilters(SaeZcomZmpDto filters);

	Respuesta getEstatus();
	
}
