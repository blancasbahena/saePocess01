package com.truper.saen.enums;

public class DataConstants {
	
	public static final String CONST_PROVEEDOR = "CONST_PROVEEDOR";
	public static final String CONST_FOLIO = "CONST_FOLIO";
	public static final Integer ID_PLANTILLA_PLANEADOR = 1;
	public static final Integer ID_PLANTILLA_GTEPLANEACION = 2;
	public static final Integer ID_PLANTILLA_OVER_STOCK = 5;
	public static final String TIPO_ZCOM = "N";
	public static final String TIPO_ZMP = "M";
	
	public static final Integer ID_PLANTILLA_LIBERACION_RECHAZO=25;
	public static final Integer ID_PLANTILLA_LIBERACION_APROBACION=26;
	public static final Integer ID_PLANTILLA_RECHAZADO_CANCELACION = 19;
	public static final Integer ID_PLANTILLA_CANCELACION = 20;
	
	public static final Integer ID_PLANTILLA_APROBACION_CANCELACION = 21;
	
}
