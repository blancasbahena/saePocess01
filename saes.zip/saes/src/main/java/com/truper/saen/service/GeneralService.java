package com.truper.saen.service;

import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.enums.CatStatusSae;

public interface GeneralService {

	CatSaeStatus getEstatus(CatStatusSae status);

}
