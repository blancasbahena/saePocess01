package com.truper.saen.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.truper.saen.commons.dto.SaeDto;
import com.truper.saen.commons.entities.CatCentro;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.CatTipoDeUnidad;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.dao.SaeDetalleDao;
import com.truper.saen.dao.SaeDetalleRevisadosDao;
import com.truper.saen.dao.SaeRevisadosDao;
import com.truper.saen.dao.TipoUnidadDao;
import com.truper.saen.dao.UserDao;
import com.truper.saen.enums.DataConstants;
import com.truper.saen.service.EmailsService;
import com.truper.saen.service.ISaeDetalleLiberadosService;
import com.truper.saen.service.SaeApprovalServices;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SaeApprovalServicesImpl implements SaeApprovalServices {

	@Autowired
	private SaeDao saeRepository;

	@Autowired
	private SaeDetalleDao saeDetalleRepository;

	@Autowired
	private UserDao userRepository;

	@Autowired
	private TipoUnidadDao tunidadDao;

	@Autowired
	private SaeRevisadosDao saeRevisadosDao;

	@Autowired
	private SaeDetalleRevisadosDao saeDetalleRevisadosDao;

	@org.springframework.beans.factory.annotation.Autowired(required = true)
	private EmailsService emailServices;

	@Value("${parameter-aprobacion-gte}")
	private Integer parameterAprobacionGte;
	private final boolean APROBACION = true;
	private final boolean RECHAZO = false;
	@Autowired
	private ISaeDetalleLiberadosService saeDetalleLiberadosService;

	@Override
	public boolean cambiaStatusPlaneacionSAEApproval(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		boolean enviarTest = false;
		boolean enviarCorreo = false;
		if (dto != null) {
			if (dto.getFolio() != null) {
				Optional<Sae> optional = saeRepository.findById(dto.getFolio());
				fin = new Date();
				if (optional.isPresent()) {
					CatSaeStatus status = new CatSaeStatus();
					status.setIdSaeStatus(dto.getIdStatus().intValue());
					optional.get().setStatus(status);
					Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
					if (userModified.isPresent()) {
						optional.get().setLastModified(new Date());
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APRUEBA_PLANEACION.getId()) {
							optional.get().setDateApproval(new Date());
							optional.get().setUserApproval(userModified.get());
							optional.get().setEtaSolicitada(dto.getEta());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APRUEBA_CANCEL_PLANEACION.getId()) {
							optional.get().setDateApproval(new Date());
							optional.get().setUserApproval(userModified.get());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APRUEBA_GTE_PLANEACION.getId()) {

							CatSaeStatus catSaeStatus = new CatSaeStatus();
							catSaeStatus.setIdSaeStatus(validarEstatusAprobacionGerente(optional));
							optional.get().setStatus(catSaeStatus);

							optional.get().setDateApprovalGte(new Date());
							optional.get().setUserApprovalGte(userModified.get());
							optional.get().setEtaSolicitada(dto.getEta());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APRUEBA_OVER_STOCK.getId()) {
							optional.get().setDateApprovalOver(new Date());
							optional.get().setUserApprovalOver(userModified.get());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APROBADO_LIBERACION.getId()) {
							optional.get().setDateApprovalLibera(new Date());
							optional.get().setUserApprovalLibera(userModified.get());
							optional.get().setEtaSolicitada(dto.getEta());
							optional.get().setUnidades(dto.getUnidades());
							CatCentro centro = new CatCentro();
							centro.setIdCentro(dto.getSucursalCentro());
							optional.get().setCentros(centro);
						}
						optional.get().setUserModified(userModified.get());
						/**
						 * Fue autorizado , de sae-Estatus para planeacion o planeacion a Gerente , el
						 * MsgRejectGte se queda nulo para que no se pinte en planeacion.
						 */
						optional.get().setMsgReject(null);
						optional.get().setMsgRejectGte(null);
						optional.get().setMsgRejectOver(null);
						optional.get().setMsgRejectLibera(null);
					}
					try {
						saeRepository.save(optional.get());
						if (enviarCorreo) {
							emailServices
									.envioCorreoValidar(optional.get().getFolio(), optional.get().getIdProveedor(),
											validaNombre(optional.get().getNombreProveedor()).toUpperCase(),
											regresaNombre(optional.get().getUserReject()),
											regresaNombre(optional.get().getUserApproval()),
											regresaNombre(optional.get().getUserRejectGte()),
											regresaNombre(optional.get().getUserApprovalGte()),
											regresaNombre(optional.get().getUserRejectOver()),
											regresaNombre(optional.get().getUserApprovalOver()),
											regresaNombre(optional.get().getUserRejectLibera()),
											regresaNombre(optional.get().getUserApprovalLibera()), enviarTest,
											optional.get().getMsgReject(), optional.get().getMsgRejectGte(),
											optional.get().getMsgRejectOver(), optional.get().getMsgRejectLibera(),
											optional.get().getUserApproval() != null
													? (optional.get().getUserApproval().getEmail() != null
															? optional.get().getUserApproval().getEmail().trim()
															: "")
													: "",
											dto.getIdStatus().intValue(), APROBACION);

						}
						log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
						return true;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return false;
	}

	@Override
	public boolean cambiaStatusOverstockApproval(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null) {
			if (dto.getFolio() != null) {
				Optional<Sae> optional = saeRepository.findById(dto.getFolio());
				fin = new Date();
				if (optional.isPresent()) {
					CatSaeStatus status = new CatSaeStatus();
					status.setIdSaeStatus(dto.getIdStatus().intValue());
					optional.get().setStatus(status);
					Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
					if (userModified.isPresent()) {
						optional.get().setDateApprovalOver(new Date());
						optional.get().setUserApprovalOver(userModified.get());
						optional.get().setUserModified(userModified.get());
						optional.get().setLastModified(new Date());
						optional.get().setMsgReject(null);
						optional.get().setMsgRejectGte(null);
						optional.get().setMsgRejectOver(null);
						optional.get().setMsgRejectLibera(null);
					}
					try {
						saeRepository.save(optional.get());
						log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
						return true;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return false;
	}

	private Integer validarEstatusAprobacionGerente(Optional<Sae> optional) {

		Integer idaMin = optional.get().getSaeDetalles().stream().mapToInt(y -> {
			try {
				return y.getIdaMin();
			} catch (Exception e) {
				return 0;
			}
		}).min().orElse(0);

		Double ss = optional.get().getSaeDetalles().stream().mapToDouble(y -> {
			try {
				return y.getSs();
			} catch (Exception e) {
				return 0.0;
			}
		}).sum();

		Integer status = 0;

		if (optional.get().getSaeDetalles() != null && !optional.get().getSaeDetalles().isEmpty()) {
			if (optional.get().getTipo().equals(DataConstants.TIPO_ZCOM) && idaMin > parameterAprobacionGte) {
				status = CatStatusSae.SAE_APRUEBA_GTE_PLANEACION.getId();
			} else if (optional.get().getTipo().equals(DataConstants.TIPO_ZCOM) && idaMin <= parameterAprobacionGte) {
				status = CatStatusSae.SAE_APRUEBA_OVER_STOCK.getId();
			} else if (optional.get().getTipo().equals(DataConstants.TIPO_ZMP) && idaMin > ss) {
				status = CatStatusSae.SAE_APRUEBA_GTE_PLANEACION.getId();
			} else if (optional.get().getTipo().equals(DataConstants.TIPO_ZMP) && idaMin <= ss) {
				status = CatStatusSae.SAE_APRUEBA_OVER_STOCK.getId();
			}
		} else {
			status = CatStatusSae.SAE_APRUEBA_GTE_PLANEACION.getId();
		}

		return status;
	}

	@Override
	public boolean approvalSAE(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null) {
			if (dto.getFolio() != null) {
				Map<String, Object> formData = new HashMap<>();
				Optional<Sae> optional = saeRepository.findById(dto.getFolio());
				fin = new Date();
				if (optional.isPresent()) {
					optional.get().setEtaSolicitada(dto.getCreated());
					optional.get().setUnidades(dto.getUnidades());

					CatTipoDeUnidad tunidad = tunidadDao.findById(dto.getIdTipoUnidad()).orElse(null);
					optional.get().setTipoDeUnidad(tunidad);

					CatSaeStatus status = new CatSaeStatus();
					status.setIdSaeStatus(CatStatusSae.SAE_ENVIADO_PARA_APROBACION.getId());
					optional.get().setCentro(dto.getCentro());
					optional.get().setStatus(status);
					int size = 0;
					if (optional.get().getSaeDetalles() != null && !optional.get().getSaeDetalles().isEmpty()) {
						size = optional.get().getSaeDetalles().size();
					}
					optional.get().setTotalCodigos(size);
					optional.get().setDate1erApproval(new Date());
					Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
					if (userModified.isPresent()) {
						optional.get().setUserModified(userModified.get());
					}
					try {
						saeRepository.save(optional.get());
						log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
						return true;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return false;
	}

	@Override
	@Transactional
	public boolean cambiaStatusPlaneacionSAEReject(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		boolean enviarTest = false;
		boolean enviarCorreo = true;
		if (dto != null) {
			if (dto.getFolio() != null) {
				Optional<Sae> optional = saeRepository.findById(dto.getFolio());
				fin = new Date();
				if (optional.isPresent()) {
					CatSaeStatus status = new CatSaeStatus();
					status.setIdSaeStatus(dto.getIdStatus().intValue());
					optional.get().setStatus(status);
					optional.get().setLastModified(new Date());
					Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
					if (userModified.isPresent()) {
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_RECHAZA_PLANEACION.getId()) {
							optional.get().setMsgReject(dto.getMsgReject());
							optional.get().setDateReject(new Date());
							optional.get().setUserReject(userModified.get());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_RECHAZA_GTE_PLANEACION.getId()) {
							optional.get().setMsgRejectGte(dto.getMsgReject());
							optional.get().setDateRejectGte(new Date());
							optional.get().setUserRejectGte(userModified.get());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_RECHAZA_OVER_STOCK_STATUS25.getId()) {
							optional.get().setMsgRejectOver(dto.getMsgReject());
							optional.get().setDateRejectOver(new Date());
							optional.get().setUserRejectOver(userModified.get());
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_RECHAZA_OVER_STOCK_STATUS26.getId()) {
							optional.get().setMsgRejectOver(dto.getMsgReject());
							optional.get().setDateRejectOver(new Date());
							optional.get().setUserRejectOver(userModified.get());
							optional.get().setConteoRevisado((short) ((Short) optional.get().getConteoRevisado() + 1));
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_ENVIADO_A_REVISION.getId()) {
							optional.get().setMsgRejectReview(dto.getMsgReject());
							optional.get().setDateRejectOver(new Date());
							optional.get().setUserRejectOver(userModified.get());
							optional.get().setConteoRevisado((short) ((Short) optional.get().getConteoRevisado() + 1));
						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_CANCELADO_LIBERACION.getId()) {
							optional.get().setMsgCancelaLibera(dto.getMsgReject());
							optional.get().setDateCancelaLibera(new Date());
							optional.get().setUserCancelaLibera(userModified.get());
						}

						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_RECHAZADO_LIBERACION.getId()) {
							optional.get().setMsgRejectLibera(dto.getMsgReject());
							optional.get().setDateRejectLibera(new Date());
							optional.get().setUserRejectLibera(userModified.get());

						}
						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_APROBADO_LIBERACION.getId()) {
							optional.get().setMsgRejectCancel(dto.getMsgReject());
							optional.get().setDateRejectCancel(new Date());
							optional.get().setUserRejectCancel(userModified.get());
							enviarCorreo = true;
						}

						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_NOENTREGADO.getId()) {
							optional.get().setComentarios(dto.getMsgReject());
							saeDetalleLiberadosService.crearDetalleLiberado(optional.get().getFolio());
							boolean delete = deleteSaeDetalle(dto.getFolio());
							log.info("Eliminando detalle: " + delete);
						}

						if (dto.getIdStatus().intValue() == CatStatusSae.SAE_ENTREGADO.getId()) {
							optional.get().setComentarios(dto.getMsgReject());
						}

						optional.get().setUserModified(userModified.get());
					}
					try {
						saeRepository.save(optional.get());
						if (enviarCorreo) {
							emailServices
									.envioCorreoValidar(optional.get().getFolio(), optional.get().getIdProveedor(),
											validaNombre(optional.get().getNombreProveedor()).toUpperCase(),
											regresaNombre(optional.get().getUserReject()),
											regresaNombre(optional.get().getUserApproval()),
											regresaNombre(optional.get().getUserRejectGte()),
											regresaNombre(optional.get().getUserApprovalGte()),
											regresaNombre(optional.get().getUserRejectOver()),
											regresaNombre(optional.get().getUserApprovalOver()),
											regresaNombre(optional.get().getUserRejectLibera()),
											regresaNombre(optional.get().getUserApprovalLibera()), enviarTest,
											optional.get().getMsgReject(), optional.get().getMsgRejectGte(),
											optional.get().getMsgRejectOver(), optional.get().getMsgRejectLibera(),
											optional.get().getUserApproval() != null
													? (optional.get().getUserApproval().getEmail() != null
															? optional.get().getUserApproval().getEmail().trim()
															: "")
													: "",
											dto.getIdStatus().intValue(), RECHAZO);

						}
						log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
						return true;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return false;
	}

	@Transactional
	private boolean deleteSaeDetalle(Long idSae) {
		try {
			saeDetalleRepository.deleteSaeDetalleByIdSae(idSae);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage());
			return false;
		}

	}

	private String validaNombre(String cadena) {
		if (cadena != null) {
			return cadena;
		}
		return "";
	}

	private String regresaNombre(User user) {
		if (user != null) {
			if (user.getName() != null) {
				return user.getName();
			}
		}
		return "";
	}

	@Override
	@Transactional
	public boolean cambiaStatusOverStockSAEReject(SaeDto dto) {

		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null && dto.getFolio() != null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			fin = new Date();
			if (optional.isPresent()) {
				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
				if (userModified.isPresent()) {
					/*optional.get().setMsgRejectOver(dto.getMsgReject());
					optional.get().setDateRejectOver(new Date());
					optional.get().setUserRejectOver(userModified.get());
					optional.get().setUserModified(userModified.get());
					optional.get().setLastModified(new Date());
					if (status.getIdSaeStatus().intValue() == CatStatusSae.SAE_RECHAZA_PLANEACION.getId()) {
						optional.get().setMsgReject(dto.getMsgReject());
					optional.get().setLastModified(new Date());*/
					
					optional.get().setDateRejectReview(new Date());
					optional.get().setMsgRejectReview(dto.getMsgReject());
					optional.get().setUserRejectReview(userModified.get());
					optional.get().setUserModified(userModified.get());
					optional.get().setLastModified(new Date());
					if (status.getIdSaeStatus().intValue() == CatStatusSae.SAE_RECHAZA_PLANEACION.getId()) {
						optional.get().setMsgReject(dto.getMsgReject());
						optional.get().setUserReject(userModified.get());
					}
				}
				try {
					saeRepository.save(optional.get());
					//mapSaeToSaeRevisados(optional.get(), userModified);
					log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					return true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	private SaeRevisado mapSaeToSaeRevisados(Sae sae, Optional<User> userModified) {
		SaeRevisado saeRevisado = new SaeRevisado();
		saeRevisado.setCreated(sae.getCreated());
		saeRevisado.setEta(sae.getEta());
		saeRevisado.setEtaSolicitada(sae.getEtaSolicitada());
		saeRevisado.setFolio(sae.getFolio());
		saeRevisado.setIdProveedor(sae.getIdProveedor());
		saeRevisado.setTipo(sae.getTipo());
		saeRevisado.setTipoDeUnidad(sae.getTipoDeUnidad());
		saeRevisado.setUnidades(sae.getUnidades());
		saeRevisado.setUserCreated(sae.getUserCreated());
		saeRevisadosDao.save(saeRevisado);
		for (SaeDetalle saedetalle : sae.getSaeDetalles()) {
			SaeDetalleId saeDetalleId = new SaeDetalleId();
			saeDetalleId.setIdSae(saedetalle.getIdDetalle().getIdSae());
			saeDetalleId.setIdPO(saedetalle.getIdDetalle().getIdPO());
			saeDetalleId.setIdPosicion(saedetalle.getIdDetalle().getIdPosicion());

			SaeDetalleRevisado saeNuevo = new SaeDetalleRevisado();
			saeNuevo.setIdDetalle(saeDetalleId);

			saeNuevo.setCondicionPago(saedetalle.getCondicionPago());
			saeNuevo.setNumOrdenSecundaria(saedetalle.getNumOrdenSecundaria());
			saeNuevo.setCantidadUnidadMedida(saedetalle.getCantidadUnidadMedida());
			saeNuevo.setFactorCantidadUnidadMedida(saedetalle.getFactorCantidadUnidadMedida());
			saeNuevo.setDescripcionComplementoFactura(saedetalle.getDescripcionComplementoFactura());
			saeNuevo.setOrigen(saedetalle.getOrigen());
			saeNuevo.setTipo(saedetalle.getTipo());
			saeNuevo.setCodigo(saedetalle.getCodigo());
			saeNuevo.setDescripcion(saedetalle.getDescripcion());
			saeNuevo.setPlaneadorProducto(saedetalle.getPlaneadorProducto());
			saeNuevo.setFamilia(saedetalle.getFamilia());
			saeNuevo.setPlanner(saedetalle.getPlanner());
			saeNuevo.setCantidad(saedetalle.getCantidad());
			saeNuevo.setCentro(saedetalle.getCentro());
			saeNuevo.setPicoPlan(saedetalle.getPicoPlan());
			saeNuevo.setPicoReal(saedetalle.getPicoReal());
			saeNuevo.setMonto(saedetalle.getMonto());
			saeNuevo.setFechaPI(saedetalle.getFechaPI());
			saeNuevo.setDifPIEvsETA(saedetalle.getDifPIEvsETA());
			saeNuevo.setMaterial(saedetalle.getMaterial());
			saeNuevo.setPeso(saedetalle.getPeso());
			saeNuevo.setVolumen(saedetalle.getVolumen());
			saeNuevo.setBo(saedetalle.getBo());
			saeNuevo.setOs(saedetalle.getOs());
			saeNuevo.setSs(saedetalle.getSs());
			saeNuevo.setIdaMin(saedetalle.getIdaMin());
			saeNuevo.setFechaEntrega(saedetalle.getFechaEntrega());
			saeNuevo.setEsNuevo(true);
			saeNuevo.setEsBorrado(false);
			saeNuevo.setEsModificado(false);
			if (userModified.isPresent()) {
				saeNuevo.setCreated(new Date());
				saeNuevo.setUserCreated(userModified.get());
			}

			saeDetalleRevisadosDao.save(saeNuevo);
		}

		return saeRevisado;
	}

	@Override
	public boolean cambiaStatusGtePlanecionReject(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null && dto.getFolio() != null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			fin = new Date();
			if (optional.isPresent()) {
				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
				if (userModified.isPresent()) {
					optional.get().setMsgReject(dto.getMsgReject());
					optional.get().setDateReject(new Date());
					optional.get().setUserReject(userModified.get());
					optional.get().setUserModified(userModified.get());

					/*
					 * optional.get().setMsgRejectGte(dto.getMsgReject());
					 * optional.get().setDateRejectGte(new Date());
					 * optional.get().setUserRejectGte(userModified.get());
					 * optional.get().setUserModified(userModified.get());
					 */
				}
				try {
					saeRepository.save(optional.get());
					mapSaeToSaeRevisados(optional.get(), userModified);
					log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					return true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	@Transactional
	public boolean cambiaStatusLiberacion(SaeDto dto) {

		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null && dto.getFolio() != null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			fin = new Date();
			if (optional.isPresent()) {
				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
				if (userModified.isPresent()) {
					optional.get().setMsgReject(dto.getMsgReject());
					optional.get().setDateReject(new Date());
					optional.get().setUserReject(userModified.get());
					optional.get().setUserModified(userModified.get());
				}
				try {
					saeRepository.save(optional.get());
					//mapSaeToSaeRevisados(optional.get(), userModified);
					log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					return true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	@Transactional
	public boolean cambiaStatusLiberacionRechazados(SaeDto dto) {

		Date inicio = new Date();
		Date fin = new Date();
		if (dto != null && dto.getFolio() != null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			fin = new Date();
			if (optional.isPresent()) {
				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
				if (userModified.isPresent()) {
					
					/** Aqui no debe incrementarse el contador **/
					//optional.get().setConteoRevisado((short) ((optional.get().getConteoRevisado() == null ? (0)
						//	: optional.get().getConteoRevisado()) + 1));
					
					optional.get().setDateRejectReview(new Date());
					optional.get().setMsgRejectReview(dto.getMsgReject());
					optional.get().setUserRejectReview(userModified.get());
					optional.get().setUserModified(userModified.get());
					optional.get().setLastModified(new Date());
				}
				try {
					saeRepository.save(optional.get());
					//mapSaeToSaeRevisados(optional.get(), userModified);
					log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					return true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	public boolean cambiaStatusLiberacionReject(SaeDto dto) {
		Date inicio = new Date();
		Date fin = new Date();
		if(dto!=null && dto.getFolio()!=null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			fin = new Date();
			if(optional.isPresent()) {
				CatSaeStatus status =  new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				Optional<User> userModified = userRepository.findById(dto.getUserModified().getId());
				if(userModified.isPresent()) {
					optional.get().setMsgRejectLibera(dto.getMsgReject());
					optional.get().setDateRejectLibera(new Date());
					optional.get().setUserRejectLibera(userModified.get());
					optional.get().setUserModified(userModified.get());
				}
				try {
					saeRepository.save(optional.get());
					mapSaeToSaeRevisados(optional.get(), userModified);
					log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					return true;
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	
}
