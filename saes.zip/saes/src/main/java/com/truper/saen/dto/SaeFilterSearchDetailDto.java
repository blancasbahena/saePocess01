package com.truper.saen.dto;

import lombok.Data;

@Data
public class SaeFilterSearchDetailDto {
	
	private String idPO;
	private String idPosicion;
	private String planner;
	private String codigo;
	private String descripcion;
	private Double Cantidad;
	private Integer ida;
	private Double bo;
	private Double os;
	private String centro;
}
