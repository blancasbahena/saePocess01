package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class SaeDetailSearch implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer tipoSar;
	private Integer folio;
	private Integer po;
	private String material;
	private Integer proveedor;
	private Integer prioridad;
	private String eta;
	private String sucursal;
	private String centro;

}
