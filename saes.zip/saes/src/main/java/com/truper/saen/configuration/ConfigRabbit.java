package com.truper.saen.configuration;
import java.io.Serializable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Component
@ConfigurationProperties(prefix = "spring.rabbitmq")
@EnableConfigurationProperties 
@Getter
@Setter
@ToString
public class ConfigRabbit implements Serializable{ 
	private static final long serialVersionUID = 2057762734468312675L; 
	private String host;
	private Integer port;
	private String username;
	private String password;
	
	private String virtualHost;
	private String exchange;
	
	private String queueSNacionales;
    private String routingkeySNacionales; 
    
    private Boolean durable;
    private Boolean exclusive;
    private Boolean autoDelete;
    
}
