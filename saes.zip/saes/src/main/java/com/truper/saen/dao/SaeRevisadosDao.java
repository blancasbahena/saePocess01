package com.truper.saen.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeRevisado;

@Repository
public interface SaeRevisadosDao extends JpaRepository<SaeRevisado, Long> {
	@Modifying
	@Transactional
	@Query(value= "DELETE FROM SaeRevisados WHERE  folio = ?1 ", nativeQuery=true )
	Integer  deleteSaeById(Long idFolio);
}
