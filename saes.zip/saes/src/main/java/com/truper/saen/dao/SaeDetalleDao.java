package com.truper.saen.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;

public interface SaeDetalleDao extends JpaRepository<SaeDetalle, SaeDetalleId>{
	
	@Modifying
	@Query(value = "DELETE FROM SAE_NACIONALES.dbo.SaeDetalle\r\n"
			+ "	WHERE idSae=:idSae", nativeQuery = true)
	void deleteSaeDetalleByIdSae(Long idSae);
	
	
	@Modifying
	@Transactional
	@Query(value= "DELETE FROM SaeDetalle WHERE  idSae = ?1 and idPO =?2 and idPosicion=?3", nativeQuery=true )
	Integer  deleteDetalleSaeById(Long idFolio, String idPO, String idPosicion);

}
