package com.truper.saen.service.impl;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.SaeDto;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.dao.SaeDao;
import com.truper.saen.service.InfoSaesService;
import com.truper.saen.service.SaeGerenteService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SaeGerenteServiceImpl implements SaeGerenteService {
	
	@Autowired
	private SaeDao saeRepository;
	
	@Autowired
	private InfoSaesService infoSaesService;
	
	@Override
	public Boolean rejectGerentePlaneacion(String token, SaeDto dto) {
		Date ini = new Date();
		Date fin = new Date();
		if(dto != null && dto.getFolio() != null) {
			Optional<Sae> optional = saeRepository.findById(dto.getFolio());
			if(optional.isPresent()) {
				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(dto.getIdStatus().intValue());
				optional.get().setStatus(status);
				optional.get().setMsgReject(dto.getMsgReject());
				optional.get().setDateReject(dto.getDateReject());
				User user = infoSaesService.obtenerUsuario(token);
				optional.get().setUserReject(user);
				try {
					saeRepository.save(optional.get());
					return true;
				}catch (Exception e) {
					e.printStackTrace();
				}
				
				fin = new Date();
				log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(ini, fin));
			}
		}
		return false;
	}

}
