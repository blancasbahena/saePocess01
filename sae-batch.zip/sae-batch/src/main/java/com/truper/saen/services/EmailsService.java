package com.truper.saen.services;

import java.util.List;

import com.truper.saen.dto.ResetPasswordDTO;

public interface EmailsService {
	Integer envioCorreoValidar(Long folio, Integer idProveedor, String proveedor,String etaSolictada,
			Integer plantilla, boolean isZcom) ;
	
	Integer enviarNotificacionCitaProveedor(List<String> folios, String correos, String nombreProveedor, Integer dias);
	
	boolean envioCorreoResetPassword(ResetPasswordDTO dto);
}
