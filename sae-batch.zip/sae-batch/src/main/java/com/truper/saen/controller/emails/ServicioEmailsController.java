package com.truper.saen.controller.emails;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.dto.RequestDTO;
import com.truper.saen.services.EmailsService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
@RestController
@RequestMapping("/emails")
@Slf4j
@CrossOrigin(origins = "*")
@Api("Servicio para envio de correos de confirmacion")
public class ServicioEmailsController {
	@org.springframework.beans.factory.annotation.Autowired(required=true)
	private EmailsService emailsService;
	
	@PostMapping("/citasSinConfirmar")
	public ResponseEntity<ResponseVO> envioCorreoZcom(@RequestHeader("Authorization") String authorization,
			@RequestBody RequestDTO dto) {
		Map<String, Object> formData = new HashMap<>();
		log.info("Se inicia controller de ZCOM  {} ", new Date());
		Integer resultado = emailsService.envioCorreoValidar(dto.getFolio(), dto.getIdProveedor(), 
				dto.getProveedor(),dto.getEtaSolicitada(),dto.getPlantilla(), true);
		formData.put("respuesta" ,resultado);
		log.info("Se obtiene resultado controller de ZCOM  {} ", resultado);
		ResponseVO vo =null;
		if(resultado==1) {
			vo = ResponseVO.builder().tipoMensaje("S")
				.folio(dto.getFolio().toString())
				.mensaje("Proceso ejecutado correctamente").data(formData)
				.build();
			log.info("Se obtiene resultado controller de ZCOM  {} ", vo.getTipoMensaje() + " -> " + vo.getMensaje());
		}else {
			String mesj = "Problemas con servicio batch";
			if(resultado.intValue()==2) mesj = "Problemas con servicio";
			if(resultado.intValue()==3) mesj = "Problemas sin correos del proveedor";
			if(resultado.intValue()==4) mesj = "Problemas con servicio Batch en parametros";
			vo = ResponseVO.builder().tipoMensaje("E")
					.mensaje(mesj).data(formData)
					.folio(dto.getFolio().toString())
					.build();
			log.info("Se obtiene resultado controller de ZCOM  {} ", vo.getTipoMensaje() + " -> " + vo.getMensaje());
		}
		log.info("Se Termina controller de ZCOM  {} ", new Date());
		return new ResponseEntity(vo, HttpStatus.OK);

	}
}
