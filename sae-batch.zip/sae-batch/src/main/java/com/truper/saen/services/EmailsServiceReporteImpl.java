package com.truper.saen.services;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truper.saen.commons.dto.AdjuntoDTO;
import com.truper.saen.commons.dto.DataDTO;
import com.truper.saen.commons.dto.EmailDTO;
import com.truper.saen.commons.dto.ParamsDTO;
import com.truper.saen.commons.entities.MensajesEmails;
import com.truper.saen.enums.DataConstants;
import com.truper.saen.rabbit.PublisherService;
import com.truper.saen.repository.MensajesEmailsDao;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class EmailsServiceReporteImpl  {
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
	@Autowired private PublisherService sender; 
	@Autowired private MensajesEmailsDao mensajesEmailsDao;
	private final String ZMP = "ZMP";
	private final String ZCOM = "ZCOM";
	@Value("${email.debug}") private String debug;
	@Value("${email.sender}") private String senderEmail;
	public Integer enviarProgramaDeEntregasDiario(String correos, byte[] bytes,String tipo,boolean esZCOM) {
		EmailDTO dtoEmail = new EmailDTO();
		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(esZCOM?
				DataConstants.ID_PLANTILLA_REPORTE_SAES_ZCOM:DataConstants.ID_PLANTILLA_REPORTE_SAES_ZMP);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = respuesta.get().getSubjectEmail();
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ",debug);
			params.setDebug(debugParam);
			DataDTO data = new DataDTO();
			if(senderEmail!=null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ",senderEmail);
			if(respuesta.get().getPlantilla() !=null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			Date date = Calendar.getInstance().getTime();  
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
			data.setEta(dateFormat.format(date));
			if (correos != null) {
				to = correos.trim().split(";");
				cc = respuesta.get().getCc().trim().split(";");
				dtoEmail.setTo(Arrays.asList(to));
				data.setTo(correos.trim());
				if (debug != null) {
					if(debug.equals("true")) {
						String[] toDebug = respuesta.get().getCc().trim().split(";");
						dtoEmail.setTo(Arrays.asList(toDebug));
					}
					data.setDebug(debug.equals("true") ? true : false);
				}				
				log.info("Parametro del  proceso de envio de correo  to : {} ",to);
				dtoEmail.setCc(Arrays.asList(cc));
				log.info("Parametro del  proceso de envio de correo  cc : {} ",cc);
				dtoEmail.setSubject(subject);
				params.setData(data);
				log.info("Parametro del  proceso de envio de correo  data : {} ",data);
				dtoEmail.setParams(params);
				log.info("Parametro del  proceso de envio de correo  params : {} ",params);
				Gson gson = new GsonBuilder().create();
				try { 
					String archivoBase64=Base64.encodeBase64String(bytes);
					List<AdjuntoDTO> lista = Arrays.asList(new AdjuntoDTO("ProgramaDeEntregas_"+(tipo.equals("N")? ZCOM : ZMP)+"_"+dateFormat.format(new Date())+".xlsx",archivoBase64));
					dtoEmail.setFiles(lista);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				String envioCorreo = gson.toJson(dtoEmail);
				log.info("Parametro del  proceso de envio de correo  JSON : {} ",envioCorreo);
				sender.send(envioCorreo);
				log.info("Proceso con exito");
				return 1;
			} else {
				return 3;
			}
		}
		return 2;

	}
}



