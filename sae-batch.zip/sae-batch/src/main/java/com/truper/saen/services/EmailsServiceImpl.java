package com.truper.saen.services;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truper.saen.commons.dto.DataDTO;
import com.truper.saen.commons.dto.EmailDTO;
import com.truper.saen.commons.dto.ParamsDTO;
import com.truper.saen.commons.entities.MensajesEmails;
import com.truper.saen.commons.utils.UtilsString;
import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResetPasswordDTO;
import com.truper.saen.dto.ResponseCatalogsProveedorDTO;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.enums.DataConstants;
import com.truper.saen.feign.CatalogsFeignClient;
import com.truper.saen.rabbit.PublisherService;
import com.truper.saen.repository.MensajesEmailsDao;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class EmailsServiceImpl  implements EmailsService{
	@Autowired private PublisherService sender;
	@Autowired private MensajesEmailsDao mensajesEmailsDao;
	@Autowired private CatalogsFeignClient catalogsFeignClient;
	@Value("${catalogs.username}")
	private String username;

	@Value("${catalogs.password}")
	private String password;

	@Value("${email.debug}")
	private String debug;
	
	@Value("${email.sender}")
	private String senderEmail;
	
	@Value("${email.reset.password}")
	private String urlResetPassword;
	@Value("${email.reset.expira}")
	private Integer minutosMas;
	

	@Override
	public  Integer envioCorreoValidar(Long folio, Integer idProveedor, String proveedor,
			String etaSolicitada,Integer plantilla, boolean isZcom) {
		log.info("Se inicia proceso de envio de correo : {} ", new Date());
		if (proveedor != null && folio != null && idProveedor != null && plantilla !=null) {
			log.info("Se inicia service de aemails  {} ",  plantilla);
			try {
				return envioCorreoCitasPorConfirmar(folio, idProveedor, proveedor, etaSolicitada,plantilla,isZcom);
			} catch (Exception ex) {
				System.out.println(
						"Problemas con envio " + ex.getMessage());
			}

		} else {
			
			System.out.println("Problemas con el proveedor ejemplo ID!NOMBRE_PROVEEDOR " + proveedor);
		}
		log.info("Se termina con error  el  proceso de envio de correo : {} ", new Date());
		return 4;
	}
	

	private Integer envioCorreoCitasPorConfirmar(Long folio, Integer idProveedor, String proveedor, 
			String etaSolicitada,Integer plantilla,boolean isZcom)
			throws Exception {
		EmailDTO dtoEmail = new EmailDTO();
		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(plantilla);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = UtilsString.replaceString2String(respuesta.get().getSubjectEmail(),
					DataConstants.CONST_PROVEEDOR, proveedor.toUpperCase());

			subject = UtilsString.replaceString2String(subject, DataConstants.CONST_FOLIO, folio.toString());
			log.info("Parametro del proceso de envio de correo  subject : {}",subject);
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ",debug);
			params.setDebug(debugParam);
			DataDTO data = new DataDTO();
			data.setFolio(folio.toString());
			if(senderEmail!=null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ",senderEmail);
			if(respuesta.get().getPlantilla() !=null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			data.setSupplier(proveedor);
			String emailsProveedor = null;
			try{
				emailsProveedor =  obtenerCorreosProveedor(idProveedor);
				log.info("Parametro del  proceso de envio de correo  emailsProveedor : {}",emailsProveedor);
			}catch(Exception ex){
				ex.printStackTrace();
				return 3;
			}
			if (emailsProveedor != null) {
				to = emailsProveedor.trim().split(";");
				cc = respuesta.get().getCc().trim().split(";");
				dtoEmail.setTo(Arrays.asList(to));
				data.setTo(emailsProveedor.trim());
				data.setEta(etaSolicitada);
				if (debug != null) {
					if(debug.equals("true")) {
						String[] toDebug = respuesta.get().getCc().trim().split(";");
						dtoEmail.setTo(Arrays.asList(toDebug));
					}
					data.setDebug(debug.equals("true") ? true : false);
				}				
				dtoEmail.setCc(Arrays.asList(cc));
				dtoEmail.setSubject(subject);
				params.setData(data);
				log.info("Parametro del  proceso de envio de correo  data : {} ",data);
				dtoEmail.setParams(params);
				log.info("Parametro del  proceso de envio de correo  params : {} ",params);
				Gson gson = new GsonBuilder().create();
				String envioCorreo = gson.toJson(dtoEmail);
				log.info("Parametro del  proceso de envio de correo  JSON : {} ",envioCorreo);
				sender.send(envioCorreo);
				log.info("Proceso con exito");
				return 1;
			} else {
				return 3;
			}
		}
		return 2;

	}

	private String obtenerCorreosProveedor(Integer idProveedor) throws Exception {
		log.info("Servicio para obtener correos de proveedor  {}  - {}  ",idProveedor,new Date());
		RequestToken requestToken = new RequestToken();
		requestToken.setPassword(password);
		requestToken.setUsername(username);
		ResponseTokenDTO token = catalogsFeignClient.getToken(requestToken);

		if (token != null) {
			ResponseCatalogsProveedorDTO response = catalogsFeignClient.getDataProveedor(idProveedor.toString(),
					"Bearer " + token.getData().getToken());
			if (response.getData().getProveedor().getEmail() == null
					|| response.getData().getProveedor().getEmail().equals("")) {
				throw new Exception("Error al obtener los correos del proveedor");
			}
			log.info("Servicio para obtener correos    {}  - {}  ",response.getData().getProveedor().getEmail(),new Date());
			return response.getData().getProveedor().getEmail();
		} else {
			throw new Exception("Error al obtener token para el envio de correo");
		}

	}

	@Override
	public Integer enviarNotificacionCitaProveedor(List<String> folios, String correos, String nombreProveedor, Integer dias) {
		
		EmailDTO dtoEmail = new EmailDTO();
		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(DataConstants.ID_PLANTILLA_NOTIFICACION_CITA_PROVEEDOR);
		String[] to = null;
		String[] cc = null;
		if (respuesta.isPresent()) {
			log.info("Se obtuvo plantilla con exito");
			String subject = UtilsString.replaceString2String(respuesta.get().getSubjectEmail(),
					DataConstants.CONST_DIAS, dias.toString());
			
			subject = UtilsString.replaceString2String(subject, DataConstants.CONST_PROVEEDOR, nombreProveedor.toUpperCase());
			ParamsDTO params = new ParamsDTO();
			boolean debugParam = true;
			if (debug != null) {
				debugParam = debug.equals("true") ? true : false;
			}
			log.info("Parametro del  proceso de envio de correo  debug : {} ",debug);
			params.setDebug(debugParam);
			DataDTO data = new DataDTO();
			data.setFolios(folios);
			if(senderEmail!=null) {
				dtoEmail.setSender(senderEmail);
			}
			log.info("Parametro del  proceso de envio de correo  senderEmail : {} ",senderEmail);
			if(respuesta.get().getPlantilla() !=null) {
				dtoEmail.setTemplate(respuesta.get().getPlantilla());
			}
			data.setSupplier(nombreProveedor);
			data.setDias(String.valueOf(dias));
			
			
			if (correos != null) {
				to = correos.trim().split(";");
				cc = respuesta.get().getCc().trim().split(";");
				dtoEmail.setTo(Arrays.asList(to));
				data.setTo(correos.trim());
				
				if (debug != null) {
					if(debug.equals("true")) {
						String[] toDebug = respuesta.get().getCc().trim().split(";");
						dtoEmail.setTo(Arrays.asList(toDebug));
					}
					data.setDebug(debug.equals("true") ? true : false);
				}				
				dtoEmail.setCc(Arrays.asList(cc));
				dtoEmail.setSubject(subject);
				params.setData(data);
				dtoEmail.setParams(params);
				Gson gson = new GsonBuilder().create();
				String envioCorreo = gson.toJson(dtoEmail);
				sender.send(envioCorreo);
				log.info("Proceso con exito");
				return 1;
			} else {
				return 3;
			}
		}
		return 2;

	}
	private String getTime(Integer minutos) {
		Calendar fecha = Calendar.getInstance();
		fecha.setTime(new Date());
		fecha.add(Calendar.MINUTE, minutos);
		java.util.Date fechaMasMinutos = fecha.getTime();
		return (new Long(fechaMasMinutos.getTime())).toString();		
	}

	@Override
	public boolean envioCorreoResetPassword(ResetPasswordDTO dto) {
		EmailDTO dtoEmail = new EmailDTO();
		Optional<MensajesEmails> respuesta = mensajesEmailsDao.findById(dto.getNumeroPlantilla());
		String[] to = null;
		String[] cc = null;
		if(dto!=null) {
			if (dto.getCorreo() != null && dto.getNombre()!=null  && respuesta.isPresent()) {
				log.info("Se obtuvo plantilla con exito");
				String subject = dto.getSubject();
				ParamsDTO params = new ParamsDTO();
				log.info("Parametro del  proceso de envio de correo  debug : {} ",debug);
				params.setDebug(false);
				DataDTO data = new DataDTO();
				if(senderEmail==null) {
					log.error("Problemas en el campo del SENDER en properties de BATCH***");
				}else {
					dtoEmail.setSender(senderEmail);
					log.info("Parametro del  proceso de envio de correo  senderEmail : {} ",senderEmail);
					if(respuesta.get().getPlantilla() !=null) {
						dtoEmail.setTemplate(respuesta.get().getPlantilla());
						data.setSupplier(dto.getNombre());
						
						String parametro="?data="+convierteB64(("us="+convierteB64(dto.getUsuario())+"&session="+convierteB64(getTime(minutosMas))));
						data.setComments(urlResetPassword+parametro);
						if(dto.getCorreo()!=null) {
							to = dto.getCorreo().split(";");
							dtoEmail.setTo(Arrays.asList(to));
							data.setTo(dto.getCorreo());
							dtoEmail.setSubject(subject);
							params.setData(data);
							Gson gson = new GsonBuilder().create();
							String envioCorreo = gson.toJson(dtoEmail);
							log.info("Parametro del  proceso de envio de correo  JSON : {} ",envioCorreo);
							sender.send(envioCorreo);
							log.info("Proceso con exito");
							return true;
						}else {
							log.error("Problemas con el correo<<to>> para envio");
						}
					}else {
						log.error("Problemas con el correo<<plantilla>> para envio");
					}
				}
			}
		}
		return false;
	}


	private String convierteB64(String cadena) {
		String cadenaBase64 ="ErrorEnValor";
		if(cadena!=null) {
			cadenaBase64 =Base64.encodeBase64String(cadena.getBytes());
		}
		return reemplazarCaracteresEspeciales(cadenaBase64);
	}
	private String reemplazarCaracteresEspeciales(String palabra) {
        String[] caracteresMalos = {"="};
        String[] caracteresBuenos = {"$"};
        for (String letraMala : caracteresMalos) {
            if(palabra.contains(letraMala)){
                palabra = palabra.replace(letraMala,caracteresBuenos[Arrays.asList(caracteresMalos).indexOf(letraMala)]);
            }
        }

        return palabra;

    }
}



