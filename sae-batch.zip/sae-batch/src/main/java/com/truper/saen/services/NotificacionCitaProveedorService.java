package com.truper.saen.services;

public interface NotificacionCitaProveedorService {
	
	void enviarNotificacionCitaProveedor();

}
