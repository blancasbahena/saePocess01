package com.truper.saen.controller.emails;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.dto.ResetPasswordDTO;
import com.truper.saen.services.EmailsService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
@RestController
@RequestMapping("/email")
@Slf4j
@CrossOrigin(origins = "*")
@Api("Servicio para envio de correos de confirmacion")
public class ServicioResetPasswordController {
	@org.springframework.beans.factory.annotation.Autowired(required=true)
	private EmailsService emailsService;
	 
	@PostMapping("/resetPassword")
	public ResponseEntity<ResponseVO> envioCorreoResetPassword(@RequestHeader("Authorization") String authorization,
			@RequestBody ResetPasswordDTO dto) {
		Map<String, Object> formData = new HashMap<>();
		String folio  = ResponseVO.getFolioActual();
		log.info("Se inicia controller de resetPassword  {} ", new Date());
		formData.put("respuesta" ,emailsService.envioCorreoResetPassword(dto));
		ResponseVO vo = ResponseVO.builder()
				.tipoMensaje("S")
				.data(formData)
				.folio(folio)
				.mensaje("Proceso ejecutado correctamente").data(formData)
				.build();
		log.info("Se termina controller de resetPassword  {} ", new Date());
		return new ResponseEntity<ResponseVO>(vo, HttpStatus.OK);
	}
}
