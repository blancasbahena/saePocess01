package com.truper.saen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;

public interface SaeDetalleRepository extends JpaRepository<SaeDetalle, SaeDetalleId> {

  @Query(value = "SELECT sd.* FROM Sae s " +
    "INNER JOIN catSaeStatus cse ON s.idStatus = cse.idSaeStatus " +
    "INNER JOIN SaeDetalle sd ON s.folio = sd.idSae "+
    "WHERE cse.idSaeStatus NOT IN :status", nativeQuery = true)
  List<SaeDetalle> findByStatusSae(@Param("status") List<Integer> status);

  @Transactional
  @Modifying
  @Query("UPDATE SaeDetalle SET " +
    "IDAMin = :IDAMin, SS = :SS, BO = :BO, OS = :OS, picoPlan = :picoPlan, picoReal = :picoReal, " +
	"diasConsumoDisponible = :diasConsumoDisponible " +
    "WHERE idPO = :idPO AND idPosicion = :idPosicion")
  int updateIndicators(@Param("IDAMin") Integer IDAMin, @Param("SS") Double SS, @Param("BO") Double BO,
    @Param("OS") Double OS, @Param("picoPlan") Integer picoPlan, @Param("picoReal") Integer picoReal, 
    @Param("idPO") String idPO, @Param("idPosicion") Integer idPosicion, 
    @Param("diasConsumoDisponible") Integer diasConsumoDisponible);
  
  @Query(value = "SELECT top 1 cse.idSaeStatus FROM Sae s " +
    "INNER JOIN catSaeStatus cse ON s.idStatus = cse.idSaeStatus " +
    "INNER JOIN SaeDetalle sd ON s.folio = sd.idSae " +
    "WHERE sd.idPO = :po and sd.idPosicion = :posicion", nativeQuery = true)
  Integer getStatusByPoAndPosicion(@Param("po") int po, @Param("posicion") int posicion);

}
