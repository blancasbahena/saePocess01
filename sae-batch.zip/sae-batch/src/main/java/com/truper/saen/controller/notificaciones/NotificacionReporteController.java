package com.truper.saen.controller.notificaciones;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.truper.saen.dto.RequestEmail;
import com.truper.saen.services.ExcelExporterService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/export-to-excel")
public class NotificacionReporteController {
	@Autowired private ExcelExporterService  serviceExcel; 
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public String enviarReporte(@RequestBody(required = true) RequestEmail dto) {
    	if(dto!=null) {
	    	log.info("####sendReportProcess  Update of indicators job starting at {}", dateFormat.format(new Date()));
	    	if(dto.getEmails()==null) {
	    		return "El campo emails  debe contener un valor : email(s)";
	    	}
	    	if(dto.getTipo()==null) {
	    		return "El campo tipo  debe contener un valor : N o M";
	    	}
	    	if(dto.getEmails().isEmpty()) {
	    		return "El campo emails  debe contener un valor : email(s)";
	    	}
	    	if(dto.getTipo().isEmpty()) {
	    		return "El campo tipo  debe contener un valor : N o M";
	    	}
	    	serviceExcel.envioReporteSaes(dto.getEmails(),dto.getTipo());
	    	log.info("#### sendeportProcess Job executed successfully !!! \n");
	    	return "Se envio correo de ejemplo";
    	}
    	return "Problemas con Request Body RequestEmail[emails : example@gmail.com , tipo: N|M]";
	}
}
