package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class SaeZcomZmpDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String tipo;
	private Integer status;
	private Integer idProveedor; 
	private String etaSolicitada; 
	private Integer folio;
	private Integer ida;
	private Integer po;
	private Integer confirmador;
	private String idCentro;

}
