package com.truper.saen.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class NotificacionCitaProveedorDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long folio;
	private Date etaSolicitada;
	private Integer diferencia;
	private Integer idProveedor;
	private String emailsProveedor;
	private String nombreProveedor;
	private String tipo;
	
}
