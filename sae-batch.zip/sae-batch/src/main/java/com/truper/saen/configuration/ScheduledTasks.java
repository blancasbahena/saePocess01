package com.truper.saen.configuration;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.truper.saen.services.ExcelExporterService;
import com.truper.saen.services.IndicatorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@EnableScheduling
public class ScheduledTasks {
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @Autowired private ExcelExporterService  serviceExcel; 
    private final String ZCOM = "N";
    private final String ZMP  = "M";
    @Value("${email.toZCOM}") private String grupoZCOM;
	@Value("${email.toZMP}")  private String grupoZMP;
    @Autowired private IndicatorService indicatorService;
    @Scheduled(cron = "${scheduler.task.cron.update-indicators}")
    public void sendMessageProcess() throws Exception {
      log.info("#### Update of indicators job starting at {}", dateFormat.format(new Date()));
      indicatorService.updateOfIndicators();
      log.info("#### Job executed successfully !!! \n");
    }
    @Scheduled(cron = "${scheduler.task.cron.daily-report-n}")
    public void sendReportProcessZCOM() throws Exception {
      log.info("####sendReportProcess  daily report ZCOM starting at {}", dateFormat.format(new Date()));  
      serviceExcel.envioReporteSaes(grupoZCOM,ZCOM);
      log.info("####sendReportProcess  daily report ZCOM executed successfully !!! \n");
    } 
    @Scheduled(cron = "${scheduler.task.cron.daily-report-m}")
    public void sendReportProcessZMP() throws Exception {
      log.info("####sendReportProcess  daily report ZMP starting at {}", dateFormat.format(new Date()));  
      serviceExcel.envioReporteSaes(grupoZMP,ZMP);
      log.info("####sendReportProcess  daily report ZMP executed successfully !!! \n");
    } 
}
