package com.truper.saen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;

public interface SaeDetalleRevisadoRepository extends JpaRepository<SaeDetalleRevisado, SaeDetalleId> {

  @Transactional
  @Modifying
  @Query("UPDATE SaeDetalleRevisado SET " +
    "IDAMin = :IDAMin, SS = :SS, BO = :BO, OS = :OS, picoPlan = :picoPlan, picoReal = :picoReal, " +
    "diasConsumoDisponible = :diasConsumoDisponible " +
    "WHERE idPO = :idPO AND idPosicion = :idPosicion")
  int updateIndicatorsRevised(@Param("IDAMin") Integer IDAMin, @Param("SS") Double SS, @Param("BO") Double BO,
    @Param("OS") Double OS, @Param("picoPlan") Integer picoPlan, @Param("picoReal") Integer picoReal, 
    @Param("idPO") String idPO, @Param("idPosicion") Integer idPosicion, 
    @Param("diasConsumoDisponible") Integer diasConsumoDisponible);
  
}
