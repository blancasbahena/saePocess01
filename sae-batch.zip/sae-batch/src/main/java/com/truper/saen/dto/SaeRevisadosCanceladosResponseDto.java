package com.truper.saen.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class SaeRevisadosCanceladosResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long folio;
	private Integer idProveedor;
	private String proveedor;
	private String eta;
	@JsonIgnore
	private Integer idaMin;
	private Integer totalCodigos;
	private Integer numeroUnidades;

	private Prioridad prioridad;
	
}
