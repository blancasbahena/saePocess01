package com.truper.saen.services;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.ws.Holder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sap.document.sap.rfc.functions.ZMMINFOBUFFER;
import com.sap.document.sap.rfc.functions.ZMMINFOBUFFERS;
import com.sap.document.sap.rfc.functions.ZMMINFOBUFFER_Service;
import com.sap.document.sap.rfc.functions.ZSDRETURN;
import com.sap.document.sap.rfc.functions.ZSTBUFFEREBELN;
import com.sap.document.sap.rfc.functions.ZTTBUFFEREBELN;
import com.sap.document.sap.rfc.functions.ZTTINFOBUFFERS;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.repository.SaeDetalleRepository;
import com.truper.saen.repository.SaeDetalleRevisadoRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class IndicatorService {

  @Value("${ws.soap.usr}")
  private String USR_WS_SOAP;
  @Value("${ws.soap.pass}")
  private String PASS_WS_SOAP;
  @Value("${ws.soap.urlIndicadores}")
  private String URL_INDICADORES;
  @Value("${sae.detalle.status.list}")
  private List<Integer> STATUS_LIST;

  @Autowired
  private SaeDetalleRepository saeDetalleRepository;

  @Autowired 
  private SaeDetalleRevisadoRepository saeDetalleRevisadoRepository;

  public void updateOfIndicators() throws MalformedURLException {
    log.info("## Getting po's with delivered status...");
    List<ZMMINFOBUFFERS> indicators = getIndicatorsFromSAP(STATUS_LIST);
    log.info("## Updating {} indicators to SAE...", indicators.size());
    validateAndUpdateIndicators(indicators);
    log.info("## Indicators Updated...", indicators.size());
  }

  public List<ZMMINFOBUFFERS> getIndicatorsFromSAP(List<Integer> status) throws MalformedURLException {
    List<SaeDetalle> list = new ArrayList<>();
    list = saeDetalleRepository.findByStatusSae(status);
    //Mandar algo para guardar las POS de list
    List<ZSTBUFFEREBELN> item =  list.stream().map(sarDet -> {
      ZSTBUFFEREBELN po = new ZSTBUFFEREBELN();
      po.setEBELN(sarDet.getIdDetalle().getIdPO());
      po.setEBELP(sarDet.getIdDetalle().getIdPosicion());
      return po;
    }).collect(Collectors.toList());
    log.info("## Request SAE with {} elements", item.size());
    java.net.Authenticator.setDefault(new java.net.Authenticator() {
      @Override
      protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication(USR_WS_SOAP, PASS_WS_SOAP.toCharArray());
      }
    });
    ZMMINFOBUFFER_Service service = new ZMMINFOBUFFER_Service(new URL(URL_INDICADORES));
    ZTTBUFFEREBELN zttbufferebeln = new ZTTBUFFEREBELN();
    Holder<ZTTINFOBUFFERS> eINFOBUFFERS = new Holder<>();
    Holder<ZSDRETURN> eRETURN = new Holder<>();

    zttbufferebeln.getItem().addAll(item);
    ZMMINFOBUFFER function = service.getZMMINFOBUFFER();
    function.zmmINFOBUFFER(zttbufferebeln, new ZTTBUFFEREBELN(), eINFOBUFFERS, eRETURN);

    List<ZMMINFOBUFFERS> response = eINFOBUFFERS.value.getItem();

    log.info("## SAP Response with {} elements", response.size());
    //TODO add list with items not found in SAP
    log.info("## {} SAP elements not found", list.size() - response.size());
    return response;
  }

  public void validateAndUpdateIndicators(List<ZMMINFOBUFFERS> indicators) {
    try {
      for (ZMMINFOBUFFERS indicator : indicators)
        if (!isDelivered(indicator))
          update(indicator);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private boolean isDelivered(ZMMINFOBUFFERS indicator) {
    Integer status = saeDetalleRepository.getStatusByPoAndPosicion(Integer.parseInt(indicator.getPO()), Integer.parseInt(indicator.getEBELP()));
    return status.equals(CatStatusSae.SAE_ENTREGADO.getId());
  }

  private void update(ZMMINFOBUFFERS indicator) {
    try {
      String po = Integer.toString(Integer.parseInt(indicator.getPO()));
      Integer posicion = Integer.parseInt(indicator.getEBELP());
      Integer idaMin = (!indicator.getDIASINVENTARIOARRIBO().isEmpty()) ? Integer.parseInt(indicator.getDIASINVENTARIOARRIBO()): 0;
      Double ss =  (indicator.getSAFETYSTOCK() != null) ? Double.parseDouble(indicator.getSAFETYSTOCK()): 0;
      Double bo = (!indicator.getBACKORDER().isEmpty()) ? Double.parseDouble(indicator.getBACKORDER()): 0;
      Double os = (!indicator.getSOBREINVENTARIO().isEmpty()) ? Double.parseDouble(indicator.getSOBREINVENTARIO()): 0;
      Integer picoPlan = (!indicator.getPICOPLAN().isEmpty()) ? Integer.parseInt(indicator.getPICOPLAN()): 0;
      Integer picoReal = (!indicator.getPICOREAL().isEmpty()) ? Integer.parseInt(indicator.getPICOREAL()): 0;
      Integer diasConsumoDisp = (indicator.getDIASCONSUMODISP() != null && !indicator.getDIASCONSUMODISP().isEmpty()) ? Integer.parseInt(indicator.getDIASCONSUMODISP()): 0;
      saeDetalleRepository.updateIndicators(idaMin, ss, bo, os, picoPlan, picoReal, po, posicion, diasConsumoDisp);
      saeDetalleRevisadoRepository.updateIndicatorsRevised(idaMin, ss, bo, os, picoPlan, picoReal, po, posicion, diasConsumoDisp);
    } catch (Exception e) {
      log.error("Error al guardar la PO {} Posicion {}, IdaMix: {} SS: {}, BO: {}, OS: {}, PicoPlan: {}, PicoReal: {}, DiasConsumoDisp: {}", 
        indicator.getPO(), indicator.getEBELP(), indicator.getDIASINVENTARIOARRIBO(), indicator.getSAFETYSTOCK(), indicator.getBACKORDER(),
        indicator.getSOBREINVENTARIO(), indicator.getPICOPLAN(), indicator.getPICOREAL(), indicator.getDIASCONSUMODISP());
      e.printStackTrace();
    }
  }

}
