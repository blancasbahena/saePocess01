package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ResponseTokenDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String token;
	
	private TokenData data;
	private String mensaje;
}
