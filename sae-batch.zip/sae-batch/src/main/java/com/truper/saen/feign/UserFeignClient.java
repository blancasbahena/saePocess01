package com.truper.saen.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
@FeignClient(name = "userFeignClient", url = "${auth-ws.host}")
public interface UserFeignClient {
	@GetMapping("${auth-ws.path-user}")
	public ResponseEntity<com.truper.saen.commons.dto.ResponseVO> getUser(@RequestParam(required=false) String userName,@RequestParam(required=false) Long id,
			@RequestHeader(value = "Authorization", required = true) String bearerToken);

}