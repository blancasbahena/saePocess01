package com.truper.saen.dto;

import lombok.Data;

@Data
public class SaeIntDto {

	private String tipo;
	private Long User;
	private Integer idProveedor;
	private Long idSae;
	private String comentarios;
	private Integer idStatus;
	private String nombreProveedor;
}
