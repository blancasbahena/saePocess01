package com.truper.saen.controller.example;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.services.JasperReportService;

import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.fill.JRFileVirtualizer;
@RestController
@RequestMapping("/enviadasHistCanceladas")
public class OrdenesController
{
	@Value("${spring.datasource.url}")
    protected String urljdbc;
	@Value("${spring.datasource.username}")
    protected String usuario;
	@Value("${spring.datasource.password}")
    protected String password;
	@Value("${spring.datasource.driver.class}")
    protected String driver;
	@Value("${jasper.reports.paths.templates}")
	protected String pathTemplates;
	@Value("${jasper.reports.paths.tmp}")
	protected String pathTemp;
	@Value("${jasper.reports.paths.out}")
	protected String pathOut;
	@Value("${jasper.reports.paths.logo}")	
	protected String pathLogo;
	private String REPORTE_ORENES_ENVIADAS2 = "OrdenesSAE.jrxml";
	private String destFileName=  "OrdenesSAEExcell"; 
	@Autowired
	private JasperReportService js;
	@Autowired
	public OrdenesController(JasperReportService js)
	{
		this.js=js;
	}
	
	@GetMapping("/reporte/{fechaInicio}/{fechaFinal}/{proveedor}")
	public ResponseEntity<String> exportReport(@PathVariable("fechaInicio") String fechaInicio,@PathVariable("fechaFinal") String fechaFinal,@PathVariable("proveedor") Integer proveedor) 
	{ 
		String idUnico = ""+ (new Date()).getTime();
		destFileName= destFileName + idUnico +".pdf";
		Map<String,Object> mapaParamtros= new HashMap<String, Object>(); 
		mapaParamtros.put("FECHA_INICIAL",fechaInicio);
		mapaParamtros.put("FECHA_FINAL",fechaFinal); 
		mapaParamtros.put("FECHA_ACTUAL",new Date());  
		mapaParamtros.put("PROVEEDOR",proveedor); 
		mapaParamtros.put("LOGO_INSTITUCION",pathLogo); 
		mapaParamtros.put("SCHEMA","public"); 
		String temporal =  pathTemp.replaceAll("xxx", idUnico);
		String resultado="";
		if(creaCarpeta(temporal))
		{
			JRFileVirtualizer virtualizer = new JRFileVirtualizer(2,temporal );
			mapaParamtros.put(JRParameter.REPORT_VIRTUALIZER, virtualizer);
			resultado = js.generaReporte(mapaParamtros,urljdbc,usuario,password,driver,
					pathTemplates +REPORTE_ORENES_ENVIADAS2,
					pathOut+  destFileName );
			Thread archivosAborrarThread = new Thread(() -> {
				File borrar = null;
				try
				{
					borrar = new File(temporal);
					File[] listaArchivosAborrar = borrar.listFiles();
					if(listaArchivosAborrar.length>0)
					{
						for(int i=0;i<listaArchivosAborrar.length;i++)
						{
							listaArchivosAborrar[i].delete();
						}
								
					}
				}
				catch(Exception ex)
				{
					Log.debug("No se pudo borrar el archivo");
				}
			});
			
			
			archivosAborrarThread.start();
		}
		else
		{
			resultado = "Error. Problemas al crear el subdirectorio temporal ["+temporal+"]";
		}
		if(resultado.indexOf("Error")>=0)
			return new  ResponseEntity(resultado,HttpStatus.BAD_REQUEST);
		return new  ResponseEntity(resultado,HttpStatus.OK);
	}
	private boolean creaCarpeta(String archivosABorrar)
	{
		File crear = null;
		try
		{
			crear= new File(archivosABorrar);
			if(!crear.isDirectory())
			{
				if(crear.mkdir())
				{
					return true;
				}
			}
		}
		catch(Exception ex)
		{
			Log.debug("No se pudo borrar el archivo");
		}
		return false;
	}
}
