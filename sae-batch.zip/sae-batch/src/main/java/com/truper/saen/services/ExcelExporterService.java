package com.truper.saen.services;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeReporte;
import com.truper.saen.repository.CatPrioridadDao;
import com.truper.saen.repository.SaeDao;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExcelExporterService {
	private XSSFWorkbook workbook;
	private XSSFSheet sheet;
	private List<SaeReporte> list;
	private String pathOrigen;
	private final String N = "N";
	private final String ZMP = "ZMP";
	private final String ZCOM = "ZCOM";
    @Autowired private SaeDao saeRepository; 
	@Autowired private CatPrioridadDao daoCatPrioridad;
	@Autowired private EmailsServiceReporteImpl emails;
	public void envioReporteSaes(String elementosEmails,String tipo) {
		byte[] bytes = null ;
		try {
			bytes =  export( tipo);
		}catch(Exception e) {
			log.error(e.getMessage(), e);
		}
		 if(bytes!=null) {
			 if(bytes.length>0) {
				 try {
			    	  emails.enviarProgramaDeEntregasDiario(elementosEmails,bytes,tipo,tipo.equals(N));
			      }catch(Exception ex) {
			    	  log.error("################ PROBLEMAS CON CONSULTA {} ",tipo);
			    	  log.error("Error> {} ",ex.getMessage());
			      }
			 }
		 }
	}
	private  byte[]  export(String tipo)
			throws IOException { 
		
		List<SaeReporte> saes = consultaSaes(tipo);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		this.list = saes;
		workbook = new XSSFWorkbook();
		try {
			
			writeHeaderLine();
			writeDataLines();
			workbook.write(bos);
		} catch (Exception e) {
			log.error("Erro> {} ", e.getMessage());
		}
		finally {
	        try {
	            bos.close();
	            workbook.close();
	        } catch (IOException e) {
	        }
	    }
		//exportReport(saes,tipo,"c:\\arch\\proceso.xlsx"); 
		return bos.toByteArray();
	} 

	private void writeHeaderLine() {
		sheet = workbook.createSheet("Reporte");

		Row row = sheet.createRow(0);

		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(12);
		style.setFont(font);
		style.setFillBackgroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		createCellEncabezado(row, 0, "SAE", style);
		createCellEncabezado(row, 1, "Origen", style);
		createCellEncabezado(row, 2, "Tipo", style);
		createCellEncabezado(row, 3, "Prioridad", style);
		createCellEncabezado(row, 4, "Item", style);
		createCellEncabezado(row, 5, "Centro", style);
		createCellEncabezado(row, 6, "Descripción", style);
		createCellEncabezado(row, 7, "Proveedor", style);
		createCellEncabezado(row, 8, "Cantidad", style);
		createCellEncabezado(row, 9, "Unidad de medida", style); // **
		createCellEncabezado(row, 10, "Fecha de entrega (ETA)", style);
		createCellEncabezado(row, 11, "tipo de unidad", style); // ** SAE.idTipoUnidad
		createCellEncabezado(row, 12, "# unidades", style);
		createCellEncabezado(row, 13, "PO", style);
		createCellEncabezado(row, 14, "Familia", style);
		createCellEncabezado(row, 15, "Comentarios", style);

	}

	private void createCellEncabezado(Row row, int columnCount, Object value, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		XSSFFont font = ((XSSFWorkbook) workbook).createFont();
		font.setFontName("Arial");
		font.setFontHeightInPoints((short) 11);
		font.setBold(true);

		HSSFWorkbook hwb = new HSSFWorkbook();
		HSSFPalette palette = hwb.getCustomPalette();
		HSSFColor myColor = palette.findSimilarColor(255, 0, 0);
		HSSFColor myColor2 = palette.findSimilarColor(12, 12, 12);
		style.setFillForegroundColor(myColor.getIndex());
		style.setFillBackgroundColor(myColor2.getIndex());
		headerStyle.setFont(font);
		cell.setCellStyle(style);
		cell.setCellValue((String) value);
	}

	private void createCell(Row row, int columnCount, Object value, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		XSSFFont font = ((XSSFWorkbook) workbook).createFont();
		font.setFontName("Arial");
		font.setFontHeightInPoints((short) 11);
		font.setBold(true);
		headerStyle.setFont(font);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		cell.setCellStyle(style);
		if (value != null) {
			if (value instanceof Integer) {
				cell.setCellValue((Integer) value);
			} else if (value instanceof Boolean) {
				cell.setCellValue((Boolean) value);
			} else if (value instanceof Long) {
				cell.setCellValue((Long) value);
			} else if (value instanceof Date) {
				cell.setCellValue((Date) value != null ? dateFormat.format(value) : "");
			} else if (value instanceof Double) {
				cell.setCellValue((Double) value);
			} else {
				cell.setCellValue((String) value);
			}
		} else {
			cell.setCellValue("-");
		}
	}

	private void writeDataLines() {
		int rowCount = 1;
		try {
			CellStyle style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();
			font.setFontHeight(14);
			style.setFont(font);
			for (SaeReporte r : list) {
				if (r.getSaeDetalles() != null && !r.getSaeDetalles().isEmpty()) {
					log.info("Sae  [ {}  -  size : {} ]", r.getFolio(), r.getSaeDetalles().size());
					for (SaeDetalle d : r.getSaeDetalles()) {
						log.info("Registro [ {} , {} , {} ]", d.getIdDetalle().getIdSae(), d.getIdDetalle().getIdPO(),
								d.getIdDetalle().getIdPosicion());
						Row row = sheet.createRow(rowCount++);
						int columnCount = 0;
						createCell(row, columnCount++, d.getIdDetalle().getIdSae(), style);
						createCell(row, columnCount++, r.getTipo(), style); 
						createCell(row, columnCount++, r.getTipo().equals(N) ? ZCOM : ZMP, style); 
						createCell(row, columnCount++,
								(r.getPrioridades() != null ? r.getPrioridades().getDescripcion() : getCalculaPrioridad(r)),
								style);
						createCell(row, columnCount++, d.getCondicionPago() != null ? d.getCondicionPago() : "", style); 
						createCell(row, columnCount++, d.getCentro() != null ? d.getCentro() : "", style);
						createCell(row, columnCount++, d.getDescripcion() != null ? d.getDescripcion() : "", style);
						createCell(row, columnCount++, r.getNombreProveedor() != null ? r.getNombreProveedor() : "",
								style);
						createCell(row, columnCount++, d.getCantidad() != null ? d.getCantidad() : 0d, style);
						createCell(row, columnCount++, d.getUnidadMedidaProducto(), style);
						createCell(row, columnCount++, r.getEtaSolicitada(), style);
						createCell(row, columnCount++,
								r.getTipoDeUnidad() != null ? r.getTipoDeUnidad().getTipoUnidad() : "-", style);
						createCell(row, columnCount++, r.getUnidades(), style);
						createCell(row, columnCount++, d.getIdDetalle().getIdPO(), style);
						createCell(row, columnCount++, d.getFamilia(), style);
						createCell(row, columnCount++, r.getComentarios(), style);
					}
				} else {
					log.info("Sae  [ {}  -  size : 0 ]", r.getFolio());
				}

			}
		} catch (Exception e) {
			log.error("Erro> {} ", e.getMessage());
		}
	}

	private String getCalculaPrioridad(SaeReporte r) {
		int catPrioridad=0;
		if(r.getTipo()!=null && r.getIdaMin()!=null ) {
			if (r.getTipo().equals("M")) {
				if(r.getIdaMin()<= 15) {
					catPrioridad =1;
				} else if (r.getIdaMin() >= 16 && r.getIdaMin() <= 30) {
					catPrioridad =2;
				} else if (r.getIdaMin() >= 31 && r.getIdaMin() <= 45) {
					catPrioridad =3;
				} else if (r.getIdaMin() >= 46) {
					catPrioridad =4;
				}
			}else if (r.getTipo().equals("N")){
				if (r.getIdaMin() <= 10) {
					catPrioridad =5;
				} else if (r.getIdaMin() >= 11 && r.getIdaMin() <= 30) {
					catPrioridad = 6;
				} else if (r.getIdaMin() > 30) {
					catPrioridad =7;
				}
			}
			if(catPrioridad>0) {
				Optional<CatPrioridades> catalogo =daoCatPrioridad.findById(catPrioridad);
				if(catalogo.isPresent()) {
					catalogo.get().getDescripcion();
				}
			}
		}
		return "-";
	}


	private List<SaeReporte> consultaSaes(String tipo) {
		List<SaeReporte>  lista = new ArrayList<SaeReporte>();
		try {
			lista= saeRepository.findByTipoAndEtaSolicitadaBetweenToday(tipo); 
		}catch(Exception e) {
			e.printStackTrace();
		}
		return lista;
	}
	public void exportReport(List<SaeReporte> saes, String tipo,String outputPath) throws IOException {
		this.list = saes;
		workbook = new XSSFWorkbook();
		try {
			FileOutputStream outputStream = new FileOutputStream(outputPath); 
			writeHeaderLine();
			writeDataLines();
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
		} catch (Exception e) {
			log.error("Erro> {} ", e.getMessage());
		}
	}
}
