package com.truper.saen.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequestDTO implements Serializable{
	private static final long serialVersionUID = -3174009354054453773L;
	private Long folio;
	private Integer idProveedor;
	private String proveedor;
	private String etaSolicitada;
	private Integer plantilla;
}
