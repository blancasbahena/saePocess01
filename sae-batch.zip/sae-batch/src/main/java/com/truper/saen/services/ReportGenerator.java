package com.truper.saen.services;
import java.sql.Connection;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
public class ReportGenerator
{
	public static JasperPrint llenaJasperReport(Connection con,Map<String,Object> mapaParamtros,String JASPERREPORT) {
		JasperPrint reporte=null; 
		try {
			
			JasperReport jasperReport =  JasperCompileManager.compileReport(JASPERREPORT);
			if (con!=null)
			{
				try {
					 reporte =  JasperFillManager.fillReport(jasperReport, mapaParamtros,con);
				} catch (JRException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace(); 
		}
		return reporte;
	}
}
