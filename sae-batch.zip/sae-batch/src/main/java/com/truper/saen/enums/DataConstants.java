package com.truper.saen.enums;

public class DataConstants {
	
	public static final String CONST_PROVEEDOR = "CONST_PROVEEDOR";
	public static final String CONST_FOLIO = "CONST_FOLIO";
	public static final String CONST_DIAS = "CONST_DIAS";
	public static final Integer ID_PLANTILLA_PLANEADOR = 1;
	public static final Integer ID_PLANTILLA_GTEPLANEACION = 2;
	public static final Integer ID_PLANTILLA_CITAS_CONFIRMAR_ZCOM_PLANEACION = 3;
	public static final Integer ID_PLANTILLA_CITAS_CONFIRMAR_ZMP_PLANEACION  = 4;
	public static final Integer ID_PLANTILLA_NOTIFICACION_CITA_PROVEEDOR  = 22;
	public static final Integer ID_PLANTILLA_REPORTE_SAES_ZCOM  = 23;
	public static final Integer ID_PLANTILLA_REPORTE_SAES_ZMP   = 24;
	
	public static final Integer CUATRO_DIAS_NOTIFICACION  = 4;
	public static final Integer CINCO_DIAS_NOTIFICACION  = 5;
	
}
