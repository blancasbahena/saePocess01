package com.truper.saen.services;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;
import org.springframework.stereotype.Service;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
@Service
public class JasperReportService
{
	
	public static String generaReporte(Map<String,Object> mapaParamtros,String urljdbc,String usuario,String password,String driver,String report,String destino)
	{
		boolean conexionTrue=false;
		boolean generateReportf=false;
		boolean exportReportf=false;
		boolean closeConexion=false;
		
		String problemaAbrirConexion="";
		String problemaGenerar="";
		String problemaExportar="";
		String problemaCerrarConexion="";
		long time= (new Date()).getTime();
		Connection con = null;
		try {
			con = connectDatabase(driver,urljdbc,usuario,password);
			conexionTrue=true;
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			problemaAbrirConexion=e1.getMessage();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			problemaAbrirConexion=e1.getMessage();
		}
		System.out.println("Inicio de proceso  " + (new Date()));
		JasperPrint jasperPrint=null;
		try
		{
			jasperPrint= ReportGenerator.llenaJasperReport(con,mapaParamtros,report);
			generateReportf=true;
		}
		catch(Exception e)
		{
			problemaGenerar=e.getMessage();
		}
		System.out.println("Envia Reporte a Jasper     " + (new Date())); 
		
		try {
			JasperExportManager.exportReportToPdfFile(jasperPrint, destino);
			exportReportf=true;
		} catch (JRException e1) {
			// TODO Auto-generated catch block
			problemaExportar=e1.getMessage();
		}
		System.out.println("Crea el archivo    " + (new Date())+"   --->    "+destino);
		try {
			con.close();
			closeConexion=true;
		} catch (SQLException e) {
			problemaCerrarConexion =  e.getMessage();
		}
		System.out.println("Conexion  Cerrada   " + (new Date()));
		
		if(conexionTrue & generateReportf & exportReportf & closeConexion)
			return destino;
		if(!conexionTrue)
			return "Error."+problemaAbrirConexion;
		if(!generateReportf)
			return "Error."+problemaGenerar;
		if(!exportReportf)
			return "Error."+problemaExportar;
		if(closeConexion)
			return "Error."+problemaCerrarConexion;
		return "Error.problema desconocido";
	}
	public static Connection connectDatabase(String driver, String url, String usuario, String password) throws ClassNotFoundException, SQLException 
	{  
		Class.forName(driver);
		Connection connection = DriverManager.getConnection(url,usuario,password);
        return connection;
	}
}
