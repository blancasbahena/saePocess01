package com.truper.saen.dto;

import java.util.Date;

public interface DetalleSaeDTO {
		
	Long getFolio();
	Date getEtaSolicitada();
	Integer getDiferencia();
	Integer getIdProveedor();
	String getNombreProveedor();
	String getTipo();
	
	void setFolio(Long f);
	void setEtaSolicitada(Date e);
	void setDiferencia(Integer d);
	void setIdProveedor(Integer p);
	void setNombreProveedor(String n);
	void setTipo(String t);
}
