package com.truper.saen.dto;

import java.io.Serializable;

import com.truper.saen.enums.Mensajes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String mensaje;
	private String tipoMensaje;
	private String descripcionError;

	public ResponseVO createSuccess(String mensaje) {
		ResponseVO responseVO = new ResponseVO() {
			private static final long serialVersionUID = 1L;
		};

		responseVO.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		responseVO.setMensaje(mensaje);
		return responseVO;
	}

	public ResponseVO createError(String descripcionError) {
		ResponseVO responseVO = new ResponseVO() {
			private static final long serialVersionUID = 1L;
		};

		responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
		responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
		responseVO.setDescripcionError(descripcionError);
		return responseVO;
	}

}
