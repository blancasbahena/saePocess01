package com.truper.saen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.Sae;
import com.truper.saen.dto.DetalleSaeDTO;

@Repository
public interface SaeRepository extends JpaRepository<Sae, Long> {
	 
	@Query(value = "select s.folio, s.ETASolicitada as etaSolicitada, "
			+ "DATEDIFF(DAY, GETDATE(), s.ETASolicitada) as diferencia, s.idProveedor, "
			+ "s.nombreProveedor, s.tipo from Sae s "
			+ "inner join sae_citas sc on s.folio = sc.id_sae "
			+ "where sc.id_status = 0", nativeQuery = true)
	List<DetalleSaeDTO> findCitasSinConfirmar();

}
