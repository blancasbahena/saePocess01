package com.truper.saen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeReporte;

@Repository
public interface SaeDao extends JpaRepository<SaeReporte, Long> {
	
	@Query(value="SELECT * FROM SAE s WHERE"
			+ " CONVERT (date,ETASolicitada) = CONVERT (date, GETDATE())"
			+ " and tipo =?1 ",nativeQuery = true )
	List<SaeReporte> findByTipoAndEtaSolicitadaBetweenToday(String tipo);
}
