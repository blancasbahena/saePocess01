package com.truper.saen.dto;

import lombok.Data;

@Data
public class RequestEmail {
	private String emails;
	private String tipo; 
}
