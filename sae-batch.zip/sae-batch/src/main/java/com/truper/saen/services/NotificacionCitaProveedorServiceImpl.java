package com.truper.saen.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.dto.DetalleSaeDTO;
import com.truper.saen.dto.NotificacionCitaProveedorDTO;
import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsProveedorDTO;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.enums.DataConstants;
import com.truper.saen.feign.CatalogsFeignClient;
import com.truper.saen.repository.SaeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificacionCitaProveedorServiceImpl implements NotificacionCitaProveedorService {

	@Autowired
	private SaeRepository saeRepository;

	@Autowired
	private EmailsService emailsService;

	@Value("${catalogs.username}")
	private String username;

	@Value("${catalogs.password}")
	private String password;

	@Autowired
	private CatalogsFeignClient catalogsFeignClient;

	@Autowired
	private ModelMapper modelMapper;

	@Scheduled(cron = "${scheduler.task.cron.notificacion-cita-proveedor}")
	@Override
	public void enviarNotificacionCitaProveedor() {

		log.info("[Service /getDataWsPosApi] | INICIO - HORA - {} ", Fechas.getHoraLogeo());

		List<DetalleSaeDTO> citas = saeRepository.findCitasSinConfirmar();

		List<DetalleSaeDTO> foliosCuatroDias = new ArrayList<>();
		List<DetalleSaeDTO> foliosCincoDias = new ArrayList<>();

		foliosCuatroDias = citas.stream().filter(cita -> cita.getDiferencia() == DataConstants.CUATRO_DIAS_NOTIFICACION)
				.collect(Collectors.toList());
		foliosCincoDias = citas.stream().filter(cita -> cita.getDiferencia() == DataConstants.CINCO_DIAS_NOTIFICACION)
				.collect(Collectors.toList());

		List<NotificacionCitaProveedorDTO> listaNotificacionCuatroDias = foliosCuatroDias.stream()
				.map(d -> modelMapper.map(d, NotificacionCitaProveedorDTO.class)).collect(Collectors.toList());
		
		List<NotificacionCitaProveedorDTO> listaNotificacionCincoDias = foliosCincoDias.stream()
				.map(d -> modelMapper.map(d, NotificacionCitaProveedorDTO.class)).collect(Collectors.toList());

				
		listaNotificacionCuatroDias.forEach(obj -> {

			String emailsProveedor = null;

			try {
				emailsProveedor = obtenerCorreosProveedor(obj.getIdProveedor());
				obj.setEmailsProveedor(emailsProveedor);
				log.info("Parametro del proceso de envio de correo emailsProveedor : {}", emailsProveedor);
			} catch (Exception ex) {
				log.error("Ocurrio un error al obtener el correo del proveedor : {}", obj.getIdProveedor());
			}

		});   
			
		listaNotificacionCincoDias.forEach(obj -> {

			String emailsProveedor = null;

			try {
				emailsProveedor = obtenerCorreosProveedor(obj.getIdProveedor());
				obj.setEmailsProveedor(emailsProveedor);
				log.info("Parametro del proceso de envio de correo emailsProveedor : {}", emailsProveedor);
			} catch (Exception ex) {
				log.error("Ocurrio un error al obtener el correo del proveedor : {}", obj.getIdProveedor());
			}

		}); 

		enviarNotificacionPorProveedor(listaNotificacionCuatroDias);
		enviarNotificacionPorProveedor(listaNotificacionCincoDias);

	}

	private String obtenerCorreosProveedor(Integer idProveedor) throws Exception {
		log.info("Servicio para obtener correos de proveedor  {}  - {}  ", idProveedor, new Date());
		RequestToken requestToken = new RequestToken();
		requestToken.setPassword(password);
		requestToken.setUsername(username);
		ResponseTokenDTO token = catalogsFeignClient.getToken(requestToken);

		if (token != null) {
			ResponseCatalogsProveedorDTO response = catalogsFeignClient.getDataProveedor(idProveedor.toString(),
					"Bearer " + token.getData().getToken());
			if (response.getData().getProveedor().getEmail() == null
					|| response.getData().getProveedor().getEmail().equals("")) {
				throw new Exception("Error al obtener los correos del proveedor");
			}
			log.info("Servicio para obtener correos {} - {}  ", response.getData().getProveedor().getEmail(),
					new Date());
			return response.getData().getProveedor().getEmail();
		} else {
			throw new Exception("Error al obtener token para el envio de correo");
		}

	}

	private void enviarNotificacionPorProveedor(List<NotificacionCitaProveedorDTO> listaNotificacion) {

		listaNotificacion.stream().map(obj -> obj.getIdProveedor()).distinct().forEach(d -> {

			try {
				enviar(listaNotificacion.stream().filter(b -> b.getIdProveedor().intValue() == d.intValue())
						.map(n -> n.getTipo() + n.getFolio()).collect(Collectors.toList()),

						listaNotificacion.stream().filter(b -> b.getIdProveedor().intValue() == d.intValue())
								.map(n -> n.getEmailsProveedor()).findFirst().get(),

						listaNotificacion.stream().filter(b -> b.getIdProveedor().intValue() == d.intValue())
								.map(n -> n.getNombreProveedor()).findFirst().get(),
						listaNotificacion.get(0).getDiferencia());
			} catch (Exception e) {
				log.error("Error al intentar enviar la notificacion: {} ", e);
			}

		});

	}

	private void enviar(List<String> folios, String correos, String nombreProveedor, Integer dias) throws Exception {

		if (folios.isEmpty() || folios == null) {
			throw new Exception("El parametro folios es obligatorio");
		} else if (correos.equals("") || correos == null) {
			throw new Exception("El parametro correos es obligatorio");
		} else if (nombreProveedor.equals("") || nombreProveedor == null) {
			throw new Exception("El parametro nombreProveedor es obligatorio");
		} else if (dias == null) {
			throw new Exception("El parametro dias es obligatorio");
		}

		Integer resultado = emailsService.enviarNotificacionCitaProveedor(folios, correos, nombreProveedor, dias);

		if (resultado == 1) {

			log.info("Notificacion enviada correctamente con parametros: {} - {} - {} - {} ", folios, correos,
					nombreProveedor, dias);

		} else {

			String mesj = "Problemas con servicio batch";

			if (resultado.intValue() == 2) {
				mesj = "Problemas con servicio";
			} else if (resultado.intValue() == 3) {
				mesj = "Problemas sin correos del proveedor";
			}

			log.info("Error en el envio de correo {} ", mesj);
		}

	}

}
