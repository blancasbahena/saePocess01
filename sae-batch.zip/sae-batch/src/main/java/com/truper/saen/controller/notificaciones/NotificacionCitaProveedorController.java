package com.truper.saen.controller.notificaciones;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.commons.enums.Mensajes;
import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.services.NotificacionCitaProveedorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/notificaciones-cita-proveedor")
public class NotificacionCitaProveedorController {

	@Autowired
	private NotificacionCitaProveedorService notificacionCitaProveedorService;

	@GetMapping
	public ResponseEntity<ResponseVO> enviarNotificacionCitaProveedor(@RequestHeader("Authorization") String authorization) {

		log.info("[GET /enviarNotificacionCitaProveedor] | INICIO - HORA - {} ", Fechas.getHoraLogeo());
		
		String folio = UUID.randomUUID().toString();
		Map<String, Object> formData = new HashMap<>();
		
		try {
			
			notificacionCitaProveedorService.enviarNotificacionCitaProveedor();
			formData.put("respuesta", "Proceso de envio de notificaciones al proveedor ejecutado con exito");
			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folio).data(formData)
					.build());
			
		} catch (Exception e) {
			log.error("Ocurrio un error en el envio de notificaciones al proveedor: {} ", e);
			formData.put("respuesta", e.getMessage());
			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje())
					.folio(folio).data(formData).build(), HttpStatus.BAD_REQUEST);
		} finally {
			log.info("[GET /enviarNotificacionCitaProveedor] | INICIO - HORA - {} ", Fechas.getHoraLogeo());
		}
		
	}

}
