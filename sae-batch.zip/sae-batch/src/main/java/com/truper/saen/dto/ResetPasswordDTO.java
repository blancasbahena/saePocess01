package com.truper.saen.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResetPasswordDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7904483614341342824L;
	private String nombre;
	private String correo;
	private String copia;
	private String subject;
	private Integer numeroPlantilla;
	private String usuario; 
}
