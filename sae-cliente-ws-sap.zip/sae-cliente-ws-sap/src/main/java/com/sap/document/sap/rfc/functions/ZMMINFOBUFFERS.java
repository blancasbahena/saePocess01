
package com.sap.document.sap.rfc.functions;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para ZMM_INFO_BUFFERS complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ZMM_INFO_BUFFERS">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MANDT" type="{urn:sap-com:document:sap:rfc:functions}clnt3"/>
 *         &lt;element name="PO" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="EBELP" type="{urn:sap-com:document:sap:rfc:functions}numeric5"/>
 *         &lt;element name="PO_ESPEJO" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="EBELNP_ESPEJO" type="{urn:sap-com:document:sap:rfc:functions}numeric5"/>
 *         &lt;element name="MATNR" type="{urn:sap-com:document:sap:rfc:functions}char18"/>
 *         &lt;element name="PLANEADOR" type="{urn:sap-com:document:sap:rfc:functions}char3"/>
 *         &lt;element name="CODIGO" type="{urn:sap-com:document:sap:rfc:functions}char40"/>
 *         &lt;element name="CANTIDAD" type="{urn:sap-com:document:sap:rfc:functions}quantum13.3"/>
 *         &lt;element name="SAFETY_STOCK" type="{urn:sap-com:document:sap:rfc:functions}char17"/>
 *         &lt;element name="DIAS_INVENTARIO_ARRIBO" type="{urn:sap-com:document:sap:rfc:functions}char16"/>
 *         &lt;element name="BACK_ORDER" type="{urn:sap-com:document:sap:rfc:functions}char16"/>
 *         &lt;element name="SOBRE_INVENTARIO" type="{urn:sap-com:document:sap:rfc:functions}char16"/>
 *         &lt;element name="WERKS" type="{urn:sap-com:document:sap:rfc:functions}char4"/>
 *         &lt;element name="PICO_PLAN" type="{urn:sap-com:document:sap:rfc:functions}char15"/>
 *         &lt;element name="PICO_REAL" type="{urn:sap-com:document:sap:rfc:functions}char15"/>
 *         &lt;element name="DIAS_CONSUMO_DISP" type="{urn:sap-com:document:sap:rfc:functions}char16"/>
 *         &lt;element name="ERDAT" type="{urn:sap-com:document:sap:rfc:functions}date10"/>
 *         &lt;element name="ERZET" type="{urn:sap-com:document:sap:rfc:functions}time"/>
 *         &lt;element name="ERNAM" type="{urn:sap-com:document:sap:rfc:functions}char12"/>
 *         &lt;element name="AENAM" type="{urn:sap-com:document:sap:rfc:functions}char12"/>
 *         &lt;element name="AEDAT" type="{urn:sap-com:document:sap:rfc:functions}date10"/>
 *         &lt;element name="AEZET" type="{urn:sap-com:document:sap:rfc:functions}time"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ZMM_INFO_BUFFERS", propOrder = {
    "mandt",
    "po",
    "ebelp",
    "poespejo",
    "ebelnpespejo",
    "matnr",
    "planeador",
    "codigo",
    "cantidad",
    "safetystock",
    "diasinventarioarribo",
    "backorder",
    "sobreinventario",
    "werks",
    "picoplan",
    "picoreal",
    "diasconsumodisp",
    "erdat",
    "erzet",
    "ernam",
    "aenam",
    "aedat",
    "aezet"
})
public class ZMMINFOBUFFERS {

    @XmlElement(name = "MANDT", required = true)
    protected String mandt;
    @XmlElement(name = "PO", required = true)
    protected String po;
    @XmlElement(name = "EBELP", required = true)
    protected String ebelp;
    @XmlElement(name = "PO_ESPEJO", required = true)
    protected String poespejo;
    @XmlElement(name = "EBELNP_ESPEJO", required = true)
    protected String ebelnpespejo;
    @XmlElement(name = "MATNR", required = true)
    protected String matnr;
    @XmlElement(name = "PLANEADOR", required = true)
    protected String planeador;
    @XmlElement(name = "CODIGO", required = true)
    protected String codigo;
    @XmlElement(name = "CANTIDAD", required = true)
    protected BigDecimal cantidad;
    @XmlElement(name = "SAFETY_STOCK", required = true)
    protected String safetystock;
    @XmlElement(name = "DIAS_INVENTARIO_ARRIBO", required = true)
    protected String diasinventarioarribo;
    @XmlElement(name = "BACK_ORDER", required = true)
    protected String backorder;
    @XmlElement(name = "SOBRE_INVENTARIO", required = true)
    protected String sobreinventario;
    @XmlElement(name = "WERKS", required = true)
    protected String werks;
    @XmlElement(name = "PICO_PLAN", required = true)
    protected String picoplan;
    @XmlElement(name = "PICO_REAL", required = true)
    protected String picoreal;
    @XmlElement(name = "DIAS_CONSUMO_DISP", required = true)
    protected String diasconsumodisp;
    @XmlElement(name = "ERDAT", required = true)
    protected String erdat;
    @XmlElement(name = "ERZET", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar erzet;
    @XmlElement(name = "ERNAM", required = true)
    protected String ernam;
    @XmlElement(name = "AENAM", required = true)
    protected String aenam;
    @XmlElement(name = "AEDAT", required = true)
    protected String aedat;
    @XmlElement(name = "AEZET", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar aezet;

    /**
     * Obtiene el valor de la propiedad mandt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMANDT() {
        return mandt;
    }

    /**
     * Define el valor de la propiedad mandt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMANDT(String value) {
        this.mandt = value;
    }

    /**
     * Obtiene el valor de la propiedad po.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPO() {
        return po;
    }

    /**
     * Define el valor de la propiedad po.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPO(String value) {
        this.po = value;
    }

    /**
     * Obtiene el valor de la propiedad ebelp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBELP() {
        return ebelp;
    }

    /**
     * Define el valor de la propiedad ebelp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBELP(String value) {
        this.ebelp = value;
    }

    /**
     * Obtiene el valor de la propiedad poespejo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOESPEJO() {
        return poespejo;
    }

    /**
     * Define el valor de la propiedad poespejo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOESPEJO(String value) {
        this.poespejo = value;
    }

    /**
     * Obtiene el valor de la propiedad ebelnpespejo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBELNPESPEJO() {
        return ebelnpespejo;
    }

    /**
     * Define el valor de la propiedad ebelnpespejo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBELNPESPEJO(String value) {
        this.ebelnpespejo = value;
    }

    /**
     * Obtiene el valor de la propiedad matnr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMATNR() {
        return matnr;
    }

    /**
     * Define el valor de la propiedad matnr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMATNR(String value) {
        this.matnr = value;
    }

    /**
     * Obtiene el valor de la propiedad planeador.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLANEADOR() {
        return planeador;
    }

    /**
     * Define el valor de la propiedad planeador.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLANEADOR(String value) {
        this.planeador = value;
    }

    /**
     * Obtiene el valor de la propiedad codigo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCODIGO() {
        return codigo;
    }

    /**
     * Define el valor de la propiedad codigo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCODIGO(String value) {
        this.codigo = value;
    }

    /**
     * Obtiene el valor de la propiedad cantidad.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCANTIDAD() {
        return cantidad;
    }

    /**
     * Define el valor de la propiedad cantidad.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCANTIDAD(BigDecimal value) {
        this.cantidad = value;
    }

    /**
     * Obtiene el valor de la propiedad safetystock.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAFETYSTOCK() {
        return safetystock;
    }

    /**
     * Define el valor de la propiedad safetystock.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAFETYSTOCK(String value) {
        this.safetystock = value;
    }

    /**
     * Obtiene el valor de la propiedad diasinventarioarribo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIASINVENTARIOARRIBO() {
        return diasinventarioarribo;
    }

    /**
     * Define el valor de la propiedad diasinventarioarribo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIASINVENTARIOARRIBO(String value) {
        this.diasinventarioarribo = value;
    }

    /**
     * Obtiene el valor de la propiedad backorder.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBACKORDER() {
        return backorder;
    }

    /**
     * Define el valor de la propiedad backorder.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBACKORDER(String value) {
        this.backorder = value;
    }

    /**
     * Obtiene el valor de la propiedad sobreinventario.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOBREINVENTARIO() {
        return sobreinventario;
    }

    /**
     * Define el valor de la propiedad sobreinventario.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOBREINVENTARIO(String value) {
        this.sobreinventario = value;
    }

    /**
     * Obtiene el valor de la propiedad werks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWERKS() {
        return werks;
    }

    /**
     * Define el valor de la propiedad werks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWERKS(String value) {
        this.werks = value;
    }

    /**
     * Obtiene el valor de la propiedad picoplan.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPICOPLAN() {
        return picoplan;
    }

    /**
     * Define el valor de la propiedad picoplan.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPICOPLAN(String value) {
        this.picoplan = value;
    }

    /**
     * Obtiene el valor de la propiedad picoreal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPICOREAL() {
        return picoreal;
    }

    /**
     * Define el valor de la propiedad picoreal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPICOREAL(String value) {
        this.picoreal = value;
    }

    /**
     * Obtiene el valor de la propiedad diasconsumodisp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIASCONSUMODISP() {
        return diasconsumodisp;
    }

    /**
     * Define el valor de la propiedad diasconsumodisp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIASCONSUMODISP(String value) {
        this.diasconsumodisp = value;
    }

    /**
     * Obtiene el valor de la propiedad erdat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getERDAT() {
        return erdat;
    }

    /**
     * Define el valor de la propiedad erdat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setERDAT(String value) {
        this.erdat = value;
    }

    /**
     * Obtiene el valor de la propiedad erzet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getERZET() {
        return erzet;
    }

    /**
     * Define el valor de la propiedad erzet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setERZET(XMLGregorianCalendar value) {
        this.erzet = value;
    }

    /**
     * Obtiene el valor de la propiedad ernam.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getERNAM() {
        return ernam;
    }

    /**
     * Define el valor de la propiedad ernam.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setERNAM(String value) {
        this.ernam = value;
    }

    /**
     * Obtiene el valor de la propiedad aenam.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAENAM() {
        return aenam;
    }

    /**
     * Define el valor de la propiedad aenam.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAENAM(String value) {
        this.aenam = value;
    }

    /**
     * Obtiene el valor de la propiedad aedat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAEDAT() {
        return aedat;
    }

    /**
     * Define el valor de la propiedad aedat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAEDAT(String value) {
        this.aedat = value;
    }

    /**
     * Obtiene el valor de la propiedad aezet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAEZET() {
        return aezet;
    }

    /**
     * Define el valor de la propiedad aezet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAEZET(XMLGregorianCalendar value) {
        this.aezet = value;
    }

}
