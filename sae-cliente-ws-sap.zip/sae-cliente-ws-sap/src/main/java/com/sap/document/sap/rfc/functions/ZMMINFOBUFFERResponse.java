
package com.sap.document.sap.rfc.functions;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="E_INFO_BUFFERS" type="{urn:sap-com:document:sap:rfc:functions}ZTT_INFO_BUFFERS"/>
 *         &lt;element name="E_RETURN" type="{urn:sap-com:document:sap:rfc:functions}ZSDRETURN"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "einfobuffers",
    "ereturn"
})
@XmlRootElement(name = "ZMM_INFO_BUFFERResponse")
public class ZMMINFOBUFFERResponse {

    @XmlElement(name = "E_INFO_BUFFERS", required = true)
    protected ZTTINFOBUFFERS einfobuffers;
    @XmlElement(name = "E_RETURN", required = true)
    protected ZSDRETURN ereturn;

    /**
     * Obtiene el valor de la propiedad einfobuffers.
     * 
     * @return
     *     possible object is
     *     {@link ZTTINFOBUFFERS }
     *     
     */
    public ZTTINFOBUFFERS getEINFOBUFFERS() {
        return einfobuffers;
    }

    /**
     * Define el valor de la propiedad einfobuffers.
     * 
     * @param value
     *     allowed object is
     *     {@link ZTTINFOBUFFERS }
     *     
     */
    public void setEINFOBUFFERS(ZTTINFOBUFFERS value) {
        this.einfobuffers = value;
    }

    /**
     * Obtiene el valor de la propiedad ereturn.
     * 
     * @return
     *     possible object is
     *     {@link ZSDRETURN }
     *     
     */
    public ZSDRETURN getERETURN() {
        return ereturn;
    }

    /**
     * Define el valor de la propiedad ereturn.
     * 
     * @param value
     *     allowed object is
     *     {@link ZSDRETURN }
     *     
     */
    public void setERETURN(ZSDRETURN value) {
        this.ereturn = value;
    }

}
