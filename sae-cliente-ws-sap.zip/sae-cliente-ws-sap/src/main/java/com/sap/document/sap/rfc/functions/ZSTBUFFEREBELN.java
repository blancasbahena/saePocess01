
package com.sap.document.sap.rfc.functions;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ZST_BUFFER_EBELN complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ZST_BUFFER_EBELN">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EBELN" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="EBELP" type="{urn:sap-com:document:sap:rfc:functions}numeric5"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ZST_BUFFER_EBELN", propOrder = {
    "ebeln",
    "ebelp"
})
public class ZSTBUFFEREBELN {

    @XmlElement(name = "EBELN", required = true)
    protected String ebeln;
    @XmlElement(name = "EBELP", required = true)
    protected String ebelp;

    /**
     * Obtiene el valor de la propiedad ebeln.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBELN() {
        return ebeln;
    }

    /**
     * Define el valor de la propiedad ebeln.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBELN(String value) {
        this.ebeln = value;
    }

    /**
     * Obtiene el valor de la propiedad ebelp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBELP() {
        return ebelp;
    }

    /**
     * Define el valor de la propiedad ebelp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBELP(String value) {
        this.ebelp = value;
    }

}
