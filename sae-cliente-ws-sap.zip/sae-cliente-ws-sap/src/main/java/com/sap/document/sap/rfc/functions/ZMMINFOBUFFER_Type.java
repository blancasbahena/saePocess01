
package com.sap.document.sap.rfc.functions;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="I_EBELN" type="{urn:sap-com:document:sap:rfc:functions}ZTT_BUFFER_EBELN"/>
 *         &lt;element name="I_EBELN_ESPEJO" type="{urn:sap-com:document:sap:rfc:functions}ZTT_BUFFER_EBELN"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "iebeln",
    "iebelnespejo"
})
@XmlRootElement(name = "ZMM_INFO_BUFFER")
public class ZMMINFOBUFFER_Type {

    @XmlElement(name = "I_EBELN", required = true)
    protected ZTTBUFFEREBELN iebeln;
    @XmlElement(name = "I_EBELN_ESPEJO", required = true)
    protected ZTTBUFFEREBELN iebelnespejo;

    /**
     * Obtiene el valor de la propiedad iebeln.
     * 
     * @return
     *     possible object is
     *     {@link ZTTBUFFEREBELN }
     *     
     */
    public ZTTBUFFEREBELN getIEBELN() {
        return iebeln;
    }

    /**
     * Define el valor de la propiedad iebeln.
     * 
     * @param value
     *     allowed object is
     *     {@link ZTTBUFFEREBELN }
     *     
     */
    public void setIEBELN(ZTTBUFFEREBELN value) {
        this.iebeln = value;
    }

    /**
     * Obtiene el valor de la propiedad iebelnespejo.
     * 
     * @return
     *     possible object is
     *     {@link ZTTBUFFEREBELN }
     *     
     */
    public ZTTBUFFEREBELN getIEBELNESPEJO() {
        return iebelnespejo;
    }

    /**
     * Define el valor de la propiedad iebelnespejo.
     * 
     * @param value
     *     allowed object is
     *     {@link ZTTBUFFEREBELN }
     *     
     */
    public void setIEBELNESPEJO(ZTTBUFFEREBELN value) {
        this.iebelnespejo = value;
    }

}
