package com.truper.saen.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaeNacCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
