package com.truper.saen.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class ModificadoDTO {
	private Boolean esNuevo;

	private Boolean esBorrado;

	private Boolean esModificado;

	private Integer pesoModificado;

	private Double volumenModificado;

	private Double cantidadModificado;
}