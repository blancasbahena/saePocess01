package com.truper.saen.commons.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SaeDto implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -4580759465506493661L;
	private Long folio;
	
	private String tipo;
	
	private Integer idStatus;
	
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date eta;
	
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date etaSolicitada;
	
	private Integer idProveedor;
	
	private Integer idSucursal;
	
	private Integer idTipoUnidad;
	
	private Integer unidades;
	
	private Integer idaMin;
	
	private Double bo;
	
	private Double os;
	
	private Integer totalCodigos;
	
	private Double monto;
	
	private Short conteoRevisado;
	
	private Short conteoRechazado;
	
	private Integer idConfirmador;
	
	private Date fechaConfirmacion;
	
	private Date rechazoConfirmacion;
	
	private Date created;
	
	private Date lastModified;
	
	private UserDTO userModified;
	
	private UserDTO userCreated;
	
	private String comentarios;	
	
	private List<PoDetalleDto> saeDetalles;
	/** campos para rechazo aprobar sae */
	
	private UserDTO userReject;
	
	private UserDTO userApproval;
	
	private Date dateReject;
	
	private Date dateApproval;
	
	private String msgReject;
	
	private Date date1erApproval;
	
	private UserDTO userApprovalGte;
	
	private Date dateApprovalGte;
	
	private UserDTO userRejectGte;
	  
	private Date dateRejectGte;
	 
	private String msgRejectGte;
	
	private UserDTO userApprovalOver;
	
	private Date dateApprovalOver;
	
	private UserDTO userRejectOver;
	  
	private Date dateRejectOver;
	 
	private String msgRejectOver;
	
	private List<SapDto> sapDetalle; 
	
	/** campos para recchazo aprobar sae con usuario de liberacion */
	private UserDTO userCancelaLibera;
	
	private UserDTO userRejectLibera;

	private UserDTO userApprovalLibera;
	
	private Date dateApprovalLibera;

	private Date dateCancelaLibera;
	  
	private Date dateRejectLibera;
	
	private String msgCancelaLibera;
	
	private String msgRejectLibera;
	
	private String sucursalCentro;
	
	private Boolean citaReprogramada;
	
	private String centro;
	
}
