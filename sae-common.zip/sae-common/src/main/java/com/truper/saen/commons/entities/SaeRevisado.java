package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;
import net.bytebuddy.implementation.bind.annotation.IgnoreForBinding;

@Data
@Entity
@Table(name = "SaeRevisados")
public class SaeRevisado implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "folio")
	private Long folio;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETA")
	private Date eta;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETASolicitada")
	private Date etaSolicitada;
	
	@Column(name = "Unidades")
	private Integer unidades;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "tipoUnidad",referencedColumnName = "idTipoUnidad")
	private CatTipoDeUnidad tipoDeUnidad;
	
	@Column(name = "created")
	private Date created;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userCreated", referencedColumnName = "id")
    private User userCreated;

	@Column(name = "tipoSae", length = 1)
	private String tipo;
	
	@Column(name = "idProveedor")
	private Integer idProveedor;
	
	
	@OneToMany(mappedBy = "sae", fetch = FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@JsonManagedReference
    private List<SaeDetalleRevisado> saeDetalles;
	
	
	@OneToOne(fetch = FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @JoinColumn(name = "folio", referencedColumnName = "folio")
	private Sae sae;
	
	@Column(name = "centro")
	private String centro;
	
	
}
