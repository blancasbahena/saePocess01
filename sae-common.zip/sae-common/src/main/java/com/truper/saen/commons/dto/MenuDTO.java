package com.truper.saen.commons.dto;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class MenuDTO {

	private Long id;

	private String descripcion;
	
	private String icon;
	
	private String tooltip;
	
	private String url;
	
	private Long parent;
	
	private String tipo;
	
	private String accion;
	
	private String classnamecss;
	
	private List<MenuDTO> subMenus;
	
	private List<MenuDTO> menusAccion;
	
}
