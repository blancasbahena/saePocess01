package com.truper.saen.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResponseMessage {
	TIPO_EXITO("S"),
	TIPO_WARNING("W"),
	TIPO_ERROR("E"),
	MSG_WARNING("No se encontraron resultados."),
	MSG_ERROR("Hubo un error al ejecutar la Operacion."),
	MSG_EXITO("Proceso ejecutado correctamente."),
	MSG_NOTFOUND("Data Not Found"),
	MSG_REQUEST_SUCCCESSFUL("Request Successful"),
	MSG_UPDATED_RESOURCE("Updated Resource"),
	MSG_ADDED_RESOURCE("Added resource"),
	MSG_RESOURCE_REMOVED("Resource Removed"),
	MSG_RESOURCE_EXISTS("Resource Exists"),
	MSG_RESOURCE_NO_EXISTS("Resource No Exists"),
	MSG_ID_NOT_MATCH("ID Not Match");
	private String mensaje;
}
