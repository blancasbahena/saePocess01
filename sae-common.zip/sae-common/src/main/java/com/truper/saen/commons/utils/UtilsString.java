package com.truper.saen.commons.utils;

public class UtilsString {

	public static String replaceString2String(String cadenaSource, String cadenaBuscar, String cadenaARemplazar) {

		String reString = cadenaSource;
		if (cadenaARemplazar != null && cadenaBuscar != null && cadenaSource != null) {
			reString = cadenaSource.replaceAll(cadenaBuscar, cadenaARemplazar);
		}
		return reString;
	}

}
