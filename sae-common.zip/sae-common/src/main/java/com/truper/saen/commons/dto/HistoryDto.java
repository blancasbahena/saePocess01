package com.truper.saen.commons.dto;

import lombok.Data;

@Data
public class HistoryDto {

	private Long idSae;
	private Short idAccion;
	private String comentario;
	
	
}
