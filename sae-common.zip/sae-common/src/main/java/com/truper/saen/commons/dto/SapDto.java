package com.truper.saen.commons.dto;

import lombok.Data;

@Data
public class SapDto {
	
	private String idPO;
	private String idPosicion;

}
