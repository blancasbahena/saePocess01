package com.truper.saen.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Pos {
	private String volume;
	private String item;
	private String code;
	private String qty;
	private String folio;
	private String weight;
	private String desc; 

}
