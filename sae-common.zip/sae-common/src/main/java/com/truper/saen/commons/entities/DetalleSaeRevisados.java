package com.truper.saen.commons.entities;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "SaeDetalleRevisado")
public class DetalleSaeRevisados {
		
	@EmbeddedId
	private SaeDetalleRevisadoId idSaeDetalleRevisado;
	
	private Integer posicion;
	
	private Integer cantidad;
	
	private Double peso;
	
	private Double volumen;
	
	private Boolean esBorrado;
	
	private Boolean esNuevo;
	
	private Boolean esModificado;
	
	private Date created;
	
	private Boolean necesitaAutorizacion;
	
	private String codigo;
	
	private String descripcion;
	
	@JsonIgnore
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
	@JoinColumn(name = "idSae", insertable = false, updatable = false)
	private SaeRevisado saeRevisado;
}
