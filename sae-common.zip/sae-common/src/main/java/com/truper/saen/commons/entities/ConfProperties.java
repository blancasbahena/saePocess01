package com.truper.saen.commons.entities;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Table(name = "confProperties")
@Data
public class ConfProperties  implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@Column(name = "llave")
	private String llave;
	@Basic(optional = false)
	@Column(name = "value")
	private String value;
	@Basic(optional = false)
	@Column(name = "activo")
	private boolean activo;
	@Column(name = "userCreated")
	private String userCreated;
	@Column(name = "dateCreate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateCreate;
	@Column(name = "userMod")
	private String userMod;
	@Column(name = "dateMod")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateMod;
}
