package com.truper.saen.commons.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Fechas {
	public static String getHoraLogeo() {
		String pattern = "MM-dd-yyyy HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		return simpleDateFormat.format(new Date());
	}
	
	public static String getDateToString(Date date) {
		String pattern = "yyyy-MM-dd";
		if(date!=null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			return simpleDateFormat.format(date);
		}
		return "";
	}
	
	public static Integer numeroDiasEntreDosFechas(Date fecha1, Date fecha2) {
		 if(fecha1!=null  && fecha2!=null) {
			 long startTime = fecha1.getTime();
		     long endTime = fecha2.getTime();
		     long diffTime = endTime - startTime;
		     long diffDays = diffTime / (1000 * 60 * 60 * 24);
		     return (int)diffDays;
		 }
		 return -1;
	}
}
