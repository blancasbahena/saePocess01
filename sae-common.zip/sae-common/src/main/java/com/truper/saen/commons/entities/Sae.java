package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "Sae")
public class Sae implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "folio")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long folio;

	@Column(name = "tipo", length = 1)
	private String tipo;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idStatus", referencedColumnName = "idSaeStatus")
	private CatSaeStatus status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETA")
	private Date eta;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETASolicitada")
	private Date etaSolicitada;

	@Column(name = "idProveedor")
	private Integer idProveedor;

	@Column(name = "Unidades")
	private Integer Unidades;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idTipoUnidad", referencedColumnName = "idTipoUnidad")
	private CatTipoDeUnidad tipoDeUnidad;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "prioridadGte", referencedColumnName = "idPrioridad")
	private CatPrioridades prioridades;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idCentro", referencedColumnName = "idCentro")
	private CatCentro centros;

	@Column(name = "IDAMin")
	private Integer idaMin;

	@Column(name = "totalCodigos")
	private Integer totalCodigos;

	@Column(name = "monto")
	private Double monto;

	@Column(name = "conteoRevisado")
	private Short conteoRevisado;

	@Column(name = "conteoRechazado")
	private Short conteoRechazado;

	@Column(name = "idConfirmador")
	private Integer idConfirmador;

	@Column(name = "fechaConfirmacion")
	private Date fechaConfirmacion;

	@Column(name = "rechazoConfirmacion")
	private Date rechazoConfirmacion;

	@Column(name = "created")
	private Date created;

	@Column(name = "lastModified")
	private Date lastModified;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userModified", referencedColumnName = "id")
	private User userModified;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userCreated", referencedColumnName = "id")
	private User userCreated;

	@Column(name = "comentarios", length = 256)
	private String comentarios;

	@OneToMany(mappedBy = "sae", fetch = FetchType.LAZY)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@JsonManagedReference
	private List<SaeDetalle> saeDetalles;

	@OneToOne(mappedBy = "idSae")
	private SaeCitas cita;

	/** campos para rechazo aprobar sae */
	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userApproval", referencedColumnName = "id")
	private User userApproval;

	/** campos para rechazo aprobar sae */
	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userReject", referencedColumnName = "id")
	private User userReject;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectGte", referencedColumnName = "id")
	private User userRejectGte;

	@Column(name = "dateReject")
	private Date dateReject;

	@Column(name = "dateRejectGte")
	private Date dateRejectGte;

	@Column(name = "dateApproval")
	private Date dateApproval;

	@Column(name = "date1erApproval")
	private Date date1erApproval;

	@Column(name = "msgReject")
	private String msgReject;

	@Column(name = "msgRejectGte")
	private String msgRejectGte;

	@Column(name = "nombreProveedor", length = 80)
	private String nombreProveedor;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userApprovalGte", referencedColumnName = "id")
	private User userApprovalGte;

	@Column(name = "dateApprovalGte")
	private Date dateApprovalGte;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userApprovalOver", referencedColumnName = "id")
	private User userApprovalOver;

	@Column(name = "dateApprovalOver")
	private Date dateApprovalOver;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectOver", referencedColumnName = "id")
	private User userRejectOver;

	@Column(name = "dateRejectOver")
	private Date dateRejectOver;

	@Column(name = "msgRejectOver")
	private String msgRejectOver;

	/** campos para rechazo aprobar sae */
	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userApprovalLibera", referencedColumnName = "id")
	private User userApprovalLibera;

	/** campos para rechazo aprobar sae */
	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userCancelaLibera", referencedColumnName = "id")
	private User userCancelaLibera;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectLibera", referencedColumnName = "id")
	private User userRejectLibera;

	@Column(name = "dateApprovalLibera")
	private Date dateApprovalLibera;

	@Column(name = "dateCancelaLibera")
	private Date dateCancelaLibera;

	@Column(name = "dateRejectLibera")
	private Date dateRejectLibera;

	@Column(name = "msgCancelaLibera")
	private String msgCancelaLibera;

	@Column(name = "msgRejectLibera")
	private String msgRejectLibera;

	@Column(name = "citaReprogramada")
	private Boolean citaReprogramada;

	// @Column( name = "idCentro", length = 4 )
	// private String idCentro;

	@Column(name = "dateRejectCancela")
	private Date dateRejectCancela;

	@Column(name = "msgRejectCancela")
	private String msgRejectCancela;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectCancela", referencedColumnName = "id")
	private User userRejectCancela;

	@Column(name = "dateRejectReview")
	private Date dateRejectReview;

	@Column(name = "msgRejectReview")
	private String msgRejectReview;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectReview", referencedColumnName = "id")
	private User userRejectReview;
	
	
	@Column(name = "dateRejectCancel")
	private Date dateRejectCancel;

	@Column(name = "msgRejectCancel")
	private String msgRejectCancel;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userRejectCancel", referencedColumnName = "id")
	private User userRejectCancel;
	
	@Column(name = "msgCancelaCita")
	private String msgCancelaCita;
	
	@Column(name = "centro")
	private String centro;

}
