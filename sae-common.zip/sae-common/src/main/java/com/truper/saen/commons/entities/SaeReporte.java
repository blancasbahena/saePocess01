package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Data
@Entity
@Table(name = "Sae")
public class SaeReporte implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "folio")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long folio;

	@Column(name = "tipo", length = 1)
	private String tipo;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idStatus", referencedColumnName = "idSaeStatus")
	private CatSaeStatus status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETA")
	private Date eta;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ETASolicitada")
	private Date etaSolicitada;

	@Column(name = "idProveedor")
	private Integer idProveedor;

	@Column(name = "Unidades")
	private Integer Unidades;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idTipoUnidad", referencedColumnName = "idTipoUnidad")
	private CatTipoDeUnidad tipoDeUnidad;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "prioridadGte", referencedColumnName = "idPrioridad")
	private CatPrioridades prioridades;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idCentro", referencedColumnName = "idCentro")
	private CatCentro centros;

	@Column(name = "IDAMin")
	private Integer idaMin;

	@Column(name = "totalCodigos")
	private Integer totalCodigos;

	@Column(name = "monto")
	private Double monto;

	@Column(name = "conteoRevisado")
	private Short conteoRevisado;

	@Column(name = "conteoRechazado")
	private Short conteoRechazado;

	@Column(name = "idConfirmador")
	private Integer idConfirmador;


	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userModified", referencedColumnName = "id")
	private User userModified;

	@OneToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "userCreated", referencedColumnName = "id")
	private User userCreated;

	@Column(name = "comentarios", length = 256)
	private String comentarios;

	@OneToMany(mappedBy = "sae", fetch = FetchType.EAGER)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@JsonManagedReference
	private List<SaeDetalle> saeDetalles;
  

	@Column(name = "nombreProveedor", length = 80)
	private String nombreProveedor;
  

	@Column(name = "citaReprogramada")
	private Boolean citaReprogramada;
 
}
