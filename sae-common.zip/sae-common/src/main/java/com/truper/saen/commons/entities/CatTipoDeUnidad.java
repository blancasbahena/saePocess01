package com.truper.saen.commons.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "catTiposDeUnidad")
public class CatTipoDeUnidad {

	@Id
	@Column(name = "idTipoUnidad")
	private Integer idTipoUnidad;
	
	@Column(name = "tipoUnidad", length = 10)
	private String tipoUnidad;
	
	@Column(name = "activo")
	private Boolean activo;
	
}
