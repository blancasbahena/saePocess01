package com.truper.saen.controller.citas;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.dto.CalendarioCitasDto;
import com.truper.saen.service.ISaeService;
import com.truper.saen.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Servicio para saes WS CITAS API")
public class SaeController {
	
	@Autowired
	private ISaeService saeService;
	
	@RequestMapping(value = "/getTotalPlanedorBySemana/", method = RequestMethod.POST)
	@ApiOperation(value = "Servicio para la obtencion de planeadores por semana", notes = "\"Servicio para la obtencion de planeadores por semana")
	public ResponseEntity<ResponseVO> getTotalPlanedorBySemana(@RequestBody CalendarioCitasDto datos) {
		log.info("[GET /getTotalPlanedorByFolio] | INICIO -  {} - HORA - {} ",UtilDates.getHora());
		Map<String,Object> data = new HashMap<>();
		
		data.put("total", saeService.getTotalPlanedorBySemana(datos.getInicio(),datos.getFin()));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Total de planeador obtenido con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /getTotalPlanedorByFolio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@RequestMapping(value = "/getDetalleByPlaneador/{idPlaneador}", method = RequestMethod.GET)
	@ApiOperation(value = "Servicio para obtener detalle de planeadores por  id planeador", notes = "Servicio para obtener detalle de planeadores por  id planeador")
	public ResponseEntity<ResponseVO> getDetalleByPlaneador(@PathVariable("idPlaneador") Long idPlaneador) {
		log.info("[GET /getDetalleByPlaneador] | INICIO -  {} - HORA - {} ",UtilDates.getHora());
		
		Map<String,Object> data = new HashMap<>();
		data.put("detallePlaneador", saeService.getDetalleByPlaneador(idPlaneador));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Detalle obtenido con  exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /getDetalleByPlaneador] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	

}
