package com.truper.saen.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsFamiliasDTO;
import com.truper.saen.dto.ResponseCatalogsPlannerrDTO;
import com.truper.saen.dto.ResponseTokenDTO;

@FeignClient(name = "apiCatalogs", url = "${catalogs.host}")
public interface CatalogsFeingClient {

	String AUTH_TOKEN = "Authorization";

	@PostMapping("${catalogs.path-token}")
	ResponseTokenDTO getToken(@RequestBody RequestToken requestToken);

	@GetMapping(value = "${catalogs.path-data-planeador}")
	ResponseCatalogsPlannerrDTO getDataPlanners(@RequestHeader(value = "Authorization", required = true) String bearerToken);
	
	@GetMapping(value = "${catalogs.path-data-familias}")
	ResponseCatalogsFamiliasDTO getDataFamilias(@RequestHeader(value = "Authorization", required = true) String bearerToken);

}
