package com.truper.saen.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class GeneracionCitaDto implements Serializable{ 
	private static final long serialVersionUID = 2057762734468312675L; 
	
	private Long idSae;
	private String usr;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaEntrega;

}
