package com.truper.saen.persistencia;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.ConfProperties;

public interface ConfPropertiesRepository extends JpaRepository<ConfProperties, String> {

}
