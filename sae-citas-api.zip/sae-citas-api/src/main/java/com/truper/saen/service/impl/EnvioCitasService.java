package com.truper.saen.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.dto.GeneracionCitaDto;
import com.truper.saen.rabbit.RabbitMqSenderCita;
import com.truper.saen.service.IEnvioCitasService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class EnvioCitasService implements IEnvioCitasService {
	
	@Autowired
	private RabbitMqSenderCita rabbitMqSenderCita;

	@Override
	public void envioCitas(GeneracionCitaDto citaDto) {
		log.info("Envio de menesaje a rabbit");
		rabbitMqSenderCita.send(citaDto);

	}

}
