package com.truper.saen.util;

import java.util.Calendar;

public class UtilDates {
	public static String getHora() {
		Calendar calendario = Calendar.getInstance();
		String hour = String.format("%02d",calendario.get(Calendar.HOUR_OF_DAY));
		String minute = String.format("%02d",calendario.get(Calendar.MINUTE));
		String second = String.format("%02d",calendario.get(Calendar.SECOND));
		return hour + ":" + minute + ":" + second;
	}
}
