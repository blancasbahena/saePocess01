package com.truper.saen.service;

import java.util.List;

import com.truper.saen.common.Respuesta;
import com.truper.saen.dto.CancelarCitaDto;
import com.truper.saen.dto.CitaDiaMesAnioDto;
import com.truper.saen.dto.CitaDto;
import com.truper.saen.dto.CitasCalendarioDto;
import com.truper.saen.dto.CitasDiaMesAnioDTO;
import com.truper.saen.dto.DetalleSaeCitaDto;
import com.truper.saen.dto.DiasCitaMesAnio;
import com.truper.saen.dto.GeneracionCitaDto;
import com.truper.saen.dto.SaeCitaDto;

public interface ICitaService {

	Long generarCita(GeneracionCitaDto dto);

	boolean hayEspacioParaCita(GeneracionCitaDto dto);

	List<CitaDto> getCitas();

	List<CitaDto> getDiasBySae(Long folio);

	Long confirmarCita(Long idCita);

	List<CitasCalendarioDto> getCitasPorMesAndAnio(Long mes, Long anio);

	SaeCitaDto getSaeByCita(Long idCita);

	List<DetalleSaeCitaDto> getDetalleSaeByFolio(Long folio);

	List<CitaDiaMesAnioDto> getCitasPorDiaMesAndAnio(Long dia, Long mes, Long anio);

	boolean borraCitasSAE(GeneracionCitaDto dto);
	
	Respuesta confirmarCita(String token, Long idSae); 
	
	Respuesta cancelarCita(String token, Long idSae, CancelarCitaDto citaDto);
	
	Respuesta reprogramarCita(String token, CitaDto cita);

	List<DiasCitaMesAnio> getNumCitasPorMesAndAnio(Long mes, Long anio);

	List<DiasCitaMesAnio> getNumCitasPorDiaMesAndAnio(Long dia, Long mes, Long anio);
}
