package com.truper.saen.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class DataCatalogsFamilias implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8719525778796329994L;
	private List<CatalogsFamilias> familias;

}
