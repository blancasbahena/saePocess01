package com.truper.saen.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.DataDTO;
import com.truper.saen.commons.dto.EmailDTO;
import com.truper.saen.commons.dto.ParamsDTO;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.CatStatusCita;
import com.truper.saen.commons.entities.MensajesEmails;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeCitas;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.enums.Mensajes;
import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dto.CancelarCitaDto;
import com.truper.saen.dto.CitaDiaMesAnioDto;
import com.truper.saen.dto.CitaDto;
import com.truper.saen.dto.CitasCalendarioDto;
import com.truper.saen.dto.DetalleSaeCitaDto;
import com.truper.saen.dto.DiasCitaMesAnio;
import com.truper.saen.dto.GeneracionCitaDto;
import com.truper.saen.dto.SaeCitaDto;
import com.truper.saen.exceptions.BussinesException;
import com.truper.saen.persistencia.CatStatusCitaRepository;
import com.truper.saen.persistencia.CatUsuariosRepository;
import com.truper.saen.persistencia.CitaRepository;
import com.truper.saen.persistencia.DataEmailsDao;
import com.truper.saen.persistencia.SaeRepository;
import com.truper.saen.service.ICitaService;
import com.truper.saen.service.IConfPropertiesService;
import com.truper.saen.service.NotificacionesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CitaServiceImpl implements ICitaService {

	@Autowired
	private CitaRepository citaRepo;
	@Autowired
	private CatUsuariosRepository usuarioRepo;

	@Autowired
	private SaeRepository saeRepository;
	
	@Autowired
	private CatStatusCitaRepository statusCitaRepository;
	
	@Autowired
	private NotificacionesService emailService;
	
	@Autowired
	private DataEmailsDao emailsDao;

	private static Long CITA_CONFIRMADA = 1l;
	private static Long CITA_CANCELADA = 2l;
	private static Long CITA_REPROGRAMADA = 2l;
	private static Integer ID_DATOS_EMAILS_CITA_CANCELADA = 17;
	private static Integer ID_DATOS_EMAILS_CITA_REPROGRAMADA = 18;
	
	@Value("${app.emails.sender}")
	private String sender;
	
	@Autowired
	private IConfPropertiesService iConfPropertiesService;

	@Override
	public List<CitaDto> getCitas() {

		return citaRepo.findAll().stream().map(e -> new CitaDto(e)).collect(Collectors.toList());

	}

	@Override
	public List<CitaDto> getDiasBySae(Long folio) {
		Sae sae = new Sae();
		sae.setFolio(folio);
		return citaRepo.findByIdSae(sae).stream().map(e -> new CitaDto(e)).collect(Collectors.toList());
	}

	@Override
	public boolean hayEspacioParaCita(GeneracionCitaDto dto) {
		try {
			Long totalCitas = citaRepo.getCitasByFechaActivas(dto.getFechaEntrega());
			Long dias = iConfPropertiesService.obtenerTotalCitasPorDia().longValue();
			if (totalCitas < dias) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Long generarCita(GeneracionCitaDto dto) {
		try {
			SaeCitas cita = new SaeCitas();
			Optional<Sae> sae = saeRepository.findById(dto.getIdSae());
			Optional<CatStatusCita> estatus = statusCitaRepository.findById(0l);
			User usuario = usuarioRepo.findByUserName(dto.getUsr());
			if (sae.isPresent() && estatus.isPresent() && usuario != null) {
				List<SaeCitas> citasSAE = citaRepo.findByIdSae(sae.get());
				if (!citasSAE.isEmpty()) {
					if (citasSAE.size() == 1) {
						cita = citasSAE.get(0);

					}
				}
				cita.setIdStatus(estatus.get());
				cita.setUserConfirma(usuario);
				cita.setIdSae(sae.get());
				cita.setFechaCita(dto.getFechaEntrega());
				SaeCitas citaDb = citaRepo.save(cita);
				return citaDb.getId();
			}
			return -1l;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return (long) -1;

	}

	@Override
	public boolean borraCitasSAE(GeneracionCitaDto dto) {
		try {

			Optional<Sae> sae = saeRepository.findById(dto.getIdSae());
			Optional<CatStatusCita> estatus = statusCitaRepository.findById(1l);
			Optional<CatStatusCita> estatusInactivo = statusCitaRepository.findById(2l);
			User usuario = usuarioRepo.findByUserName(dto.getUsr());
			if (sae.isPresent() && estatus.isPresent() && usuario != null) {
				List<SaeCitas> citasSAE = citaRepo.findByIdSae(sae.get());
				if (!citasSAE.isEmpty()) {
					if (citasSAE.size() == 1) {
						citasSAE.get(0).setIdStatus(estatusInactivo.get());
						citaRepo.save(citasSAE.get(0));
					}
				}
			}
		} catch (Exception e) {
			throw new BussinesException("Problemas en el borrado de citas para sae :" + dto.getIdSae());
		}
		return true;
	}

	@Override
	public Long confirmarCita(Long idCita) {
		SaeCitas citaConfirmada = citaRepo.findByIdAndConfirmada(idCita, true);

		if (citaConfirmada != null) {
			throw new BussinesException("La cita ya se encuentra confirmada");
		}

		Long totalCitasConfirmadas = citaRepo.getCitasConfirmadasByFecha(new Date());
		Long dias = iConfPropertiesService.obtenerTotalCitasPorDia().longValue();
		SaeCitas cita = null;
		if (totalCitasConfirmadas < dias) {
			cita = citaRepo.getById(idCita);
			if (cita != null) {
				cita.setConfirmada(true);
				cita.setFechaConfirmacion(new Date());
				citaRepo.save(cita);
			}
		} else {
			throw new BussinesException("Ya existen mas de 5 citas confirmdas por dia");
		}
		return cita.getId();
	}

	@Override
	public List<CitasCalendarioDto> getCitasPorMesAndAnio(Long mes, Long anio) {

		return citaRepo.getCitasByMesAndAnio(mes, anio);
	}

	@Override
	public SaeCitaDto getSaeByCita(Long idCita) {
		Optional<SaeCitas> cita = citaRepo.findById(idCita);
		if (cita.isPresent()) {
			return new SaeCitaDto(cita.get());
		}
		return null;
	}

	@Override
	public List<DetalleSaeCitaDto> getDetalleSaeByFolio(Long folio) {
		return citaRepo.getDetalleSaeByFolio(folio);
	}

	@Override
	public List<CitaDiaMesAnioDto> getCitasPorDiaMesAndAnio(Long dia, Long mes, Long anio) {
		return citaRepo.getCitasPorDiaMesAndAnio(dia, mes, anio);
	}
	
	@Override
	public List<DiasCitaMesAnio> getNumCitasPorMesAndAnio(Long mes, Long anio) {
		return citaRepo.getNumCitasPorMesAndAnio(mes, anio);
	}
	
	@Override
	public List<DiasCitaMesAnio> getNumCitasPorDiaMesAndAnio(Long dia,Long mes, Long anio) {
		return citaRepo.getNumCitasPorDiaMesAndAnio(dia, mes, anio);
	}

	@Override
	public Respuesta confirmarCita(String token, Long idSae) {

		Respuesta respuesta = new Respuesta();
		try {

			Sae sae = new Sae();
			sae = saeRepository.findById(idSae).orElse(null);

			if (sae == null) {
				throw new BussinesException("El IdSae no es valido");
			}

			List<SaeCitas> citas = citaRepo.findByIdSae(sae);

			if (citas.isEmpty()) {
				throw new BussinesException("No existe cita con ese IdSae");
			} else {

				SaeCitas cita = citas.get(0);

				Long totalCitasConfirmadas = citaRepo.getCitasConfirmadasByFecha(cita.getFechaCita());
				Long dias = iConfPropertiesService.obtenerTotalCitasPorDia().longValue();
				if (totalCitasConfirmadas >= dias) {
					throw new BussinesException("No hay disponibilidad de Citas para el " + cita.getFechaCita());
				} else if (cita.getConfirmada() == null || cita.getConfirmada() == false) {

					cita.setConfirmada(true);
					cita.setFechaConfirmacion(new Date());

					String username = JWUtil.extractUsername(token);

					User user = usuarioRepo.findByUserName(username);
					cita.setUserConfirma(user);
					CatStatusCita statusCita = new CatStatusCita();
					statusCita.setIdStatus(CITA_CONFIRMADA);
					cita.setIdStatus(statusCita);

					CatSaeStatus saeStatus = new CatSaeStatus();
					saeStatus.setIdSaeStatus(CatStatusSae.SAE_CON_CITA_CONFIRMADA.getId());
					sae.setStatus(saeStatus);
					
					Date inicio =  new Date();
					log.info("[INICIO - UPDATE] | SAE ");
					saeRepository.save(sae);
					Date fin =  new Date();
					log.info("[FIN - UPDATE] | SAE - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
					inicio =  new Date();
					log.info("[INICIO - UPDATE] | SAE_CITAS ");
					citaRepo.save(cita);
					fin =  new Date();
					log.info("[FIN - UPDATE] | SAE_CITAS - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

					respuesta.setEstado(HttpStatus.OK);
					respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
					Map<String, Object> data = new HashMap<>();

					SaeCitaDto citadto = new SaeCitaDto(cita);
					// Falta armar el dto correcto de acuerdo a la info que hay que regresar
					data.put("cita", citadto);
					respuesta.setData(data);
					respuesta.setMensaje("Cita confirmada con exito");

				} else {

					Map<String, Object> data = new HashMap<>();
					SaeCitaDto citadto = new SaeCitaDto(cita);
					data.put("cita", citadto);
					throw new BussinesException("La cita ya ha sido confirmada con anterioridad");
				}

			}
		} catch (Exception e) {
			log.error(e.getMessage());
			respuesta.setEstado(HttpStatus.BAD_REQUEST);
			respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			respuesta.setMensaje(e.getMessage());
		}

		return respuesta;
	}

	@Override
	public Respuesta cancelarCita(String token, Long idSae, CancelarCitaDto citaDto) {
		Respuesta respuesta = new Respuesta();
		
		String username = JWUtil.extractUsername(token);
		User user = usuarioRepo.findByUserName(username);
		
		Sae sae = new Sae();
		sae = saeRepository.findById(idSae).orElse(null);

		if( sae == null ) {
			throw new BussinesException("El IdSae no es valido");
		}
		
		List<SaeCitas> citas = citaRepo.findByIdSae(sae);
		if( citas.isEmpty() ) {
			throw new BussinesException("No existe cita con ese IdSae");
		}else {
			
			try {
			SaeCitas cita = citas.get(0);
			
			CatStatusCita statusCita = new CatStatusCita();
			statusCita.setIdStatus(CITA_CANCELADA);
			cita.setIdStatus(statusCita);
			
			CatSaeStatus saeStatus = new CatSaeStatus();
			saeStatus.setIdSaeStatus(CatStatusSae.SAE_CON_CITA_CANCELADA.getId());
			
			sae.setStatus(saeStatus);
			sae.setMsgCancelaCita(citaDto.getMensajeCancelacion());
			sae.setUserModified(user);

			//Se prepara DTO para Email.
			MensajesEmails dataMail = emailsDao.findById(ID_DATOS_EMAILS_CITA_CANCELADA).orElse(null);
			
			EmailDTO mail =  new EmailDTO();
			mail.setTo(Arrays.asList(sae.getUserApproval().getEmail()));
			
			if( dataMail.getCc() != null || !dataMail.getCc().equals("") ) {
				mail.setCc(Arrays.asList(dataMail.getCc().split(";")));
			}
			mail.setSender(sender);
			mail.setSubject(dataMail.getSubjectEmail());
			mail.setTemplate(dataMail.getPlantilla());
			
			ParamsDTO params = new ParamsDTO();
			DataDTO data =  new DataDTO();
			
			data.setFolio(sae.getTipo()+sae.getFolio());
			data.setProveedor(sae.getNombreProveedor());
			data.setPlaning(sae.getUserApproval().getName());
			data.setCita(sae.getCita().getId().toString());
			data.setFechaCita( Fechas.getDateToString( sae.getCita().getFechaCita() ));
			
			params.setData(data);
			mail.setParams(params);
			
			Date inicio =  new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeRepository.save(sae);
			Date fin =  new Date();
			log.info("[FIN - UPDATE] | SAE - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			inicio =  new Date();
			log.info("[INICIO - UPDATE] | SAE_CITAS ");
			citaRepo.save(cita);
			fin =  new Date();
			log.info("[FIN - UPDATE] | SAE_CITAS - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			
			emailService.EnviarEmail(mail);
			
			}catch (Exception e) {
				respuesta.setEstado(HttpStatus.BAD_REQUEST);
				respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
				respuesta.setMensaje(e.getMessage());
			}	
			
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			respuesta.setMensaje("La cita fue cancelada con exito");
		
		}
		
		return respuesta;
	}

	@Override
	public Respuesta reprogramarCita(String token, CitaDto citadto) {
		Respuesta respuesta = new Respuesta();
		
		//String username = JWUtil.extractUsername(token);
		
		Sae sae = new Sae();
		sae = saeRepository.findById(citadto.getId()).orElse(null);
		
		if( sae == null ) {
			throw new BussinesException("El IdSae no es valido");
		}
		
		List<SaeCitas> citas = citaRepo.findByIdSae(sae);
		if( citas.isEmpty() ) {
			throw new BussinesException("No existe cita con ese IdSae");
		}else {
			
			try {
			SaeCitas cita = citas.get(0);
			
			CatStatusCita statusCita = new CatStatusCita();
			statusCita.setIdStatus(CITA_REPROGRAMADA);
			cita.setIdStatus(statusCita);
			cita.setFechaReprogramada(citadto.getFechaReprogramada());
			
			CatSaeStatus saeStatus = new CatSaeStatus();
			saeStatus.setIdSaeStatus(CatStatusSae.SAE_CON_CITA_REPROGRAMADA.getId());

			sae.setStatus(saeStatus);
			sae.setCitaReprogramada(true);
			
			//Se prepara DTO para Email.
			MensajesEmails dataMail = emailsDao.findById(ID_DATOS_EMAILS_CITA_REPROGRAMADA).orElse(null);
			
			EmailDTO mail =  new EmailDTO();
			mail.setTo(Arrays.asList(sae.getUserApproval().getEmail()));
			
			if( dataMail.getCc() != null || !dataMail.getCc().equals("") ) {
				mail.setCc(Arrays.asList(dataMail.getCc().split(";")));
			}
			mail.setSender(sender);
			mail.setSubject(dataMail.getSubjectEmail());
			mail.setTemplate(dataMail.getPlantilla());
			
			ParamsDTO params = new ParamsDTO();
			DataDTO data =  new DataDTO();
			
			data.setFolio(sae.getTipo()+sae.getFolio());
			data.setProveedor(sae.getNombreProveedor());
			data.setPlaning(sae.getUserApproval().getName());
			data.setCita(sae.getCita().getId().toString());
			data.setFechaCita( Fechas.getDateToString( sae.getCita().getFechaCita() ));
			data.setNuevaCita( Fechas.getDateToString( citadto.getFechaReprogramada()));
			
			params.setData(data);
			mail.setParams(params);
			
			Date inicio =  new Date();
			log.info("[INICIO - UPDATE] | SAE ");
			saeRepository.save(sae);
			Date fin =  new Date();
			log.info("[FIN - UPDATE] | SAE - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			inicio =  new Date();
			log.info("[INICIO - UPDATE] | SAE_CITAS ");
			citaRepo.save(cita);
			fin =  new Date();
			log.info("[FIN - UPDATE] | SAE_CITAS - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			
			emailService.EnviarEmail(mail);
			
		}catch (Exception e) {
			respuesta.setEstado(HttpStatus.BAD_REQUEST);
			respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			respuesta.setMensaje(e.getMessage());
		}	
		
			
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		
		}
		
		return respuesta;
	}

}
