package com.truper.saen.exceptions;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.responses.ErrorMessage;
import com.truper.saen.responses.ValidationErrors;
import com.truper.saen.util.UtilDates;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@ControllerAdvice
public class AppExceptionHandler {

    @ExceptionHandler(value = { BussinesException.class })
    public ResponseEntity<Object> handleEmailExistsException(BussinesException ex, WebRequest webRequest) {
    	
    	Respuesta resp = new Respuesta(); 
    	resp.setTipoMensaje(ResponseMessage.TIPO_ERROR.getMensaje());
		resp.setMensaje(ex.getMessage());
		resp.setEstado(HttpStatus.INTERNAL_SERVER_ERROR);
		ErrorMessage errorMessage = new ErrorMessage(new Date(), ex.getMessage());
		Map<String, Object> data = new HashMap<>();
		data.put("error", errorMessage);
		resp.setData(data);
		log.error("Error en el servicio",ex.getMessage(), UtilDates.getHora());
		return new ResponseEntity<>(resp, resp.getEstado());
    }

    @ExceptionHandler(value = { MethodArgumentNotValidException.class })
    public ResponseEntity<Object> handleEmailExistsException(MethodArgumentNotValidException ex,
            WebRequest webRequest) {

        Map<String, String> errors = new HashMap<>();

        for (ObjectError error : ex.getBindingResult().getAllErrors()) {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        }

        ValidationErrors validationErrors = new ValidationErrors(errors, new Date());

        return new ResponseEntity<>(validationErrors, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = { Exception.class })
    public ResponseEntity<Object> handleException(Exception ex, WebRequest webRequest) {
        ErrorMessage errorMessage = new ErrorMessage(new Date(), ex.getMessage());
        log.error("Error en el servicio",ex.getMessage(), UtilDates.getHora());
        return new ResponseEntity<>(errorMessage, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
