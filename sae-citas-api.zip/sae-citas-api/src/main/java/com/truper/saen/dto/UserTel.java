package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class UserTel implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 9158505824425184596L;
	private String id;
	private String usuario;
	private String nombre;

}
