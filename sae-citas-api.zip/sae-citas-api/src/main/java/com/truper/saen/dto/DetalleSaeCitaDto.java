package com.truper.saen.dto;

public interface DetalleSaeCitaDto {

	String getPo();
	String getMaterial();
	String getDescripcion();
	Long getCantidad();
	Integer getIda();
	
}
