package com.truper.saen.rabbit;

import java.util.Date;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.entities.CatStatusCita;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeCitas;
import com.truper.saen.configuration.ConfigRabbit;
import com.truper.saen.dto.GeneracionCitaDto;
import com.truper.saen.persistencia.CatStatusCitaRepository;
import com.truper.saen.persistencia.CitaRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class RabbitMqSenderCita {

	private final RabbitTemplate rabbitTemplate;
	private final ConfigRabbit configRabbit;
	
	
	@Autowired
	private CitaRepository citaRepo;
	private CatStatusCitaRepository statuCitaRepo;

	public void send(GeneracionCitaDto citaDto) {
		
		SaeCitas cita= new SaeCitas();
		cita.setFechaCita(new Date());
		Sae sae = new Sae();
		sae.setFolio(citaDto.getIdSae());
		cita.setIdSae(sae);
		
		CatStatusCita estatus = new CatStatusCita();
		estatus.setIdStatus(1l);
		//cita.setIdStatus(estatus);
		citaRepo.save(cita);
		log.info("SE ENVIA  RoutingkeyTraficoFungRuiAutorizo --->> "+ configRabbit.getRoutingkeySNacionalesGeneracionCitas());
		log.info("SE ENVIA  QueueTraficoFungRuiAutorizo      --->> "+ configRabbit.getQueueSNacionalesGeneracionCitas());
		log.info("SE ENVIA  VirtualHost                     --->> "+ rabbitTemplate.getConnectionFactory().getVirtualHost());
		rabbitTemplate.setRoutingKey(configRabbit.getRoutingkeySNacionalesGeneracionCitas());
		rabbitTemplate.setDefaultReceiveQueue(configRabbit.getQueueSNacionalesGeneracionCitas());
		rabbitTemplate.convertAndSend(configRabbit.getExchange(),
				configRabbit.getRoutingkeySNacionalesGeneracionCitas(), cita);

	}

}
