package com.truper.saen.persistencia;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.User;

public interface CatUsuariosRepository extends JpaRepository<User, Long>{

	User findByUserName(String userName);
}
