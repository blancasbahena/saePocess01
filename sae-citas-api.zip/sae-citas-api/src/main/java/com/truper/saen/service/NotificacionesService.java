package com.truper.saen.service;

import com.truper.saen.commons.dto.EmailDTO;

public interface NotificacionesService {

	boolean EnviarEmail( EmailDTO mail );
	
}
