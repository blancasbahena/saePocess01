package com.truper.saen.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.dto.DetallePlaneadorDto;
import com.truper.saen.persistencia.CalendarioRepository;
import com.truper.saen.service.CalendarioZMPService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CalendarioZmpImpl implements CalendarioZMPService{

	@Autowired
	private CalendarioRepository calendarioRepo;
	
	@Override
	public Respuesta getDetalleByPlaneadorAndFecha(String planner, String dia) {
		Respuesta respuesta = new Respuesta();

		Date inicio =  new Date();
		log.info("[INICIO - SELECT] | SAE ");
		List<DetallePlaneadorDto> detalles = calendarioRepo.getDetalleByPlaneadorAndDia(planner, dia);
		Date fin =  new Date();
		log.info("[FIN - SELECT] | SAE - {}" ,Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		
		
		if( !detalles.isEmpty() ) {
			respuesta.setEstado(HttpStatus.OK);
			Map<String, Object> data = new HashMap<>();
			data.put("detalles", detalles);
			respuesta.setData(data);
			respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
			
		}else {
			respuesta.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			respuesta.setEstado(HttpStatus.NOT_FOUND);
		}
		
		return respuesta;
	}

}
