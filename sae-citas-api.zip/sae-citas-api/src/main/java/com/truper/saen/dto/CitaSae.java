package com.truper.saen.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class CitaSae {
	private Integer id;
	private String idPlannerDomingo;
	private String plannerDomingo;
	private String familiaDomingo;
	private Integer cantUnidDomingo;
	
	private String idPlannerLunes;
	private String plannerLunes;
	private String familiaLunes;
	private Integer cantUnidLunes;
	
	private String idPlannerMartes;
	private String plannerMartes;
	private String familiaMartes;
	private Integer cantUnidMartes;
	
	private String idPlannerMiercoles;
	private String plannerMiercoles;
	private String familiaMiercoles;
	private Integer cantUnidMiercoles;
	
	private String idPlannerJueves;
	private String plannerJueves;
	private String familiaJueves;
	private Integer cantUnidJueves;
	
	private String idPlannerViernes;
	private String plannerViernes;
	private String familiaViernes;
	private Integer cantUnidViernes;
	
	private String idPlannerSabado;
	private String plannerSabado;
	private String familiaSabado;
	private Integer cantUnidSabado;
}
