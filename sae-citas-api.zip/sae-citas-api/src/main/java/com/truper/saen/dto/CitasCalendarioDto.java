package com.truper.saen.dto;

import java.util.Date;

public interface CitasCalendarioDto {
	Long getId();
	Long getIdSae();
	Date getFechaCita();
	Date getFechaConfirmacion();
	Boolean getConfirmada();
	Long getIdStatus();
	String getUsuario();

}
