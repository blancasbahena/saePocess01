package com.truper.saen.service;

import com.truper.saen.dto.ActualizarConfiguracionDto;

public interface IConfPropertiesService {

	Integer obtenerTotalCitasPorDia();
	
	String actualizarConfiguracion(ActualizarConfiguracionDto dto);
}
