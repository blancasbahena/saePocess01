package com.truper.saen.dto;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class PlaneadorFamilia {
	
	private String planeador;
	private String familia;
	private Long folio;
	@Override
	public int hashCode() {
		return Objects.hash(familia, planeador);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlaneadorFamilia other = (PlaneadorFamilia) obj;
		return Objects.equals(familia, other.familia) && Objects.equals(planeador, other.planeador);
	}

}
