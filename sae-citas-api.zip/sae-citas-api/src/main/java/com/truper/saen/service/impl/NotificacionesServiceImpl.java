package com.truper.saen.service.impl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.DataDTO;
import com.truper.saen.commons.dto.EmailDTO;
import com.truper.saen.commons.dto.ParamsDTO;
import com.truper.saen.rabbit.EnqueueMessage;
import com.truper.saen.service.NotificacionesService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificacionesServiceImpl implements NotificacionesService {

	@Value("${app.emails.mode.debug.active:false}")
	private boolean debug;
		
	@Value("${app.emails.mode.debug.to}")
	private String debugTo;
	
	@Value("${app.emails.mode.debug.cc}")
	private String debugCC;
	
	@Autowired
	private EnqueueMessage rbmqService; 
	
	@Override
	public boolean EnviarEmail(EmailDTO mail) {
		
		if( debug ) {
			
			ParamsDTO params = mail.getParams();
			if( params == null ) {
				params = new ParamsDTO();
			}
			DataDTO data = params.getData();
			data.setDebug(debug);
			data.setTo(mail.getTo().toString());
			
			params.setDebug(debug);
			mail.setTo(Arrays.asList(debugTo.split(";")));
			
			if( mail.getCc() != null && !debugCC.equals("") ) {
				data.setCc(mail.getCc().toString());
				mail.setCc(Arrays.asList(debugCC.split(";")));
			}else {
				mail.setCc(null);
			}
			params.setData(data);
			
			mail.setParams(params);
					
		}
		try {
			rbmqService.sendQueueEmail(mail);
		}catch (Exception e) {
			log.error(e.getMessage());
			return false;
		}
			
		return true;
	}

}
