package com.truper.saen.rabbit;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truper.saen.commons.dto.EmailDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EnqueueMessage {
	
	  @Autowired
	  private AmqpTemplate rabbitTemplateAMQ;
	  
	  @Value("${spring.rabbitmq.queueWsMail}")
	  private String queueWsMail;
	  
	  public void sendQueueEmail(EmailDTO mail) {
		try {
			Gson gson = new GsonBuilder().create();
			String json = gson.toJson(mail);
			log.info("Mensaje a envíar: {}", json);
		    MessageProperties props = new MessageProperties();
		    props.getHeaders().put(MessageHeaders.CONTENT_TYPE, MessageProperties.CONTENT_TYPE_JSON);
		    Message message = new Message(new Gson().toJson(json).getBytes(), props);
		    
		    
		    rabbitTemplateAMQ.convertAndSend(queueWsMail, message);
		    log.info("Mensaje encolado.");
		}catch(Exception ex) {
			ex.printStackTrace();
			log.error(ex.getMessage());
		}
	  }

}
