package com.truper.saen.dto;

public interface DetallePlaneadorDto {
	
	String getNombreProveedor();
	Long getFolio();
	Integer getIda();
	Integer getConteoRevisado();
	String getTipo();

}
