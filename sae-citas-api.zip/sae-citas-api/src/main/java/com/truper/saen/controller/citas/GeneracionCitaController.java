package com.truper.saen.controller.citas;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.configuration.JWUtil;
import com.truper.saen.dto.CancelarCitaDto;
import com.truper.saen.dto.CitaDto;
import com.truper.saen.dto.ConfirmarCitaDto;
import com.truper.saen.dto.GeneracionCitaDto;
import com.truper.saen.service.ICitaService;
import com.truper.saen.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@Api("Servicio para generación de citas WS CITAS API")
public class GeneracionCitaController {
	
	@Autowired
	private ICitaService citaService;

	
	@RequestMapping(value = "/generacionCita", method = RequestMethod.POST)
	@ApiOperation(value = "Servicio para generación de citas", notes = "Generacion de citas para la api ws citas")
	public ResponseEntity<ResponseVO> generacionCita(@RequestBody GeneracionCitaDto dto) {
		log.info("[POST /generacionCita] | INICIO -  {} - HORA - {} ", dto.toString(), com.truper.saen.util.UtilDates.getHora());
		Long cita = 0l;
		if(citaService.hayEspacioParaCita(dto)) {
			
			cita= citaService.generarCita(dto);
		}
		Respuesta respuesta = new Respuesta()
				
				;
		Map<String, Object> data = new HashMap<>();
		data.put("idCita", cita);
		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Cita creada con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[POST /generacionCita] | FIN -  {} - HORA - {} ", dto.toString(), UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	
	@RequestMapping(value = "/confirmarCita", method = RequestMethod.POST)
	@ApiOperation(value = "Servicio para confirmacion de citas", notes = "Confirmacion de citas para la api ws citas")
	public ResponseEntity<ResponseVO> confirmarCita(@RequestBody ConfirmarCitaDto dto) {
		log.info("[POST /confirmarCita] | INICIO -  {} - HORA - {} ", dto.toString(), com.truper.saen.util.UtilDates.getHora());
		Long idCita =citaService.confirmarCita(dto.getIdCita());
		Respuesta respuesta = new Respuesta();
		Map<String, Object> data = new HashMap<>();
		data.put("idCita", idCita);
		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Cita confirmada con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[POST /confirmarCita] | INICIO -  {} - HORA - {} ", dto.toString(), com.truper.saen.util.UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PutMapping( value ="confirmarCita/{idSae}" )
	@ApiOperation(value = "Servicio para confirmacion de citas mediante idSae")
	public ResponseEntity<Respuesta> confirmarCita(@RequestHeader("Authorization") String token, @PathVariable Long idSae ){
		log.info("[PUT /confirmarCita/{}] | INICIO -  {} ",idSae,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta =  citaService.confirmarCita(token.substring(7), idSae);
		log.info("[GET /confirmarCita/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PutMapping( value ="cancelarCita/{idSae}" )
	@ApiOperation(value = "Servicio para cancelar cita por idSae")
	public ResponseEntity<Respuesta> cancelarCita(@RequestHeader("Authorization") String token, @PathVariable Long idSae, @RequestBody CancelarCitaDto citaDto ){
		log.info("[PUT /cancelarCita/{}] | INICIO -  {} - {} ",idSae,JWUtil.extractUsername(token.substring(7)), citaDto);
		Respuesta respuesta =  citaService.cancelarCita(token.substring(7), idSae, citaDto);
		log.info("[GET /cancelarCita/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@PutMapping( value ="reprogramarCita/{idSae}" )
	@ApiOperation(value = "Servicio para cancelar cita por idSae")
	public ResponseEntity<Respuesta> reprogramarCita(@RequestHeader("Authorization") String token, @PathVariable Long idSae, @RequestBody CitaDto cita ){
		log.info("[PUT /reprogramarCita/{}] | INICIO -  {} - { {} }",idSae,JWUtil.extractUsername(token.substring(7)),cita);
		Respuesta respuesta =  citaService.reprogramarCita(token.substring(7), cita);
		log.info("[GET /reprogramarCita/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
}
