package com.truper.saen.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.truper.saen.commons.entities.SaeCitas;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CitaDto implements Serializable {

	
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	private Long id;
	private Date fechaCita;
	
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaReprogramada;
	
	public CitaDto(SaeCitas e) {
		this.id= e.getId();
		this.fechaCita = e.getFechaCita();
	}
	
	

}
