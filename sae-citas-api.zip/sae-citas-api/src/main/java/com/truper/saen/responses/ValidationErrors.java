package com.truper.saen.responses;

import java.util.Map;

import lombok.Data;

import java.util.Date;

@Data
public class ValidationErrors {

    private Map<String, String> errors;
    private Date timestamp;

    public ValidationErrors(Map<String, String> errors, Date timestamp) {
        this.errors = errors;
        this.timestamp = timestamp;
    }

 

}
