package com.truper.saen.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.entities.ConfProperties;
import com.truper.saen.dto.ActualizarConfiguracionDto;
import com.truper.saen.persistencia.ConfPropertiesRepository;
import com.truper.saen.service.IConfPropertiesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ConfPropertiesServiceImpl implements IConfPropertiesService {
	@Autowired
	private ConfPropertiesRepository confPropertiesRepository;

	@Override
	public Integer obtenerTotalCitasPorDia() {
		log.info("obtenerTotalCitasPorDia");
		Optional<ConfProperties> conf = confPropertiesRepository.findById("limitador.citas.dias");

		if (conf.isPresent()) {
			return Integer.parseInt(conf.get().getValue());
		}
		return 0;
	}

	@Override
	public String actualizarConfiguracion(ActualizarConfiguracionDto dto) {
		Optional<ConfProperties> conf = confPropertiesRepository.findById(dto.getLlave());

		if (conf.isPresent()) {
			conf.get().setValue(dto.getValue());
			confPropertiesRepository.save(conf.get());
		}
		return conf.get().getLlave();
		
	}

}
