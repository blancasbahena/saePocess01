package com.truper.saen.dto;

import lombok.Data;

@Data
public class CancelarCitaDto {
	private String mensajeCancelacion;
}
