package com.truper.saen.persistencia;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.truper.saen.commons.entities.Sae;
import com.truper.saen.dto.DetallePlaneadorDto;
import com.truper.saen.dto.TotalPlaneadorDto;

public interface SaeRepository extends JpaRepository<Sae, Long>{

	@Query(value="select sd.planner as planeador,sc.fecha_cita as fechaCita, "
			+ "	s.Unidades as unidades, s.folio, "
			+ "	( SELECT DATEPART(dw,sc.fecha_cita) ) as dia, sd.familia from sae_citas sc "
			+ "	inner join Sae s on s.folio = sc.id_sae "
			+ "	inner join SaeDetalle sd on s.folio = sd.idSae "
			+ "	where sc.fecha_cita BETWEEN :inicio AND :fin  "
			+ "	and s.idStatus != 3 and sd.planner != '' "
			+ "	and sd.planner IS NOT NULL "
			+ " and s.tipo = 'M' "
			+ "	Group by sd.planner, sc.fecha_cita,sd.familia,s.folio,s.Unidades;", nativeQuery=true)
	List<TotalPlaneadorDto> getTotalPlanedorBySemana(@Param("inicio") String inicio, @Param("fin") String fin);
	
	@Query(value="SELECT cp.nombre , s.folio, s.IDAMin  as ida\r\n"
			+ "from Sae s , SaeDetalle sd ,\r\n"
			+ "catPlaneador cp \r\n"
			+ "where s.folio = sd.idSae \r\n"
			+ "and sd.planner = cp.idPlaneador \r\n"
			+ "and sd.planner =:idPlaneador ", nativeQuery=true)
	List<DetallePlaneadorDto> getDetalleByPlaneador(@Param("idPlaneador")Long idPlaneador);
}
