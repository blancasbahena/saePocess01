package com.truper.saen.dto;

import lombok.Data;

@Data
public class CalendarioCitasDto {

	private String inicio;
	private String fin;
	
}
