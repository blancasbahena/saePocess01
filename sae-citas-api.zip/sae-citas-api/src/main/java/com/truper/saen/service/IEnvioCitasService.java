package com.truper.saen.service;

import com.truper.saen.dto.GeneracionCitaDto;

public interface IEnvioCitasService {

	void envioCitas(GeneracionCitaDto citaDto);
}
