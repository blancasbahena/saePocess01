package com.truper.saen.dto;

public interface DiasCitaMesAnio {

	Long getDia();
	Long getMes();
	Long getAnio();
	Long getCont();
}
