package com.truper.saen.dto;

import com.truper.saen.commons.entities.SaeCitas;

import lombok.Data;

@Data
public class SaeCitaDto {

	private String proveedor;
	private Long folio;
	private Integer idaMin;

	public SaeCitaDto(SaeCitas cita) {
		super();
		this.proveedor = "test";
		this.folio = cita.getIdSae().getFolio();
		this.idaMin = cita.getIdSae().getIdaMin();
	}

}
