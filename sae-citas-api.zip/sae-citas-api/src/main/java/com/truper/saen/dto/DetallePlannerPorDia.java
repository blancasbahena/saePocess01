package com.truper.saen.dto;

public interface DetallePlannerPorDia {

	Long getFolio();
	String getNombreProveedor();
	Integer getIDAMin();
	
	
}
