package com.truper.saen.dto;

import lombok.Data;

@Data
public class CitasDiaMesAnioDTO {

	private Long idProveedor;
	private Long folio;
	private Integer ida;
	private String nombreProveedor;
	
	
}
