package com.truper.saen.controller.citas;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.dto.ActualizarConfiguracionDto;
import com.truper.saen.service.IConfPropertiesService;
import com.truper.saen.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Servicio para configuracion")
public class ConfController {
	
	@Autowired
	private IConfPropertiesService iConfPropertiesService;
	
	@ApiOperation(value = "Servicio para obtener dias por Sae", notes = "Servicio para obtener dias por Sae")
	@RequestMapping(value = "/obtenerTotalCitasPorDia", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerTotalCitasPorDia() {

		log.info("[GET /obtenerTotalCitasPorDia] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("totalDias",iConfPropertiesService.obtenerTotalCitasPorDia());
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener dias por sae obtenidas  con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerTotalCitasPorDia] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	
	}
	
	
	@RequestMapping(value = "/actualizarConfiguracion", method = RequestMethod.POST)
	@ApiOperation(value = "Servicio para actualizacion de configuracion", notes = "Servicio para actualizacion de configuracion")
	public ResponseEntity<ResponseVO> actualizarConfiguracion(@RequestBody ActualizarConfiguracionDto dto) {
		log.info("[POST /actualizarConfiguracion] | INICIO -  {} - HORA - {} ", dto.toString(), com.truper.saen.util.UtilDates.getHora());
		String valor = iConfPropertiesService.actualizarConfiguracion(dto);
		Respuesta respuesta = new Respuesta();
		Map<String, Object> data = new HashMap<>();
		data.put("valor", valor);
		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Conf actualizada con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[POST /actualizarConfiguracion] | INICIO -  {} - HORA - {} ", dto.toString(), com.truper.saen.util.UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
}
