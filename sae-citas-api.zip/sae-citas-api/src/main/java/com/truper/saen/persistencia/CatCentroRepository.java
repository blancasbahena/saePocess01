package com.truper.saen.persistencia;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.CatCentro;

public interface CatCentroRepository extends JpaRepository<CatCentro, Integer>{

}
