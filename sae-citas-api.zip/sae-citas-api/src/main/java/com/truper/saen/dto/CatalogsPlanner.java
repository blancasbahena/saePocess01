package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class CatalogsPlanner implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5917929888317255375L;

	private String codigoPlaneador;
	private UserTel user;
	
	
	
}
