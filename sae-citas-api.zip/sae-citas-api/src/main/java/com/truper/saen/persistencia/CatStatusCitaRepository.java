package com.truper.saen.persistencia;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.CatStatusCita;

public interface CatStatusCitaRepository extends JpaRepository<CatStatusCita, Long>{

}
