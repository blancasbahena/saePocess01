package com.truper.saen.service;

import com.truper.saen.common.Respuesta;

public interface CalendarioZMPService {

	Respuesta getDetalleByPlaneadorAndFecha(String planner, String dia);
	
}
