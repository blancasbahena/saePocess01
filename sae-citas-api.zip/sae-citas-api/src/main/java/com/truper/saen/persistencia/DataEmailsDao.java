package com.truper.saen.persistencia;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.MensajesEmails;

public interface DataEmailsDao extends JpaRepository<MensajesEmails, Integer> {

}
