package com.truper.saen.dto;

import java.util.Date;

public interface TotalPlaneadorDto {
	
	Long getUnidades();
	String getPlaneador();
	Date getFechaCita();
	Long getDia();
	String getFamilia();
	Long getFolio();
}
