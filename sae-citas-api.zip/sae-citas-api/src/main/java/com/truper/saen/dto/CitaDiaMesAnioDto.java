package com.truper.saen.dto;

public interface CitaDiaMesAnioDto {

	Long getIdProveedor();
	Long getFolio();
	Integer getIda();
	String getNombreProveedor();
	Long getIdStatus();
}
