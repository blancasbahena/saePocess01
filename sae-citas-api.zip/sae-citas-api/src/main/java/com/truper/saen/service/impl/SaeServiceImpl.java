package com.truper.saen.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.truper.saen.dto.CatalogsFamilias;
import com.truper.saen.dto.CatalogsPlanner;
import com.truper.saen.dto.CitaSae;
import com.truper.saen.dto.DetallePlaneadorDto;
import com.truper.saen.dto.PlaneadorFamilia;
import com.truper.saen.dto.RequestToken;
import com.truper.saen.dto.ResponseCatalogsFamiliasDTO;
import com.truper.saen.dto.ResponseCatalogsPlannerrDTO;
import com.truper.saen.dto.ResponseTokenDTO;
import com.truper.saen.dto.TotalPlaneadorDto;
import com.truper.saen.dto.TotalPlaneadorMapeo;
import com.truper.saen.feign.CatalogsFeingClient;
import com.truper.saen.persistencia.SaeRepository;
import com.truper.saen.service.ISaeService;

@Service
public class SaeServiceImpl implements ISaeService {
	
	@Autowired
	private SaeRepository saeRepo;
	
	@Autowired
	private ModelMapper maper;

	private final static Integer LUNES=1;
	private final static Integer MARTES=2;
	private final static Integer MIERCOLES=3;
	private final static Integer JUEVES=4;
	private final static Integer VIERNES=5;
	private final static Integer SABADO=6;
	private final static Integer DOMINGO=7;
	private static Map<Integer,List<TotalPlaneadorMapeo>> diasMapeados;
	private static Map<Integer,Integer> TotalesPorDia;
	private static Integer maximoNumeroPlaneadores=0;
	
	private List<CatalogsPlanner> planneadores;
	private List<CatalogsFamilias> familias;
	
	@Autowired
	private CatalogsFeingClient catalogsFeingClient;
	
	@Value("${catalogs.username}")
	private String username;

	@Value("${catalogs.password}")
	private String password;
	
	private Integer sumaDia = 0;
	
	private final String TOTAL_STR = "Total; ";
	
	@Override
	public List<CitaSae> getTotalPlanedorBySemana(String inicio,String fin ) {
		Gson gson = new Gson();
		List<TotalPlaneadorDto> infoBD = saeRepo.getTotalPlanedorBySemana(inicio,fin);
		System.out.println("Base de Batos : " + infoBD.toString() + infoBD.size());
		List<TotalPlaneadorMapeo> result = infoBD.stream().map(d -> maper.map(d, TotalPlaneadorMapeo.class)).collect(Collectors.toList());
		List<CitaSae> lista=getResponse(result);
		System.out.println("Salida "+
				gson.toJson(lista, new TypeToken
						<List<CitaSae>>(){}.getType()));
		System.out.println("Salida "+ lista);
		return lista;
	}

	@Override
	public List<DetallePlaneadorDto> getDetalleByPlaneador(Long idPlaneador) {
		return saeRepo.getDetalleByPlaneador(idPlaneador);
	}
	
	private List<CitaSae> getResponse(List<TotalPlaneadorMapeo> totalPlaneadorDtos) {
		
		RequestToken requestToken = new RequestToken();
		requestToken.setPassword(password);
		requestToken.setUsername(username);
		ResponseTokenDTO token = catalogsFeingClient.getToken(requestToken);
		
		if (token != null) {
			ResponseCatalogsPlannerrDTO response = catalogsFeingClient.getDataPlanners("Bearer " + token.getData().getToken());
			if( response.getData().getPlaneadores() != null && !response.getData().getPlaneadores().isEmpty() ) {
				planneadores = response.getData().getPlaneadores();				
			}
			
			ResponseCatalogsFamiliasDTO respFamilia = catalogsFeingClient.getDataFamilias("Bearer " + token.getData().getToken());
			if( respFamilia.getData().getFamilias() != null && !respFamilia.getData().getFamilias().isEmpty() ) {
				familias = respFamilia.getData().getFamilias();				
			}
		}
		
		List<Integer> diasSemana =Arrays.asList(DOMINGO,LUNES,MARTES, MIERCOLES,JUEVES, VIERNES,SABADO);
		diasMapeados= new HashMap<Integer,List<TotalPlaneadorMapeo>>();
		TotalesPorDia = new HashMap<Integer, Integer>();
		diasSemana.stream().forEach(diaSemana-> {
			sumaDia = 0;
			List<TotalPlaneadorMapeo> listaPorDia =totalPlaneadorDtos.stream().filter(r-> r.getDia().equals(diaSemana)).collect(Collectors.toList());
			//List<String>  planeadores = listaPorDia.stream().map(r -> r.getPlaneador()).distinct().sorted().collect(Collectors.toList());
			List<PlaneadorFamilia>  planeadores = listaPorDia.stream().map(r -> new PlaneadorFamilia(r.getPlaneador(),r.getFamilia(),r.getFolio()) ).distinct().collect(Collectors.toList());
			//List<TotalPlaneadorMapeo> planeadoresAgrupados=new ArrayList<>();
			List<TotalPlaneadorMapeo> planeadoresAgrupadosPrueba=new ArrayList<>();
			/*planeadores.forEach(planeador->{
				Integer cantiadesPorPlaneador=listaPorDia.stream().filter(r-> r.getPlaneador().equals(planeador)).mapToInt(TotalPlaneadorMapeo::getTotalUnidades).sum();
				Optional<TotalPlaneadorMapeo> planeadorDTO=listaPorDia.stream().filter(r-> r.getPlaneador().equals(planeador)).findAny();
				if(planeadorDTO.isPresent()) {
					planeadorDTO.get().setTotalUnidades(cantiadesPorPlaneador);
					planeadoresAgrupados.add(planeadorDTO.get());
				}	
			});*/
			
			planeadores.forEach(prueba->{
				Integer cantiadesPorPlaneador=listaPorDia.stream().filter( r-> ( r.getPlaneador().equals(prueba.getPlaneador()) && r.getFamilia().equals(prueba.getFamilia())) && r.getFolio() == prueba.getFolio() ).mapToInt(TotalPlaneadorMapeo::getUnidades).sum();
				Optional<TotalPlaneadorMapeo> planeadorDTO=listaPorDia.stream().filter(r-> (r.getPlaneador().equals(prueba.getPlaneador()) && r.getFamilia().equals(prueba.getFamilia()))).findAny();
				if(planeadorDTO.isPresent()) {
					sumaDia+=cantiadesPorPlaneador;
					planeadorDTO.get().setUnidades(cantiadesPorPlaneador);
					planeadoresAgrupadosPrueba.add(planeadorDTO.get());
				}	
			});
			diasMapeados.put(diaSemana,planeadoresAgrupadosPrueba);
			TotalesPorDia.put(diaSemana, sumaDia);
			
		} ); 
		maximoNumeroPlaneadores=0;
		diasSemana.stream().forEach(diaSemana-> { 
			Integer size=((List<TotalPlaneadorMapeo> ) diasMapeados.get(diaSemana)).size();
			if(size>maximoNumeroPlaneadores) {
				maximoNumeroPlaneadores = size;
			}
		});
		System.out.println("maximoNumeroPlaneadores "+ maximoNumeroPlaneadores);
		List<CitaSae> responses = new ArrayList<>();
		for(int i=0;i<maximoNumeroPlaneadores.intValue();i++) {
			responses.add(createResponse(i,diasMapeados));
		}		
		responses.add(createTotales(responses.size(),TotalesPorDia));
		
		return responses;
		
	}
	
	private CitaSae createTotales(int i,Map<Integer,Integer> totalesDia) {
		return CitaSae.builder()

				.familiaDomingo(TOTAL_STR)
				.cantUnidDomingo(totalesDia.get(DOMINGO))
				
				
				.familiaLunes(TOTAL_STR)
				.cantUnidLunes(totalesDia.get(LUNES))
					
				.familiaMartes(TOTAL_STR)
				.cantUnidMartes(totalesDia.get(MARTES))

				.familiaMiercoles(TOTAL_STR)
				.cantUnidMiercoles(totalesDia.get(MIERCOLES))
				
				
				.familiaJueves(TOTAL_STR)
				.cantUnidJueves(totalesDia.get(JUEVES))
				
				
				.familiaViernes(TOTAL_STR)
				.cantUnidViernes(totalesDia.get(VIERNES))
				
				
				.familiaSabado(TOTAL_STR)
				.cantUnidSabado(totalesDia.get(SABADO))
				
				.id(i)
				.build();
	}
	
	private CitaSae createResponse(int i, Map<Integer, List<TotalPlaneadorMapeo>> diasMapeados) {
		TotalPlaneadorMapeo domingo= obtieneElemento(i,diasMapeados.get(DOMINGO));
		TotalPlaneadorMapeo lunes= obtieneElemento(i,diasMapeados.get(LUNES));
		TotalPlaneadorMapeo martes= obtieneElemento(i,diasMapeados.get(MARTES));
		TotalPlaneadorMapeo miercoles= obtieneElemento(i,diasMapeados.get(MIERCOLES));
		TotalPlaneadorMapeo jueves= obtieneElemento(i,diasMapeados.get(JUEVES));
		TotalPlaneadorMapeo viernes= obtieneElemento(i,diasMapeados.get(VIERNES));
		TotalPlaneadorMapeo sabado= obtieneElemento(i,diasMapeados.get(SABADO));
		return CitaSae.builder()
			.cantUnidDomingo(domingo.getUnidades())
			.familiaDomingo(getFamilia( domingo.getFamilia()))
			.plannerDomingo(getPlanner(domingo.getPlaneador()))
			.idPlannerDomingo(domingo.getPlaneador())
			
			.cantUnidLunes(lunes.getUnidades())
			.familiaLunes(getFamilia( lunes.getFamilia()))
			.plannerLunes(getPlanner(lunes.getPlaneador()))
			.idPlannerLunes(lunes.getPlaneador())
			
			.cantUnidMartes(martes.getUnidades())
			.familiaMartes(getFamilia( martes.getFamilia()))
			.plannerMartes(getPlanner(martes.getPlaneador()))
			.idPlannerMartes(martes.getPlaneador())
			
			.cantUnidMiercoles(miercoles.getUnidades())
			.familiaMiercoles(getFamilia( miercoles.getFamilia()))
			.plannerMiercoles(getPlanner(miercoles.getPlaneador()))
			.idPlannerMiercoles(miercoles.getPlaneador())
			
			.cantUnidJueves(jueves.getUnidades())
			.familiaJueves(getFamilia( jueves.getFamilia()))
			.plannerJueves(getPlanner(jueves.getPlaneador()))
			.idPlannerJueves(jueves.getPlaneador())
			
			.cantUnidViernes(viernes.getUnidades())
			.familiaViernes(getFamilia( viernes.getFamilia()))
			.plannerViernes(getPlanner(viernes.getPlaneador()))
			.idPlannerViernes(viernes.getPlaneador())
			
			.cantUnidSabado(sabado.getUnidades())
			.familiaSabado(getFamilia( sabado.getFamilia()))
			.plannerSabado(getPlanner(sabado.getPlaneador()))
			.idPlannerSabado(sabado.getPlaneador())
			
			.id(i)
			.build();
	}
	
	private static TotalPlaneadorMapeo obtieneElemento(int i,List<TotalPlaneadorMapeo> lista) {
		if(lista!=null) {
			if(!lista.isEmpty()) {
				if(lista.size()>i) {
					return lista.get(i);
				}
			}
		}
		return TotalPlaneadorMapeo.builder().fechaCita(null).dia(0).planeador(null).unidades(null).build();
	}
	
	private String getPlanner(String idPlanner) {
		if( idPlanner != null ) {
			String nombrePlaneador = idPlanner ;
			
			for (CatalogsPlanner planner : planneadores) {
				if(  idPlanner.equals(planner.getCodigoPlaneador()) ) {
					nombrePlaneador+= " | "+ planner.getUser().getNombre();
					return nombrePlaneador;
				}
			}
			
			return nombrePlaneador;
		}
		return null;
		
	}
	
	private String getFamilia(String idFamilia) {
		if( idFamilia != null ) {
			String nombreFamilia = idFamilia ;
			
			for (CatalogsFamilias familia : familias) {
				if(  idFamilia.equals(familia.getCodigo()) ) {
					nombreFamilia = familia.getDescripcion();
					return nombreFamilia;
				}
			}
			
			return nombreFamilia;
		}
		return null;
		
	}
	
}
