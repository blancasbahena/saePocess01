package com.truper.saen.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class TotalPlaneadorMapeo  {
	private Date fechaCita;
	private Integer unidades;
	private String planeador;
	private Integer dia;
	private String familia;
	private Long folio;
}
