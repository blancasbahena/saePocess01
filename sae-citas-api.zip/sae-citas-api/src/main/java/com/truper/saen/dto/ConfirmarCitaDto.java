package com.truper.saen.dto;

import lombok.Data;

@Data
public class ConfirmarCitaDto {
	private Long idCita;
}
