package com.truper.saen.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ResponseCatalogsPlannerrDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1328134103122069962L;
	
	private DataCatalogsPlanner data;

}
