package com.truper.saen.persistencia;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.truper.saen.commons.entities.CatStatusCita;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeCitas;
import com.truper.saen.dto.CitaDiaMesAnioDto;
import com.truper.saen.dto.CitasCalendarioDto;
import com.truper.saen.dto.DetalleSaeCitaDto;
import com.truper.saen.dto.DiasCitaMesAnio;

public interface CitaRepository extends JpaRepository<SaeCitas, Long>{
	
	List<SaeCitas> findByIdSae(Sae idSae);
	
	List<SaeCitas> findByIdSaeAndIdStatus(Sae idSae,CatStatusCita catCitas);
	
	@Query("SELECT COUNT(sc) FROM SaeCitas sc WHERE sc.fechaCita=:fechaCita")
    Long getCitasByFecha(@Param("fechaCita") Date fechaCita);
	
	@Query("SELECT COUNT(sc) FROM SaeCitas sc WHERE sc.fechaCita=:fechaCita and sc.idStatus=1")
    Long getCitasByFechaActivas(@Param("fechaCita") Date fechaCita);
	 
	
	@Query("SELECT COUNT(sc) FROM SaeCitas sc WHERE sc.fechaCita=:fechaCita and sc.confirmada=1")
    Long getCitasConfirmadasByFecha(@Param("fechaCita") Date fechaCita);
	
	@Query(value="SELECT \r\n"
			+ "id,\r\n"
			+ "id_sae as idSae,\r\n"
			+ "fecha_cita as fechaCita,\r\n"
			+ "fecha_confirmacion as fechaConfirmacion,\r\n"
			+ "confirmada ,\r\n"
			+ "id_status as idStatus,\r\n"
			+ "user_confirma as usuario\r\n"
			+ "FROM sae_citas WHERE MONTH(fecha_cita) = :mes AND YEAR(fecha_cita) = :anio", nativeQuery=true)
	List<CitasCalendarioDto> getCitasByMesAndAnio(@Param("mes") Long mes, @Param("anio") Long anio);
	
	
	
	@Query(value="SELECT sd.idPO as po ,sd.material,\r\n"
			+ "	sd.descripcion, sd.cantidad ,\r\n"
			+ "	s.IDAMin as ida  \r\n"
			+ "from Sae s , SaeDetalle sd \r\n"
			+ "where s.folio = sd.idSae and s.folio =:folio", nativeQuery=true)
	List<DetalleSaeCitaDto> getDetalleSaeByFolio(@Param("folio") Long folio);
	
	SaeCitas findByIdAndConfirmada(Long idCita ,Boolean confirmada);
	
	@Query(value="SELECT s.idProveedor , s.folio , s.IDAMin as ida, s.idStatus  \r\n" + 
			"	FROM sae_citas ct, Sae s\r\n" + 
			"WHERE ct.id_sae = s.folio  AND\r\n" + 
			"DAY(fecha_cita)=:dia AND \r\n" + 
			"s.tipo = 'N' AND\r\n" +
			"MONTH(fecha_cita) = :mes  AND YEAR(fecha_cita) = :anio" , nativeQuery=true)
	List<CitaDiaMesAnioDto> getCitasPorDiaMesAndAnio(@Param("dia") Long dia,@Param("mes") Long mes, @Param("anio") Long anio);
	
	@Query(value="SELECT DAY(ct.fecha_cita) as dia ,MONTH(fecha_cita) as mes ,YEAR(fecha_cita) as anio,count(DAY(ct.fecha_cita)) as cont\r\n" + 
			"	FROM sae_citas ct, Sae s\r\n" + 
			"WHERE ct.id_sae = s.folio  AND\r\n" + 
			"MONTH(fecha_cita) = :mes  AND YEAR(fecha_cita) = :anio\r\n" + 
			"AND s.tipo = 'N'\r\n" +
			"GROUP by ct.fecha_cita ", nativeQuery=true)
	List<DiasCitaMesAnio> getNumCitasPorMesAndAnio(@Param("mes") Long mes, @Param("anio") Long anio);
	
	/*@Query(value="SELECT DAY(ct.fecha_cita) as dia,MONTH(fecha_cita) as mes ,YEAR(fecha_cita) as anio, count(DAY(ct.fecha_cita)) as cont\r\n" + 
			"	FROM sae_citas ct, Sae s\r\n" + 
			"WHERE ct.id_sae = s.folio  AND\r\n" + 
			"DAY(fecha_cita)=:dia AND\r\n" + 
			"MONTH(fecha_cita) = :mes  AND YEAR(fecha_cita) = :anio\r\n" + 
			"GROUP by ct.fecha_cita ", nativeQuery=true)*/
	@Query(value="SELECT DAY(ct.fecha_cita) as dia,MONTH(fecha_cita) as mes ,YEAR(fecha_cita) as anio, count(DAY(ct.fecha_cita)) as cont\r\n" + 
			"	FROM sae_citas ct, Sae s\r\n" + 
			"WHERE ct.id_sae = s.folio  AND\r\n" + 
			"DAY(fecha_cita)=:dia AND\r\n" + 
			"MONTH(fecha_cita) = :mes  AND YEAR(fecha_cita) = :anio\r\n" + 
			"AND s.tipo = 'N'\r\n" + 
			"GROUP by ct.fecha_cita", nativeQuery=true)
	List<DiasCitaMesAnio> getNumCitasPorDiaMesAndAnio(@Param("dia") Long dia,@Param("mes") Long mes, @Param("anio") Long anio);
	
	
	
}
