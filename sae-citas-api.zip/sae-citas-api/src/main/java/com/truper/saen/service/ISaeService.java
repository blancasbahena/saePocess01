package com.truper.saen.service;

import java.util.List;

import com.truper.saen.dto.CitaSae;
import com.truper.saen.dto.DetallePlaneadorDto;

public interface ISaeService {
	
	List<CitaSae> getTotalPlanedorBySemana(String inicio,String fin);
	List<DetallePlaneadorDto> getDetalleByPlaneador(Long idPlaneador);
}
