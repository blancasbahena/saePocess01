package com.truper.saen.persistencia;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.truper.saen.commons.entities.Sae;
import com.truper.saen.dto.DetallePlaneadorDto;


public interface CalendarioRepository extends JpaRepository<Sae, Long>{

	@Query(value="		SELECT s.folio, s.nombreProveedor,s.IDAMin,s.conteoRevisado ,s.tipo  \r\n"
			+ "			FROM Sae s\r\n"
			+ "			INNER JOIN SaeDetalle sd on s.folio = sd.idSae \r\n"
			+ "			INNER JOIN sae_citas sc on sc.id_sae = s.folio\r\n"
			+ "			WHERE sd.planner =:planner\r\n"
			+ "			AND sc.fecha_cita =:dia \r\n"
			+ "		    GROUP BY s.folio, s.nombreProveedor,s.IDAMin,s.conteoRevisado ,s.tipo;", nativeQuery=true)
	List<DetallePlaneadorDto> getDetalleByPlaneadorAndDia(@Param("planner") String planner, @Param("dia") String dia);
	
}
