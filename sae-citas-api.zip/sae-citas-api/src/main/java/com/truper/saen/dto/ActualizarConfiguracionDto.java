package com.truper.saen.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ActualizarConfiguracionDto {
	
	private String llave;
	private String value;

}
