package com.truper.saen.controller.citas;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.common.Respuesta;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.service.CalendarioZMPService;
import com.truper.saen.service.ICitaService;
import com.truper.saen.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Servicio para obtener el calendario WS CITAS API")
public class CalendarioController {

	@Autowired
	private ICitaService citaService;
	
	@Autowired
	private CalendarioZMPService calendarService;

	@ApiOperation(value = "Servicio para obtener el calendario", notes = "\"Servicio para la obtencion de calendario")
	@RequestMapping(value = "/obtenerCalendario", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerCalendario() {

		log.info("[GET /obtenerCalendario] | INICIO -  {} - HORA - {} ", UtilDates.getHora());

		Map<String, Object> data = new HashMap<>();
		data.put("data", citaService.getCitas());

		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Cita creada con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerCalendario] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener dias por Sae", notes = "Servicio para obtener dias por Sae")
	@RequestMapping(value = "/obtenerDiasPorSae/{idSae}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerDiasPorSae(@PathVariable("idSae") Long idSae) {

		log.info("[GET /obtenerDiasPorSae] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("citas", citaService.getDiasBySae(idSae));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener dias por sae obtenidas  con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerDiasPorSae] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener citas por dia mes y anio", notes = "Servicio para obtener citas por dia mes y anio")
	@RequestMapping(value = "/getCitasPorMesAndAnio/{mes}/{anio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> getCitasPorMesAndAnio(@PathVariable("mes") Long mes,
			@PathVariable("anio") Long anio) {
		log.info("[GET /getCitasPorMesAndAnio] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("citas", citaService.getCitasPorMesAndAnio(mes, anio));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Consulta de calendario obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /getCitasPorMesAndAnio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener sae por cita", notes = "Servicio para obtener sae por cita")
	@RequestMapping(value = "/obtenerSaePorCita/{idCita}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerSaePorCita(@PathVariable("idCita") Long idCita) {
		log.info("[GET /obtenerSaePorCita] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("sae", citaService.getSaeByCita(idCita));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener Sae por Cita obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /getCitasPorMesAndAnio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener sae por dia mes y anio", notes = "Servicio para obtener sae por dia mes y anio")
	@RequestMapping(value = "/obtenerSaePorDiaMesAnio/{dia}/{mes}/{anio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerSaePorDiaMesAnio(@PathVariable("dia") Long dia,
			@PathVariable("mes") Long mes, @PathVariable("anio") Long anio) {
		log.info("[GET /obtenerSaePorDiaMesAnio] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("sae", citaService.getCitasPorDiaMesAndAnio(dia, mes, anio));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener Sae por Cita obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerSaePorDiaMesAnio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener el numero de citas por dia apartir del mes y anio", notes = "Servicio para obtener el numero de citas por dia apartir del mes y anio")
	@RequestMapping(value = "/obtenerNumCitasPorMesAnio/{mes}/{anio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerNumCitasPorMesAnio(@PathVariable("mes") Long mes,
			@PathVariable("anio") Long anio) {
		log.info("[GET /obtenerNumCitasPorMesAnio] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("sae", citaService.getNumCitasPorMesAndAnio(mes, anio));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener Sae por Cita obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerNumCitasPorMesAnio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@ApiOperation(value = "Servicio para obtener sae por dia mes y anio", notes = "Servicio para obtener sae por dia mes y anio")
	@RequestMapping(value = "/obtenerNumCitasPorDiaMesAnio/{dia}/{mes}/{anio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> obtenerNumCitasPorDiaMesAnio(@PathVariable("dia") Long dia,
			@PathVariable("mes") Long mes, @PathVariable("anio") Long anio) {
		log.info("[GET /obtenerSaePorDiaMesAnio] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("sae", citaService.getNumCitasPorDiaMesAndAnio(dia, mes, anio));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener Sae por Cita obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /obtenerSaePorDiaMesAnio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}

	@ApiOperation(value = "Servicio para obtener sae por folio", notes = "Servicio para obtener sae por folio")
	@RequestMapping(value = "/getDetalleSaeByFolio/{idFolio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> getDetalleSaeByFolio(@PathVariable("idFolio") Long idFolio) {

		log.info("[GET /getDetalleSaeByFolio] | INICIO -  {} - HORA - {} ", UtilDates.getHora());
		Map<String, Object> data = new HashMap<>();
		data.put("detalleSae", citaService.getDetalleSaeByFolio(idFolio));
		Respuesta respuesta = new Respuesta();

		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Obtener detalle Sae por folio obtenida con exito");
		respuesta.setTipoMensaje(ResponseMessage.TIPO_EXITO.getMensaje());
		log.info("[GET /getDetalleSaeByFolio] | FIN -  {} - HORA - {} ", UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
	@GetMapping(value = "calendario/getDetalles/planner/{planner}/fecha/{fecha}")
	public ResponseEntity<ResponseVO> getDetallesByPlannerAndDate(@PathVariable("planner") String planner,@PathVariable("fecha") String fecha ){
		
		log.info("[GET calendario/getDetalles/planner/{}/fecha/{}] | INICIO -  {} - HORA - {} ",planner,fecha, UtilDates.getHora());
		Respuesta respuesta = calendarService.getDetalleByPlaneadorAndFecha(planner, fecha); 
		log.info("[GET calendario/getDetalles/planner/{}/fecha/{}] | FIN -  {} - HORA - {} ",planner,fecha, UtilDates.getHora());
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
}
