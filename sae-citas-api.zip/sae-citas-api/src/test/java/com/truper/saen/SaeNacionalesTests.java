package com.truper.saen;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.truper.saen.dto.DiasCitaMesAnio;
import com.truper.saen.service.ICitaService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class SaeNacionalesTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	private ICitaService citaService;
	
	@Test
	public void listarCitas() {
		log.info("entra listarCitas de febrero del 2023");
		List<DiasCitaMesAnio> menu = citaService.getNumCitasPorMesAndAnio(new Long(2), new Long(2023));
		menu.stream().forEach((cita) -> {
			System.out.println(cita.getDia()+": "+cita.getCont());
		});
	}
	
	@Test
	public void listarCitasDia() {
		log.info("entra listarCitasDia del 24 de febrero del 2023");
		List<DiasCitaMesAnio> menu = citaService.getNumCitasPorDiaMesAndAnio(new Long(24),new Long(2), new Long(2023));
		menu.stream().forEach((cita) -> {
			System.out.println(cita.getDia()+": "+cita.getCont());
		});
	}

}
