package com.truper.saen.controller.citas;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.truper.saen.commons.dto.ResponseVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class CalendarioControllerTest {
	private final static String PLANNER = "P12";
	private final static String FECHA = "2023-02-12";
	@Autowired
	private CalendarioController calendario;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void getDetalleByPlannerAndDateTest() {
		log.info("Inicia test en getDetalleByPlannerAndDateTest");
		ResponseEntity<ResponseVO> response = calendario.getDetallesByPlannerAndDate(PLANNER, FECHA);
		assertNotNull(response);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		log.info(response.toString());
	}

}
