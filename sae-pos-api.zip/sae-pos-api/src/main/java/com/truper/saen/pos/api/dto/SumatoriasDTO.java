package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SumatoriasDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7018294106831620372L;
	Double cantidad;
	Double monto;
	Double peso;
	Double volumen;
}
