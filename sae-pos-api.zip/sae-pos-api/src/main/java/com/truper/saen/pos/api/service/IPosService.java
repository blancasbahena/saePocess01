package com.truper.saen.pos.api.service;

import java.util.Set;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.pos.api.dto.PosDTO;
import com.truper.saen.pos.api.dto.ResponseImportacionesDetalleOrdenDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;

public interface IPosService {
	
	Set<ResponseImportacionesDetalleOrdenDTO> getDataWsPosApi(PosDTO posDTO) throws Exception;

	ResponseVO  getDetalles(Long id);
	
	RespuestaDTO getPOsByIdSae(Long idSae);
	
	RespuestaDTO getPosRevisadosByIdSae(Long idSae);
}
