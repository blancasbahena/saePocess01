package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class AddPosDetalleDTO  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "La propiedad numeroOrden es obligatoria y no puede venir vacia")
	private String numeroOrden;
	
	@NotBlank(message = "La propiedad posicion es obligatoria y no puede venir vacia")
	private String posicion;
	
	private String condicionPago;
	private String item;
	private Double poTotalQuantity;
	private Double peso;
	private Double volumen;
	private String planeador;
	private String centro;
	private String numOrdenSecundaria;
	private Double cantidadUnidadMedida;
	private Double factorCantidadUnidadMedida;
	private String itemDescription;
	private String origen;
	private String tipo;
	private String codigo;
	private String descripcion;
	private String planeadorProducto;
	private String familia;
	private Double monto;
	private String unidadMedidaProducto;
	
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaEntrega;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaPI;
	
}

