package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class DeletePosDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@NotNull(message = "La propiedad idSae es obligatoria y no puede venir vacia")
	private Long idSae;
	private String userName;
	@Valid
	private List<DeletePosDetalleDTO> listPoDetalle;
}

