package com.truper.saen.pos.api.service;

import java.util.List;

import com.truper.saen.commons.dto.SaeRevisadoDto;
import com.truper.saen.pos.api.dto.DetalleSaeDTO;
import com.truper.saen.pos.api.dto.RequestRevisadoDto;
import com.truper.saen.pos.api.dto.SaeDetalleDTO;

public interface ISaeRevisadosService {
	 
	public SaeRevisadoDto cloneSAE(RequestRevisadoDto dto) ;
	public SaeRevisadoDto getSae(Long folio) ; 
	public List<SaeRevisadoDto> getAllSaes() ; 
	public SaeRevisadoDto actualizoSAE(RequestRevisadoDto dtoReq);
	
	public SaeRevisadoDto resumenSaeBySae(Long folio) ; 
	public List<SaeRevisadoDto> resumenSaeBySaes() ; 

	List<SaeDetalleDTO> detalleSaeRevisadoBySae(Long folio);
}
