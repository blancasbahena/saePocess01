package com.truper.saen.pos.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.pos.api.dto.DetalleSaeDTO;
import com.truper.saen.pos.api.dto.ResumenSaeDTO;

@Repository
public interface SaeRevisadosRepository extends JpaRepository<SaeRevisado, Long> {

	@Query(value = "SELECT s.folio , s.idProveedor , "
			+ "DATEDIFF(day, s.created ,GETDATE())  diasTranscurridos, s.ETASolicitada eta , "
			+ "s.BO bo , s.OS os , s.totalCodigos, s.idTipoUnidad , s.Unidades unidades, s.Monto monto "
			+ "FROM SAE s where  s.folio=:folio ", nativeQuery = true)
	List<ResumenSaeDTO> resumenSaeBySae(@Param("folio") Long folio);

	/*@Query(value = "select\r\n" + "	ROW_NUMBER() OVER(\r\n" + "ORDER BY\r\n" + "	folio DESC) id,\r\n"
			+ "	idPO ,\r\n" + "	posSap,\r\n" + "	planner,\r\n" + "	codigo,\r\n" + "	descripcion ,\r\n"
			+ "	cantidad ,\r\n" + "	IDAMin idaMin,\r\n" + "	SS ss,\r\n" + "	BO bo ,\r\n" + "	OS os ,\r\n"
			+ "	centro ,\r\n" + "	picoPlan ,\r\n" + "	picoReal ,\r\n" + "	monto,\r\n" + "	fechaPI fechaPi,\r\n"
			+ "	diferenciaFecha,\r\n" + "	esBorrado ,\r\n" + "	esModificado ,\r\n" + "	esNuevo,\r\n"
			+ "	ETA eta,\r\n" + "	ETASolicitada etaSolicitada,\r\n" + "	unidades,\r\n"
			+ "	cantidadModificado cantidadModificado\r\n" + "from\r\n" + "	(\r\n" + "	SELECT DISTINCT\r\n"
			+ "		s.folio as folio,\r\n" + "		sd.idPO ,\r\n" + "		sd.idPosicion posSap,\r\n"
			+ "		sd.planner,\r\n" + "		sd.codigo,\r\n" + "		sd.descripcion ,\r\n"
			+ "		sd2.cantidad ,\r\n" + "		sd.IDAMin idaMin,\r\n" + "		sd.SS ss,\r\n" + "		sd.BO bo ,\r\n"
			+ "		sd.OS os ,\r\n" + "		sd.centro ,\r\n" + "		sd.picoPlan ,\r\n" + "		sd.picoReal ,\r\n"
			+ "		sd.monto,\r\n" + "		sd.fechaPI fechaPi,\r\n"
			+ "		DATEDIFF(day, sd.fechaPI , s.ETASolicitada) diferenciaFecha,\r\n" + "		sd.esBorrado ,\r\n"
			+ "		sd.esModificado ,\r\n" + "		sd.esNuevo,\r\n" + "		s.ETA eta,\r\n"
			+ "		s.ETASolicitada etaSolicitada,\r\n" + "		s.unidades,\r\n"
			+ "		sd.cantidadModificado cantidadModificado\r\n" + "	from\r\n" + "		SaeRevisados s\r\n"
			+ "		inner join SaeDetalleRevisado sd on s.folio =sd.idSae \r\n"
			+ "		left join SaeDetalle sd2 on sd.idSae = sd2.idSae \r\n" + "	where\r\n"
			+ "		 s.folio = :folio\r\n" + "union ALL\r\n" + "	SELECT DISTINCT \r\n"
			+ "		s.folio as folio,\r\n" + "		sd2.idPO ,\r\n" + "		sd2.idPosicion posSap,\r\n"
			+ "		sd2.planner,\r\n" + "		sd2.codigo,\r\n" + "		sd2.descripcion ,\r\n"
			+ "		sd2.cantidad ,\r\n" + "		sd2.IDAMin idaMin,\r\n" + "		sd2.SS ss,\r\n" + "		sd2.BO bo ,\r\n"
			+ "		sd2.OS os ,\r\n" + "		sd2.centro ,\r\n" + "		sd2.picoPlan ,\r\n"
			+ "		sd2.picoReal ,\r\n" + "		sd2.monto,\r\n" + "		sd2.fechaPI fechaPi,\r\n"
			+ "		DATEDIFF(day, sd2.fechaPI , s.ETASolicitada) diferenciaFecha,\r\n" + "		sd.esBorrado ,\r\n"
			+ "		sd.esModificado ,\r\n" + "		sd.esNuevo,\r\n" + "		s.ETA eta,\r\n"
			+ "		s.ETASolicitada etaSolicitada,\r\n" + "		s.unidades,\r\n"
			+ "		sd.cantidadModificado cantidadModificado\r\n" + "	from\r\n" + "		Sae s\r\n"
			+ "		inner join SaeDetalle sd2 on s.folio =sd2.idSae \r\n"
			+ "		left join SaeDetalleRevisado sd on sd.idSae = sd.idSae \r\n" + "	where\r\n"
			+ "		 s.folio = :folio) as ps", nativeQuery = true)
	List<DetalleSaeDTO> detalleSaeBySae(@Param("folio") Long folio); */



	@Query(value = "SELECT ROW_NUMBER() OVER(ORDER BY s.folio  DESC) id, sd.idPO ,sd.idPosicion  posSap, sd.planner,sd.codigo, "
			+ " sd.descripcion ,(case \r\n"
			+ "		WHEN (select sd2.cantidad  from SaeDetalle sd2 where sd2.idPO  =sd.idPO and sd2.idPosicion = sd.idPosicion) is NULL \r\n"
			+ "		then (sd.cantidad) \r\n"
			+ "		WHEN (select sd2.cantidad  from SaeDetalle sd2 where sd2.idPO  =sd.idPO and sd2.idPosicion = sd.idPosicion) is NOT NULL \r\n"
			+ "		THEN (select sd2.cantidad  from SaeDetalle sd2 where sd2.idPO  =sd.idPO and sd2.idPosicion = sd.idPosicion)\r\n"
			+ "	end\r\n"
			+ "	) as cantidad, COALESCE (sd.IDAMin,0) idaMin, sd.tipo , "
			+ " sd.SS  ss, sd.BO  bo , sd.OS  os , sd.centro , sd.picoPlan , "
			+ " sd.picoReal , sd.monto, sd.fechaPI fechaPi, "
			+ " DATEDIFF(day, sd.fechaPI  ,s.ETASolicitada)  diferenciaFecha,sd.esBorrado  , sd.esModificado  , sd.esNuevo, s.ETA eta, s.ETASolicitada etaSolicitada,sd.cantidadModificado cantidadModificado,s.unidades, "
			+ " sd.diasConsumoDisponible "
			+ "  from SaeRevisados  s, SaeDetalleRevisado sd "
			+ " where s.folio = sd.idSae and  s.folio=:folio ", nativeQuery = true)
			List<DetalleSaeDTO> detalleSaeBySae(@Param("folio") Long folio);

	List<SaeRevisado> findByIdProveedor(Integer idProveedor);

}
