package com.truper.saen.pos.api.dto;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.truper.saen.pos.api.response.vo.ResponseVO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter 
@Getter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespuestaDTO extends ResponseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    @JsonIgnore
    private HttpStatus estado;
    
    public RespuestaDTO(String tipo, String msg, String nombreObjeto, Object data) {
		super(tipo, msg, nombreObjeto, data);
	}

	public RespuestaDTO(String tipo, String msg,  String descError, String nombreObjeto, Object data) {
		super(tipo, msg, descError, nombreObjeto, data);
	}
    
}
