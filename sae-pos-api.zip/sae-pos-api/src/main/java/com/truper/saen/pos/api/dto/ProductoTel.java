package com.truper.saen.pos.api.dto;

import lombok.Data;


@Data
public class ProductoTel{

    private String codigo;
    private String clave;
    private String descripcion;
    private Boolean refaccion;
    private Integer masterCart;
    private Double volumenCart;
    private Double pesoCart;
    private Double pesoMaster;
    private Double volumenMaster;
    private Boolean productoOEM;

}
