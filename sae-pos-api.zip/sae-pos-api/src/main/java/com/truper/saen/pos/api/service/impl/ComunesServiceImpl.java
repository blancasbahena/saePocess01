package com.truper.saen.pos.api.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.pos.api.dto.CatalogsPrioridad;
import com.truper.saen.pos.api.repository.CatPrioridadesDao;
import com.truper.saen.pos.api.service.IComunesService;

@Service
public class ComunesServiceImpl implements IComunesService{
	@Autowired
	private CatPrioridadesDao catPrioridadesDao; 

	@Override
	public Prioridad getPrioridad(CatPrioridades catPrioridades, String tipo, Integer idaMin) {
		Prioridad prioridad = new Prioridad();

		if (catPrioridades != null) {
			prioridad.setIdPrioridad(catPrioridades.getIdPrioridad());
			prioridad.setDescripcion(catPrioridades.getDescripcion());
			prioridad.setColor(catPrioridades.getColor());
			return prioridad;
		}

		Optional<CatPrioridades> catPrioridad = null;

		if (tipo == null) {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
			return prioridad;
		}

		if (tipo.equals("M") && idaMin <= 15) {
			catPrioridad = catPrioridadesDao.findById(1);
		} else if (tipo.equals("M") && (idaMin >= 16 && idaMin <= 30)) {
			catPrioridad = catPrioridadesDao.findById(2);
		} else if (tipo.equals("M") && (idaMin >= 31 && idaMin <= 45)) {
			catPrioridad = catPrioridadesDao.findById(3);
		} else if (tipo.equals("M") && idaMin >= 46) {
			catPrioridad = catPrioridadesDao.findById(4);
		} else if (tipo.equals("N") && idaMin <= 10) {
			catPrioridad = catPrioridadesDao.findById(5);
		} else if (tipo.equals("N") && (idaMin >= 11 && idaMin <= 30)) {
			catPrioridad = catPrioridadesDao.findById(6);
		} else if (tipo.equals("N") && (idaMin > 30)) {
			catPrioridad = catPrioridadesDao.findById(7);
		}

		if (catPrioridad.isPresent()) {
			prioridad.setIdPrioridad(catPrioridad.get().getIdPrioridad());
			prioridad.setDescripcion(catPrioridad.get().getDescripcion());
			prioridad.setColor(catPrioridad.get().getColor());
		} else {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
		}
		return prioridad;
	}
	
	public Prioridad getPrioridadZMP(CatPrioridades catPrioridades, Integer valor, List<CatalogsPrioridad> prioridades) {
		
		Prioridad prioridad = new Prioridad();

		if( valor == null)
			valor = 0;
		
		if (catPrioridades != null) {
			prioridad.setIdPrioridad(catPrioridades.getIdPrioridad());
			prioridad.setDescripcion(catPrioridades.getDescripcion());
			prioridad.setColor(catPrioridades.getColor());
			return prioridad;
		}
		
		for (CatalogsPrioridad catprioridad : prioridades) {
			if( valor >= catprioridad.getRangoMin() && valor <= catprioridad.getRangoMax() ) {
				prioridad.setColor(catprioridad.getColor());
				prioridad.setDescripcion(catprioridad.getDescripcion());
				prioridad.setIdPrioridad(catprioridad.getIdPrioridad());
				return prioridad;
			}
		}
		if( prioridad.getIdPrioridad() == null ) {
			prioridad.setIdPrioridad(0);
			prioridad.setDescripcion("Prioridad no identificada");
			prioridad.setColor("#000000");
		}
		
		return prioridad;
	}

}
