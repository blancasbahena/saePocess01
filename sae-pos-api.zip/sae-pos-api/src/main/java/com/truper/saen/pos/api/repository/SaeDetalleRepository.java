package com.truper.saen.pos.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;

@Repository
public interface SaeDetalleRepository extends JpaRepository<SaeDetalle, SaeDetalleId>{
	
}
