package com.truper.saen.pos.api;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import lombok.extern.slf4j.Slf4j;
@SpringBootApplication
@Slf4j
@EnableEurekaClient
@EnableFeignClients
@EntityScan("com.truper.saen.commons.entities")
public class SpringBootSwagger3SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSwagger3SecurityApplication.class, args);
		/*UserDetailsServices service = new UserDetailsServices();
		UserDetails principal_2 = service.loadUserByUsername("example");
		JWUtil jwutil = new JWUtil();
		
		log.info("Este es un servicio de log4j {} ",jwutil.generaToken(principal_2));
		log.debug("Este es un servicio de log4j {} ",jwutil.generaToken(principal_2));
		log.warn("Este es un servicio de log4j {}",jwutil.generaToken(principal_2));
		log.error("Este es un servicio de log4j {}",jwutil.generaToken(principal_2));*/
	}

}