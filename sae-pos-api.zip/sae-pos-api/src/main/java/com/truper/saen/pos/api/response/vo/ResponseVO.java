package com.truper.saen.pos.api.response.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
@AllArgsConstructor
public class ResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String mensaje;
	private String tipoMensaje;
	private String folio;
	private String descripcionError;
	private Map<String, Object> data;
	
	public ResponseVO() {
		this.folio = UUID.randomUUID().toString();
	}
	
	public static String getFolioActual() {
		return  UUID.randomUUID().toString();
	}
	
	public ResponseVO(String tipo, String msg,String nombreObjeto,Object data) {
		this.mensaje = msg;
		this.tipoMensaje =tipo;
		this.data = new HashMap<String, Object>();
		this.data.put(nombreObjeto, data);
		this.folio = UUID.randomUUID().toString();
	}
	
	public ResponseVO(String tipo, String msg, String descError, String nombreObjeto, Object data) {
		this.mensaje = msg;
		this.tipoMensaje = tipo;
		this.descripcionError = descError;
		this.data = new HashMap<String, Object>();
		this.data.put(nombreObjeto, data);
		this.folio = UUID.randomUUID().toString();
	} 
	
}
