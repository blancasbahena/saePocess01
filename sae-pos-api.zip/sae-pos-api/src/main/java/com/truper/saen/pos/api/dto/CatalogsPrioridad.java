package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class CatalogsPrioridad implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer idPrioridad;
	private String descripcion;
	private String color;
	private Integer rangoMin;
	private Integer rangoMax;
	
}
