package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class UpdatePosDetalleDTO  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "La propiedad numeroOrden es obligatoria y no puede venir vacia")
	private String numeroOrden;
	
	@NotBlank(message = "La propiedad posicion es obligatoria y no puede venir vacia")
	private String posicion;
	
	@NotNull(message = "La propiedad cantidad es obligatoria y no puede venir vacia")
	private Double cantidad;
	
	@NotNull(message = "La propiedad peso es obligatoria y no puede venir vacia")
	private Double peso;
	
	@NotNull(message = "La propiedad volumen es obligatoria y no puede venir vacia")
	private Double volumen;
	
}
