package com.truper.saen.pos.api.dto;

import java.util.Date;

public interface ResumenSaeDTO {

	Long getFolio();

	Long getIdProveedor();

	Long getDiasTranscurridos();

	Date getEta();

	Double getBo();

	Long getOs();

	Long getTotalCodigos();

	Long getIdTipoUnidad();

	Long getUnidades();

	Double getMonto();

}
