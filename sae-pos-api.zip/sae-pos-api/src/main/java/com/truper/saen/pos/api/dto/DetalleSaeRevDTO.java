package com.truper.saen.pos.api.dto;

import java.util.Date;

import com.truper.saen.commons.dto.Prioridad;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DetalleSaeRevDTO {
	private Long id;
	private Long idPO;
	private Long posSap;
	private String planner;
	private String codigo;
	private String descripcion;
	private Long cantidad;
	private Long idaMin;
	private Long ss;
	private Double bo;
	private Long os;
	private String centro;
	private Long picoPlan;
	private Long picoReal;
	private Double monto;
	private Date fechaPi;
	private Long diferenciaFecha;
	private Long unidades;
	private Date etaSolicitada;
	private Date eta;
	private Boolean esNuevo;
	private Boolean esBorrado;	
	private Boolean esModificado;
	private Double cantidadModificado;
	private Double pesoModificado;
	private Double volumenModificado;
	private String accion;
	private Date fechaEntrega;
	private Prioridad prioridad;
}
