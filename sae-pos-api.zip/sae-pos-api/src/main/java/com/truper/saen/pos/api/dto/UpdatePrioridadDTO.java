package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class UpdatePrioridadDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long idSae;
	private String numeroOrden;
	private String posicion;
	private Integer idPrioridad;
}
