package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.Date;

import com.truper.saen.commons.dto.Prioridad;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SaeDetalleDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long idPO;
	private Long posSap;
	private String planner;
	private String codigo;
	private String descripcion;
	private Long cantidad;
	private Long idaMin;
	private Long ss;
	private Double bo;
	private Long os;
	private String centro;
	private Long picoPlan;
	private Long picoReal;
	private Double monto;
	private Date fechaPi;
	private Long diferenciaFecha;
	private Long unidades;
	private Date etaSolicitada;
	private Date fechaEntrega;
	private Date eta;

	private Boolean esNuevo;
	private Boolean esBorrado;
	private Boolean esModificado;
	private Double cantidadModificado;
	private Double pesoModificado;
	private Double volumenModificado;

	private String accion;
	private String tipo;
	private Prioridad prioridad;
	private Long peso;
	private Double volumen;
	
	

	public SaeDetalleDTO(DetalleSaeDTO dto, Prioridad prioridad) {
		super();
		this.id = dto.getId();
		this.idPO = dto.getIdPO();
		this.posSap = dto.getPosSap();
		this.planner = dto.getPlanner();
		this.codigo = dto.getCodigo();
		this.descripcion = dto.getDescripcion();
		this.cantidad = dto.getCantidad();
		this.idaMin =dto.getIdaMin();
		this.ss = dto.getSs();
		this.bo = dto.getBo();
		this.os = dto.getOs();
		this.centro = dto.getCentro();
		this.picoPlan = dto.getPicoPlan();
		this.picoReal = dto.getPicoReal();
		this.monto = dto.getMonto();
		this.fechaPi = dto.getFechaPi();
		this.diferenciaFecha = dto.getDiferenciaFecha();
		this.unidades = dto.getUnidades();
		this.etaSolicitada = dto.getEtaSolicitada();
		this.fechaEntrega = dto.getFechaEntrega();
		this.eta = dto.getEta();
		this.esNuevo = dto.getEsNuevo();
		this.esBorrado = dto.getEsBorrado();
		this.esModificado = dto.getEsModificado();
		this.cantidadModificado = dto.getCantidadModificado();
		this.pesoModificado = dto.getPesoModificado();
		this.volumenModificado = dto.getVolumenModificado();
		this.accion = dto.getAccion();
		this.tipo = dto.getTipo();
		this.prioridad= prioridad;
		this.peso=dto.getPeso();
		this.volumen=dto.getVolumen();
	}
}
