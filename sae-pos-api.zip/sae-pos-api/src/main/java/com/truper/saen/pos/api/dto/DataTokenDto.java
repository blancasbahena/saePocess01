package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataTokenDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 759219235550964847L;
	private String token;
	
}
