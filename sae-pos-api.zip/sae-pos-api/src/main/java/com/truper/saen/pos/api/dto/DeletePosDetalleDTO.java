package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class DeletePosDetalleDTO  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "La propiedad numeroOrden es obligatoria y no puede venir vacia")
	private String numeroOrden; // idPo
	
	@NotBlank(message = "La propiedad posicion es obligatoria y no puede venir vacia")
	private String posicion; //idPosicion
	
}