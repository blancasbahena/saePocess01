package com.truper.saen.pos.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.User;

public interface UserDao extends JpaRepository<User, Long>{

	Optional<User> findByUserName(String userName);
	
}
