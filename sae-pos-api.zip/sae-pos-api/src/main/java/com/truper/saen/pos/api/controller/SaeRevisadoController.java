package com.truper.saen.pos.api.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.pos.api.dto.RequestRevisadoDto;
import com.truper.saen.pos.api.enums.Mensajes;
import com.truper.saen.pos.api.response.vo.ResponseVO;
import com.truper.saen.pos.api.service.ISaeRevisadosService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/pos-revisados")
@Api("Servicio para la administracion de las POs en BD SAE Nacionales")
@CrossOrigin(value = { "*" }, exposedHeaders = { "Content-Disposition" })
public class SaeRevisadoController {

	@Autowired
	private ISaeRevisadosService iSaeService;

	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> generaSae(@RequestBody RequestRevisadoDto dto) {
		log.info("Inicia controller para obtencion de generaSAE {} , {}", dto.getIdSae() != null ? dto.getIdSae() : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.cloneSAE(dto));
			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData).build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}



	@PutMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> actualizaSAE(@RequestBody RequestRevisadoDto dto) {
		log.info("Inicia controller para obtencion de generaSAE {} , {}", dto.getIdSae() != null ? dto.getIdSae() : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.actualizoSAE(dto));
			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData).build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}

	@GetMapping(value = "/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> getSae(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de getSae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.getSae(folio));
			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData).build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> getSaes() {
		log.info("Inicia controller para obtencion de getAllSaes {}", Fechas.getHoraLogeo());
		try {
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.getAllSaes());
			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).data(formData).build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	
	
	@GetMapping(value = "/getSaeByFolio/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> getSaeByFolio(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de resumenSaeBySae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.resumenSaeBySae(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	@GetMapping(value = "/detalleSaeRevisadosBySae/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra detalleSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> detalleSaeRevisadosBySae(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de resumenSaeBySae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("detalleSae", iSaeService.detalleSaeRevisadoBySae(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	} 

}
