package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class DataCatalogDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5103543843585118303L;
	
	List<ProductoTel> productos;
	
}
