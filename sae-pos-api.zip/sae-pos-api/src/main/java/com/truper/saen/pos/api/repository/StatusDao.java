package com.truper.saen.pos.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.CatSaeStatus;

public interface StatusDao extends JpaRepository<CatSaeStatus, Integer>{

}
