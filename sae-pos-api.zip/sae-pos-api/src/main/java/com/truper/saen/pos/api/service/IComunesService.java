package com.truper.saen.pos.api.service;

import java.util.List;

import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.pos.api.dto.CatalogsPrioridad;

public interface IComunesService {

	 Prioridad getPrioridad(CatPrioridades catPrioridades, String tipo, Integer idaMin);
	 
	 Prioridad getPrioridadZMP(CatPrioridades catPrioridades, Integer valor, List<CatalogsPrioridad> prioridades);
}
