package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class DataCatalogsPrioridades implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private List<CatalogsPrioridad> prioridad;
	
}
