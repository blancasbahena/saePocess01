package com.truper.saen.pos.api.dto;

import java.util.Date;

import com.truper.saen.commons.dto.Prioridad;

public interface DetalleSaeDTO {
	
	Long getId();

	Long getIdPO();

	Long getPosSap();

	String getPlanner();

	String getCodigo();
	
	String getDescripcion();
	
	Long getCantidad();
	
	Long getIdaMin();
	
	Long getSs();
	
	Double getBo();

	Long getOs();
	
	String getCentro();
	
	Long getPicoPlan();
	
	Long getPicoReal();
	
	Double getMonto();
	
	Date getFechaPi();
	
	Long getDiferenciaFecha();
	
	Long getUnidades();
	
	Date getEtaSolicitada();
	
	Date getFechaEntrega();
	
	Date getEta();
	
	Boolean getEsNuevo();
	Boolean getEsBorrado();	
	Boolean getEsModificado();
	Double getCantidadModificado();
	Double getPesoModificado();
	Double getVolumenModificado();	 
	void setEsNuevo(Boolean c);	
	void setEsBorrado(Boolean v);		
	void setEsModificado(Boolean c);	
	void setCantidadModificado(Double sd);	
	void setPesoModificado(Double sd);	
	void setVolumenModificado(Double sd);
	String getAccion();	
	void setAccion(String sd);
	
	
	void setId(Long d);

	void setIdPO(Long xc);

	void setPosSap(Long a);

	void setPlanner(String a);

	void setCodigo(String a);
	
	void setDescripcion(String s);
	
	void setCantidad(Long sa);
	
	void setIdaMin(Long sa);
	
	void setSs(Long sa);
	
	void setBo(Double a);

	void setOs(Long s);
	
	void setCentro(String d);
	
	void setPicoPlan(Long d);
	
	void setPicoReal(Long s);
	
	void setMonto(Double s);
	
	void setFechaPi(Date s);
	
	void setDiferenciaFecha(Long d);
	
	void setUnidades(Long d) ;
	
	void setEtaSolicitada(Date x);
	
	void setFechaEntrega(Date fe);
	
	void setEta(Date c);
	
	String getTipo();
	
	void setPrioridad(Prioridad prioridad);
	
	String getPrioridadDetalle();
	
	Long getPeso();
	
	Double getVolumen();
	
	Integer getDiasConsumoDisponible();
	
}
