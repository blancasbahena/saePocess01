package com.truper.saen.pos.api.service;

import java.util.List;

import com.truper.saen.pos.api.dto.AddPosDTO;
import com.truper.saen.pos.api.dto.DeletePosDTO;
import com.truper.saen.pos.api.dto.DetalleSaeRevDTO;
import com.truper.saen.pos.api.dto.ResponseDetalleDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;
import com.truper.saen.pos.api.dto.ResumenSaeDTO;
import com.truper.saen.pos.api.dto.SaeDetalleDTO;
import com.truper.saen.pos.api.dto.UpdatePosDTO;
import com.truper.saen.pos.api.dto.UpdatePrioridadDTO;

public interface ISaeService {
	
	RespuestaDTO addPosToSae(AddPosDTO info);
	
	RespuestaDTO updatePosFromSae(UpdatePosDTO info);
	
	RespuestaDTO deletePosFromSae(DeletePosDTO info);
	
	List<ResumenSaeDTO>resumenSaeBySae(Long folio);
	  
	List<SaeDetalleDTO> detalleSaeBySae(Long folio);
	
	List<DetalleSaeRevDTO> detalleSaeBySaeRev(Long folio);

	RespuestaDTO actualizarPrioridadDetalleSae(UpdatePrioridadDTO info);

	List<SaeDetalleDTO> detalleSaeBySaeLib(Long folio);
	
}
