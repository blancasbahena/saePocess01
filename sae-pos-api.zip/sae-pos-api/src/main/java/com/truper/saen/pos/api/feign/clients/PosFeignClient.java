package com.truper.saen.pos.api.feign.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.truper.saen.pos.api.dto.PosDTO;
import com.truper.saen.pos.api.dto.ResponseTokenDTO;
import com.truper.saen.pos.api.dto.ResponseWsPosApiDTO;
import com.truper.saen.pos.api.dto.User;

@FeignClient(name = "wsPosAPi", url = "${pos-cp.host}")
public interface PosFeignClient {
	
	String AUTH_TOKEN = "Authorization";

	@PostMapping("${pos-cp.path-token}")
	ResponseTokenDTO getToken(@RequestBody User user);
	
	@PostMapping("${pos-cp.path-data}")
	ResponseWsPosApiDTO getDataFromWsPosApi(@RequestBody PosDTO posDTO, @RequestHeader(AUTH_TOKEN) String bearerToken);

	/*@GetMapping(value = "${sart.pedidos.reporte.reintento.informacion.path}")
	@Headers("Content-Type: application/json")
	SartReporteReintento getInformacionReporte(@RequestParam("placas") String placas,
			@RequestParam("fechaInicio") String fechaInicio,
			@RequestParam("fechaFin") String fechaFin,
			@RequestHeader(AUTH_TOKEN) String bearerToken);*/

}
