package com.truper.saen.pos.api.feign.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.truper.saen.commons.dto.ListProductosDto;
import com.truper.saen.pos.api.dto.ResponseCatalogApi;
import com.truper.saen.pos.api.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.pos.api.dto.ResponseTokenCatalogDTO;
import com.truper.saen.pos.api.dto.User;

@FeignClient(name = "wsCatalogApi", url = "${feing.catalog.host}")
public interface CatalogClient {
	
	String AUTH_TOKEN = "Authorization";

	@PostMapping("${feing.catalog.path-token}")
	ResponseTokenCatalogDTO getToken(@RequestBody User user);
	
	@PostMapping("${feing.catalog.listProducts}")
	ResponseCatalogApi getListaProductos(@RequestBody ListProductosDto productos, @RequestHeader(AUTH_TOKEN) String bearerToken);
	
	@GetMapping(value = "${feing.catalog.path-prioridad}")
	ResponseCatalogsPrioridadDTO getPrioridadByTipo(@PathVariable String tipo,
			@RequestHeader(value = "Authorization", required = true) String bearerToken);

}
