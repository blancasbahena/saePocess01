package com.truper.saen.pos.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.pos.api.dto.DetalleSaeDTO;
import com.truper.saen.pos.api.dto.DetalleSaeRevDTO;
import com.truper.saen.pos.api.dto.ResumenSaeDTO;
import com.truper.saen.pos.api.dto.SaeDetalleDTO;

@Repository
public interface SaeRepository extends JpaRepository<Sae, Long> {

	List<Sae> findByStatusLessThanEqualAndIdProveedor(CatSaeStatus status, Integer idProveedor);
	
	List<Sae> findByIdProveedor(Integer idProveedor);

	@Query(value = "SELECT s.folio , s.idProveedor , "
			+ "DATEDIFF(day, s.created ,GETDATE())  diasTranscurridos, s.ETASolicitada eta , "
			+ "s.BO bo , s.OS os , s.totalCodigos, s.idTipoUnidad , s.Unidades unidades, s.Monto monto "
			+ "FROM SAE s where  s.folio=:folio ", nativeQuery = true)
	List<ResumenSaeDTO> resumenSaeBySae(@Param("folio") Long folio);
	 
	@Query(value = "SELECT ROW_NUMBER() OVER(ORDER BY s.folio  DESC) id, sd.idPO ,sd.idPosicion  posSap, sd.planner,sd.codigo, \r\n" + 
			"	sd.descripcion ,sd.cantidad ,COALESCE (sd.IDAMin,0) idaMin, \r\n" + 
			"	sd.SS  ss, sd.BO  bo , sd.OS  os , sd.centro , sd.picoPlan , \r\n" + 
			"	sd.picoReal , sd.monto, sd.fechaPI fechaPi, \r\n" + 
			"	DATEDIFF(day, sd.fechaPI  ,s.ETASolicitada)  diferenciaFecha,s.Unidades unidades, \r\n" + 
			" s.ETASolicitada etaSolicitada, sd.fechaEntrega, s.tipo, sd.prioridadDetalle,\r\n" +
			" sd.diasConsumoDisponible, " + 
			" sd.peso, sd.volumen from Sae  s, SaeDetalle sd \r\n" + 
			"	where s.folio = sd.idSae and  s.folio=:folio", nativeQuery = true)
	List<DetalleSaeDTO> detalleSaeBySae(@Param("folio") Long folio);
	
	@Query(value = "SELECT ROW_NUMBER() OVER(ORDER BY s.folio  DESC) id, sd.idPO ,sd.idPosicion  posSap, sd.planner,sd.codigo, \r\n" + 
			"	sd.descripcion ,sd.cantidad ,COALESCE (sd.IDAMin,0) idaMin, \r\n" + 
			"	sd.SS  ss, sd.BO  bo , sd.OS  os , sd.centro , sd.picoPlan , \r\n" + 
			"	sd.picoReal , sd.monto, sd.fechaPI fechaPi, \r\n" + 
			"	DATEDIFF(day, sd.fechaPI  ,s.ETASolicitada)  diferenciaFecha,s.Unidades unidades, \r\n" + 
			" s.ETASolicitada etaSolicitada, sd.fechaEntrega, s.tipo, sd.prioridadDetalle,\r\n" + 
			" sd.peso, sd.volumen from Sae  s, SaeDetalleLiberados sd \r\n" + 
			"	where s.folio = sd.idSae and  s.folio=:folio", nativeQuery = true)
	List<DetalleSaeDTO> detalleSaeBySaeLib(@Param("folio") Long folio);
	
}
