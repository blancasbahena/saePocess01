package com.truper.saen.pos.api.controller;
import io.swagger.annotations.Authorization;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.pos.api.configuration.JWUtil;
import com.truper.saen.pos.api.dto.PosDTO;
import com.truper.saen.pos.api.dto.ResponseImportacionesDetalleOrdenDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;
import com.truper.saen.pos.api.enums.Mensajes;
import com.truper.saen.pos.api.response.vo.ResponseVO;
import com.truper.saen.pos.api.service.IPosService;
import com.truper.saen.pos.api.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/pos")
@Api("Servicio para obtener las POs de WS POS API")
@CrossOrigin(value = { "*" }, exposedHeaders = { "Content-Disposition" })
public class PosController {
	
	@Autowired
	private IPosService iPosService;

	@PostMapping
	@ApiOperation(value = "Servicio para obtener las POs del WS POS API", notes = "Obtiene las POs del servicio WS POS API")
	public ResponseEntity<ResponseVO> getDataWsPosApi(@Valid @RequestBody PosDTO posDTO, Errors error)  {

		log.info("[POST /getDataWsPosApi] | INICIO -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());
		
		String folio = UUID.randomUUID().toString();
		
		try {
			
			if(error.hasErrors()) {
				throw new Exception(error.toString());
			}

			Set<ResponseImportacionesDetalleOrdenDTO> response = iPosService.getDataWsPosApi(posDTO);

			Map<String, Object> formData = new HashMap<>();
			formData.put("pos", response);

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folio).data(formData)
					.build());

		} catch (Exception e) {
			log.error("Error en el servicio getDataWsPosApi {} a las {} con parametros {} y folio {}",
					e.getMessage(), UtilDates.getHora(), posDTO.toString(), folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage())
					.folio(folio).build(), HttpStatus.BAD_REQUEST);

		} finally {
			log.info("[POST /getDataWsPosApi] | FIN -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());
		}

	}
	@GetMapping
	@ApiOperation(value = "Servicio que muestra informacion de un SAE, parametros {id}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<com.truper.saen.commons.dto.ResponseVO> getDetailsSAE(@RequestParam(required = true) Long id) {
		log.info("Inicia controller para obtencion de SaeController {} , {}", id != null ? id : "-",
				Fechas.getHoraLogeo());
		try {
			return new ResponseEntity<>(iPosService.getDetalles(id), HttpStatus.OK);
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/idSae/{idSae}")
	public ResponseEntity<RespuestaDTO> getPosByIdSae(@RequestHeader("Authorization") String token, @PathVariable(required = true) Long idSae){
		log.info("[POST /pos/idSae/{}] | INICIO -  {}",idSae,JWUtil.extractUsername(token.substring(7)));
		RespuestaDTO respuesta = iPosService.getPOsByIdSae(idSae);
		log.info("[POST /pos/idSae/{}]] | FIN",idSae);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
	@GetMapping(value = "/revisados/idSae/{idSae}")
	public ResponseEntity<RespuestaDTO> getPosRevisadosByIdSae(@RequestHeader("Authorization") String token, @PathVariable(required = true) Long idSae){
		log.info("[POST /pos/revisados/idSae/{}] | INICIO -  {}",idSae,JWUtil.extractUsername(token.substring(7)));
		RespuestaDTO respuesta = iPosService.getPosRevisadosByIdSae(idSae);
		log.info("[POST /pos/revisados/idSae/{}]] | FIN",idSae);
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
}
