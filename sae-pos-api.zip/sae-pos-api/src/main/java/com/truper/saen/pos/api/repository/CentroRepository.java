package com.truper.saen.pos.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.CatCentro;


@Repository
public interface CentroRepository extends JpaRepository<CatCentro, String>{

	
}