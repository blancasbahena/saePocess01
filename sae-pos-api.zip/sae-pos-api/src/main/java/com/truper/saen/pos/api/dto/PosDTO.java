package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class PosDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotBlank(message = "La propiedad claveProveedor es obligatoria y no puede venir vacia")
	private String claveProveedor;

	private Date fechaInicio;

	private Date fechaFin;

	private String esLiberada;

	private String ordenCerrada;
	
	private String tipoPO;

}
