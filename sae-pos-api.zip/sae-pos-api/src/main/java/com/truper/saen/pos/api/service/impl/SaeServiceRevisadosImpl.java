package com.truper.saen.pos.api.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.dto.SaeRevisadoDto;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Relationships;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.entities.User;
import com.truper.saen.commons.enums.CatStatusSae;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.pos.api.dto.AddPosDetalleDTO;
import com.truper.saen.pos.api.dto.CatalogsPrioridad;
import com.truper.saen.pos.api.dto.DetalleSaeDTO;
import com.truper.saen.pos.api.dto.RequestDetalleDTO;
import com.truper.saen.pos.api.dto.RequestRevisadoDto;
import com.truper.saen.pos.api.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.pos.api.dto.ResponseTokenCatalogDTO;
import com.truper.saen.pos.api.dto.SaeDetalleDTO;
import com.truper.saen.pos.api.feign.clients.CatalogClient;
import com.truper.saen.pos.api.repository.CatPrioridadesRepository;
import com.truper.saen.pos.api.repository.SaeDetalleRepository;
import com.truper.saen.pos.api.repository.SaeDetalleRevisadoRepository;
import com.truper.saen.pos.api.repository.SaeRepository;
import com.truper.saen.pos.api.repository.SaeRevisadosRepository;
import com.truper.saen.pos.api.repository.StatusDao;
import com.truper.saen.pos.api.repository.UserDao;
import com.truper.saen.pos.api.service.IComunesService;
import com.truper.saen.pos.api.service.ISaeRevisadosService;
import com.truper.saen.pos.api.util.UtilDates;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
@RequiredArgsConstructor
public class SaeServiceRevisadosImpl implements ISaeRevisadosService {

	private final ModelMapper mapper;
	private final SaeRevisadosRepository saeRepository; 
	private final CatPrioridadesRepository catPrioridadesRepository;
	private final SaeDetalleRevisadoRepository saeDetalleRepository;
	private final SaeRepository saeRepositoryRead;
	private final SaeDetalleRepository   saeDetalleRepositoryRead;
	private final UserDao userDao;
	private final StatusDao statusDao;
	
	@Autowired
	private IComunesService iComunesService; 
	
	@Value("${feing.catalog.user}")
	private String catUsername;

	@Value("${feing.catalog.pass}")
	private String catPassword;
	
	@Autowired
	private CatalogClient catalogsFeignClient;
 
	public void add(RequestRevisadoDto info) {
		log.info("[Service-Revisados /add] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		SaeRevisado sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (sae != null) {
			Set<SaeDetalleRevisado> posDetalle = new HashSet<>();
			for (AddPosDetalleDTO detallePO : info.getNuevos()) {
				SaeDetalleId detalleId = 
						SaeDetalleId.builder()
						.idSae(info.getIdSae())
						.idPO(detallePO.getNumeroOrden().trim())
						.idPosicion(detallePO.getPosicion().trim()).build();

				SaeDetalleRevisado detalle = mapper.map(detallePO,SaeDetalleRevisado.class);
						new SaeDetalleRevisado();
				detalle.setPlanner(detallePO.getPlaneador());
				detalle.setIdDetalle(detalleId);
				detalle.setEsModificado(false);
				detalle.setEsBorrado(false);
				detalle.setEsNuevo(true);
				detalle.setCreated(new Date());
				detalle.setUserCreated(obtieneUsuario(info.getUser()));
				posDetalle.add(detalle);
				
			}
			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");

			if (!posDetalle.isEmpty()) {
				saeDetalleRepository.saveAll(posDetalle);
				fin = new Date();
				log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			} 
		}   
	}
	public void update(RequestRevisadoDto info) { 
		log.info("[Service-Revisados /update] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		SaeRevisado sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if (sae != null) {
			for (RequestDetalleDTO detallePO : info.getModificados()) {
				salvaDetalle( getSaeDetalleRevisadoDto(
						info.getIdSae(),detallePO.getIdPO(), detallePO.getPos()), detallePO,
						true,false,false,info.getUser());
			}
			for (RequestDetalleDTO detallePO : info.getEliminados()) { 
				salvaDetalle( getSaeDetalleRevisadoDto(
						info.getIdSae(),detallePO.getIdPO(), detallePO.getPos()), detallePO,
						false,true,false,info.getUser());
			}
		} 
	}
	private SaeDetalleRevisado salvaDetalle(SaeDetalleRevisado detalle,RequestDetalleDTO detallePO,
			boolean modificado,boolean borrado,boolean nuevo,String user) {
		if (detalle!=null) {
			detalle.setCantidad(detallePO.getCantidad());
			detalle.setPeso(detallePO.getPeso());
			detalle.setVolumen(detallePO.getVolumen());
			detalle.setCantidadModificado(detallePO.getCantidadModificado());
			detalle.setPesoModificado(detallePO.getPesoModificado());
			detalle.setVolumenModificado(detallePO.getVolumenModificado());
			detalle.setEsModificado(modificado);
			detalle.setEsBorrado(borrado);
			detalle.setEsNuevo(nuevo);
			detalle.setCreated(new Date());
			detalle.setUserCreated(obtieneUsuario(user));
			detalle=saeDetalleRepository.save(detalle);
			return detalle;
		}
		return null;
	}
	private User obtieneUsuario(String username) {
		if(username!=null) {
			Optional<User> user = userDao.findByUserName(username);
			if(user.isPresent()) {
				return user.get();
			}
		}
		return null;
	}

	private SaeRevisadoDto mapeo(SaeRevisado entity) {
		SaeRevisadoDto dto= mapper.map(entity,SaeRevisadoDto.class);
		dto.setUserCreated(Relationships.directSelfReferenceUserWithoutPassword(dto.getUserCreated()));
		return dto;
	} 
	private SaeDetalleRevisado getSaeDetalleRevisadoDto(Long idSae,String idPo,String idPosicion) { 
		Optional<SaeDetalleRevisado> detalleRevisado = saeDetalleRepository.findById(
				SaeDetalleId.builder().idSae(idSae).idPO(idPo).idPosicion(idPosicion).build());
		if(detalleRevisado.isPresent()) {
			return detalleRevisado.get();
		}
		return null;
	} 
	@Override
	public SaeRevisadoDto cloneSAE(RequestRevisadoDto dtoReq) {
		log.info("[Service-Revisados /cloneSAE] | INICIO -  {} - HORA - {} ", dtoReq.getIdSae(), UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - cloneSAE] | SAE ");
		Optional<Sae> sae = saeRepositoryRead.findById(dtoReq.getIdSae());
		SaeRevisadoDto dto= null;
		if(sae.isPresent() && dtoReq.getIdSae()!=null) {
			SaeRevisado nuevoEntity= new SaeRevisado();
			nuevoEntity.setFolio(dtoReq.getIdSae());
			nuevoEntity.setEta(dtoReq.getEta());
			nuevoEntity.setEtaSolicitada(sae.get().getEtaSolicitada());
			nuevoEntity.setUnidades(dtoReq.getUnidades());
			nuevoEntity.setTipoDeUnidad(sae.get().getTipoDeUnidad());
			nuevoEntity.setCreated(new Date());
			nuevoEntity.setUserCreated(obtieneUsuario(dtoReq.getUser()));
			nuevoEntity.setTipo(sae.get().getTipo());
			nuevoEntity.setIdProveedor(sae.get().getIdProveedor());
			nuevoEntity.setCentro(sae.get().getCentro());
			
			nuevoEntity =saeRepository.save(nuevoEntity);
			
			Optional<CatSaeStatus> estatus =statusDao.findById(dtoReq.getIdEstatus());
			if(estatus.isPresent()) {
				if(!sae.get().getSaeDetalles().isEmpty()) {
					sae.get().getSaeDetalles().forEach(det-> saeDetalleRepository.save(mapper(det)));
				}
				update(dtoReq);
				add(dtoReq);
				Optional<SaeRevisado> saeRevisado = saeRepository.findById(dtoReq.getIdSae());
				sae.get().setStatus(estatus.get());
				//sae.get().setUnidades(dtoReq.getUnidades());
				Short revisado = sae.get().getConteoRevisado();
				if( ( revisado == null || revisado == 0 )  &&  (dtoReq.getIdEstatus() == CatStatusSae.SAE_ENVIADO_A_REVISION.getId() || dtoReq.getIdEstatus() == CatStatusSae.SAE_ENVIADO_A_REVISION17.getId() ||dtoReq.getIdEstatus()==CatStatusSae.SAE_REVISADO_PENDIENTE_APROBACION_G.getId() ) ) {
					sae.get().setConteoRevisado((short) 1);
				}else if(revisado > 0 && dtoReq.getIdEstatus() == CatStatusSae.SAE_ENVIADO_A_REVISION.getId()  )  {
					sae.get().setConteoRevisado((short) (revisado + 1));
				}
				
				sae.get().setUserModified(obtieneUsuario(dtoReq.getUser()));

				saeRepositoryRead.save(sae.get());
				if(saeRevisado.isPresent()) {
					dto= mapeo(saeRevisado.get());
				}
			}
		}
		Date fin = new Date();
		log.info("[FIN - cloneSAE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return dto;
	}

	private SaeDetalleRevisado mapper(SaeDetalle det) {
		SaeDetalleRevisado saeDetalleDB= new SaeDetalleRevisado();
		saeDetalleDB.setIdDetalle(det.getIdDetalle());
		saeDetalleDB.setCondicionPago(det.getCondicionPago());
		saeDetalleDB.setNumOrdenSecundaria(det.getNumOrdenSecundaria());
		saeDetalleDB.setCantidadUnidadMedida(det.getCantidadUnidadMedida());
		saeDetalleDB.setFactorCantidadUnidadMedida(det.getCantidadUnidadMedida());
		saeDetalleDB.setDescripcionComplementoFactura(det.getDescripcionComplementoFactura());
		saeDetalleDB.setOrigen(det.getOrigen());
		saeDetalleDB.setTipo(det.getTipo());
		saeDetalleDB.setCodigo(det.getCodigo());
		saeDetalleDB.setDescripcion(det.getDescripcion());
		saeDetalleDB.setPlaneadorProducto(det.getPlaneadorProducto());
		saeDetalleDB.setFamilia(det.getFamilia());
		saeDetalleDB.setPlanner(det.getPlanner());
		saeDetalleDB.setCantidad(det.getCantidad());
		saeDetalleDB.setCentro(det.getCentro());
		saeDetalleDB.setPicoPlan(det.getPicoPlan());
		saeDetalleDB.setPicoReal(det.getPicoReal());
		saeDetalleDB.setMonto(det.getMonto());
		saeDetalleDB.setFechaPI(det.getFechaPI());
		saeDetalleDB.setDifPIEvsETA(det.getDifPIEvsETA());
		saeDetalleDB.setMaterial(det.getMaterial());
		saeDetalleDB.setPeso(det.getPeso());
		saeDetalleDB.setVolumen(det.getVolumen());
		saeDetalleDB.setBo(det.getBo());
		saeDetalleDB.setOs(det.getOs());
		saeDetalleDB.setSs(det.getSs());
		saeDetalleDB.setIdaMin(det.getIdaMin());
		saeDetalleDB.setFechaEntrega(det.getFechaEntrega());
		return saeDetalleDB;
	}
	@Override
	public SaeRevisadoDto actualizoSAE(RequestRevisadoDto dtoReq) {
		log.info("[Service-Revisados /cloneSAE] | INICIO -  {} - HORA - {} ", dtoReq.getIdSae(), UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - cloneSAE] | SAE ");
		Optional<Sae> sae = saeRepositoryRead.findById(dtoReq.getIdSae());
		SaeRevisadoDto dto= null;
		if(sae.isPresent() && dtoReq.getIdSae()!=null) {
			SaeRevisado nuevoEntity= new SaeRevisado();
			nuevoEntity.setFolio(dtoReq.getIdSae());
			nuevoEntity.setEta(dtoReq.getEta());
			nuevoEntity.setEtaSolicitada(sae.get().getEtaSolicitada());
			nuevoEntity.setUnidades(dtoReq.getUnidades());
			nuevoEntity.setTipoDeUnidad(sae.get().getTipoDeUnidad());
			nuevoEntity.setCreated(new Date());
			nuevoEntity.setUserCreated(obtieneUsuario(dtoReq.getUser()));
			nuevoEntity.setTipo(sae.get().getTipo());
			nuevoEntity.setIdProveedor(sae.get().getIdProveedor());
			nuevoEntity.setCentro(sae.get().getCentro());
			nuevoEntity =saeRepository.save(nuevoEntity);
			update(dtoReq);
			add(dtoReq);
			Optional<SaeRevisado> saeRevisado = saeRepository.findById(dtoReq.getIdSae());
			if(saeRevisado.isPresent()) {
				dto= mapeo(saeRevisado.get());
			}
		}
		Date fin = new Date();
		log.info("[FIN - cloneSAE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return dto;
	}
	@Override
	public SaeRevisadoDto getSae(Long folio) {
		SaeRevisadoDto dto = null;
		log.info("[Service-Revisados /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		Optional<SaeRevisado> optional =  saeRepository.findById(folio);
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if(optional.isPresent()) {
			dto =  mapeo(optional.get());
		}
		return dto;
	} 
	@Override
	public List<SaeRevisadoDto> getAllSaes() { 
		List<SaeRevisadoDto> listaDto= new ArrayList<SaeRevisadoDto>();
		log.info("[Service-Revisados /getSaes] | INICIO   - HORA - {} ",   UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - getSaes] | SAE ");
		List<SaeRevisado> lista =  saeRepository.findAll();
		Date fin = new Date();
		log.info("[FIN - getSaes] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if(!lista.isEmpty()) {
			listaDto = lista.stream().map(m->mapeo(m)).collect(Collectors.toList());
		}
		return listaDto;
	}
	
	@Override
	public SaeRevisadoDto resumenSaeBySae(Long folio) {
		SaeRevisadoDto dto = null;
		log.info("[Service-Revisados /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		Optional<SaeRevisado> optional =  saeRepository.findById(folio);
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if(optional.isPresent()) {
			dto =  mapeo(optional.get());
		}
		return dto;
	}

	
	@Override
	public List<SaeRevisadoDto> resumenSaeBySaes() { 
		List<SaeRevisadoDto> listaDto= new ArrayList<SaeRevisadoDto>();
		log.info("[Service-Revisados /getSaes] | INICIO   - HORA - {} ",   UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - getSaes] | SAE ");
		List<SaeRevisado> lista =  saeRepository.findAll();
		Date fin = new Date();
		log.info("[FIN - getSaes] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		if(!lista.isEmpty()) {
			listaDto = lista.stream().map(m->mapeo(m)).collect(Collectors.toList());
		}
		return listaDto;
	}



	/**
	 * Obtener de datalles por sae revisado mas propridad
	 */
	
	@Override
	public List<SaeDetalleDTO> detalleSaeRevisadoBySae(Long folio) {
		log.info("[Service /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		List<DetalleSaeDTO> detalleSae = saeRepository.detalleSaeBySae(folio);
		List<SaeDetalleDTO> dataDetalle = new ArrayList<SaeDetalleDTO>();
		
		List<CatalogsPrioridad> prioridades = getPrioridades();
		
		for (DetalleSaeDTO detalleSaeDTO : detalleSae) {
			Integer idPrioridad = detalleSaeDTO.getPrioridadDetalle()!=null?
					Integer.parseInt(detalleSaeDTO.getPrioridadDetalle()):null;
			CatPrioridades catPrioridad=null;
			if (idPrioridad!=null) {
				catPrioridad = catPrioridadesRepository.findById(idPrioridad).get();
			}
			
			Prioridad prioridad = new Prioridad();
			String tipo = "";
			if (detalleSaeDTO.getTipo().equals("ZCOM")) {
				tipo = "N";
				prioridad = iComunesService.getPrioridad(catPrioridad, tipo, detalleSaeDTO.getIdaMin().intValue());
			} else {
				tipo = "M";
				prioridad =iComunesService.getPrioridadZMP(catPrioridad, detalleSaeDTO.getDiasConsumoDisponible(), prioridades);
			}
			
			
			SaeDetalleDTO detalle = new SaeDetalleDTO(detalleSaeDTO,prioridad);
			dataDetalle.add(detalle);
			
		}
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return dataDetalle;
	}

	private List<CatalogsPrioridad> getPrioridades() {
		List<CatalogsPrioridad> prioridades = new ArrayList<>();
		
		com.truper.saen.pos.api.dto.User user = new com.truper.saen.pos.api.dto.User();
		user.setUsername(catUsername);
		user.setPassword(catPassword);
		ResponseTokenCatalogDTO token = catalogsFeignClient.getToken(user);
		if (token != null) {
		
			ResponseCatalogsPrioridadDTO response = catalogsFeignClient.getPrioridadByTipo("M","Bearer " + token.getData().getToken() );
			
			if(  response != null) {
				prioridades = response.getData().getPrioridad();
			}
			
		}
		
		return prioridades;
	}
	
}
