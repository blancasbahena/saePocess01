package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ImportacionesDetalleOrdenDTO implements Serializable, Comparable<ImportacionesDetalleOrdenDTO> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String condicionPago;
	private String numeroOrden;
	private String posicion;
	private String item;
	private Double poTotalQuantity;
	private String planeador;
	private String centro;
	private String numOrdenSecundaria;
	private Double cantidadUnidadMedida;
	private Double factorCantidadUnidadMedida;
	private String itemDescription;
	private String origen;
	private String tipo;
	private String codigo;
	private String descripcion;
	private String planeadorProducto;
	private String familia;
	private Integer masterCart;
	private Double volumenCart;
	private Double volumenMaster;
	private Double pesoCart;
	private Double pesoMaster;
	private String shippingDate;
	private Double volumenCalculado;
	private Double pesoCalculado;
	private String unidadMedidaProducto;
	private String fechaProforma;

	public ImportacionesDetalleOrdenDTO() {

	}

	public ImportacionesDetalleOrdenDTO(String condicionPago, String numeroOrden, String posicion, String item,
			Double poTotalQuantity, String planeador, String centro, String numOrdenSecundaria,
			Double cantidadUnidadMedida, Double factorCantidadUnidadMedida, String itemDescription, String origen,
			String tipo, String codigo, String descripcion, String planeadorProducto, String familia) {
		super();
		this.condicionPago = condicionPago;
		this.numeroOrden = numeroOrden;
		this.posicion = posicion;
		this.item = item;
		this.poTotalQuantity = poTotalQuantity;
		this.planeador = planeador;
		this.centro = centro;
		this.numOrdenSecundaria = numOrdenSecundaria;
		this.cantidadUnidadMedida = cantidadUnidadMedida;
		this.factorCantidadUnidadMedida = factorCantidadUnidadMedida;
		this.itemDescription = itemDescription;
		this.origen = origen;
		this.tipo = tipo;
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.planeadorProducto = planeadorProducto;
		this.familia = familia;
	}


	@Override
	public int compareTo(ImportacionesDetalleOrdenDTO b) {
		if (Integer.parseInt(posicion) > Integer.parseInt(b.posicion)) {
			return 1;
		} else if (Integer.parseInt(posicion) < Integer.parseInt(b.posicion)) {
			return -1;
		} else {
			return 0;
		}
	}

}
