package com.truper.saen.pos.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;

@Repository
public interface SaeDetalleRevisadoRepository extends JpaRepository<SaeDetalleRevisado, SaeDetalleId>{
	
}
