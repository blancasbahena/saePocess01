package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RequestDetalleDTO  implements Serializable{
	private static final long serialVersionUID = -6664426433773800876L;
	private String  idPO;
	private String  pos;
	private String  descripcion;
	private Double  cantidad;
	private Double  peso;
	private Double  volumen;
	private boolean esModificado;
	private boolean esBorrado;
	private boolean esNuevo;
	
	private Double  cantidadModificado;
	private Double  pesoModificado;
	private Double  volumenModificado;
}
