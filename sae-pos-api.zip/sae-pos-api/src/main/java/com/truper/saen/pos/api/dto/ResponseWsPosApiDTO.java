package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ResponseWsPosApiDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String mensaje;
	private String tipoMensaje;
	private String folio;
	private String descripcionError;
	private DataDTO data;

}
