package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RequestRevisadoDto implements Serializable{ 
	private static final long serialVersionUID = 8666587796563175428L;
	private Long idSae;
	private String user;
	private Date eta;
	private Date etaSolicitada;
	private Integer unidades;
	private Integer idEstatus;
	List<AddPosDetalleDTO> nuevos;
	List<RequestDetalleDTO> modificados;
	List<RequestDetalleDTO> sinCambios;
	List<RequestDetalleDTO> eliminados;
}
