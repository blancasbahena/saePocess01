package com.truper.saen.pos.api.dto;

import java.io.Serializable;
import java.util.TreeSet;

import lombok.Data;

@Data
public class ResponseImportacionesDetalleOrdenDTO implements Serializable, Comparable<ResponseImportacionesDetalleOrdenDTO> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String idPo;
	
	private TreeSet<ImportacionesDetalleOrdenDTO> poDetalleDto;
	
	@Override
	public int compareTo(ResponseImportacionesDetalleOrdenDTO b) {
		if (Integer.parseInt(idPo) > Integer.parseInt(b.idPo)) {
			return 1;
		} else if (Integer.parseInt(idPo) < Integer.parseInt(b.idPo)) {
			return -1;
		} else {
			return 0;
		}
	}


}
