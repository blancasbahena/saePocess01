package com.truper.saen.pos.api.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ResponseTokenDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String token;
}
