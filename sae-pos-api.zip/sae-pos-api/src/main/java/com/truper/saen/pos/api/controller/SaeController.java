package com.truper.saen.pos.api.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.truper.saen.commons.utils.Fechas;
import com.truper.saen.pos.api.configuration.JWUtil;
import com.truper.saen.pos.api.dto.AddPosDTO;
import com.truper.saen.pos.api.dto.DeletePosDTO;
import com.truper.saen.pos.api.dto.DeletePosDetalleDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;
import com.truper.saen.pos.api.dto.UpdatePosDTO;
import com.truper.saen.pos.api.dto.UpdatePrioridadDTO;
import com.truper.saen.pos.api.enums.Mensajes;
import com.truper.saen.pos.api.response.vo.ResponseVO;
import com.truper.saen.pos.api.service.ISaeService;
import com.truper.saen.pos.api.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/pos")
@Api("Servicio para la administracion de las POs en BD SAE Nacionales")
@CrossOrigin(value = { "*" }, exposedHeaders = { "Content-Disposition" })
public class SaeController {

	@Autowired
	private ISaeService iSaeService;

	@PostMapping(value = "/addPOs/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> addPosToSae(@RequestHeader("Authorization") String token,
			@PathVariable Long idSae, @Valid @RequestBody AddPosDTO info, Errors error) {

		log.info("[POST /addPosToSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		String folio = UUID.randomUUID().toString();

		try {

			if (error.hasErrors()) {
				throw new Exception(error.toString());
			}

			RespuestaDTO respuesta = iSaeService.addPosToSae(info);
			log.info("[POST /addPosToSae] | FIN -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
			return new ResponseEntity<>(respuesta, respuesta.getEstado());

		} catch (Exception e) {
			log.error("Error en el servicio addPosToSae {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), info.toString(), folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage()).folio(folio).build(),
					HttpStatus.BAD_REQUEST);

		}

	}

	@PutMapping(value = "/updatePOs/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> updatePosFromSae(@RequestHeader("Authorization") String token,
			@PathVariable Long idSae, @Valid @RequestBody UpdatePosDTO info, Errors error) {

		log.info("[PUT /updatePosFromSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		String folio = UUID.randomUUID().toString();

		try {

			if (error.hasErrors()) {
				throw new Exception(error.toString());
			}

			RespuestaDTO respuesta = iSaeService.updatePosFromSae(info);
			log.info("[PUT /updatePosFromSae] | FIN -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
			return new ResponseEntity<>(respuesta, respuesta.getEstado());

		} catch (Exception e) {
			log.error("Error en el servicio updatePosFromSae {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), info.toString(), folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage()).folio(folio).build(),
					HttpStatus.BAD_REQUEST);

		}

	}

	@DeleteMapping(value = "/deletePOs/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> deletePosFromSae(@RequestHeader("Authorization") String token,
			@PathVariable Long idSae, @Valid @RequestBody DeletePosDTO info, Errors error) {

		log.info("[DELETE /deletePosFromSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		String folio = UUID.randomUUID().toString();

		try {

			if (error.hasErrors()) {
				throw new Exception(error.toString());
			}

			RespuestaDTO respuesta = iSaeService.deletePosFromSae(info);
			log.info("[DELETE /deletePosFromSae] | FIN -  {} - HORA - {} ", info.toString(), UtilDates.getHora());

			return new ResponseEntity<>(respuesta, respuesta.getEstado());

		} catch (Exception e) {
			log.error("Error en el servicio deletePosFromSae {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), info.toString(), folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage()).folio(folio).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	@DeleteMapping(value = "/deletePO", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra informacion de un SAE, parametros {id}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<com.truper.saen.commons.dto.ResponseVO> deletePosFromSae(@RequestParam(required = true)  Long idSae,@RequestParam(required = true)  Long idPo,@RequestParam(required = true)  Long idPosicion) {
		List<DeletePosDetalleDTO> ListDtoDetail =  new ArrayList<DeletePosDetalleDTO>();
		DeletePosDetalleDTO dtoDetail = new DeletePosDetalleDTO(idPo.toString(),idPosicion.toString());
		ListDtoDetail.add(dtoDetail);
		DeletePosDTO info = new DeletePosDTO(idSae,"",ListDtoDetail);
		log.info("[DELETE /deletePosFromSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());
		String folio = UUID.randomUUID().toString();
		String mensjae="Problemas con delete de PO";
		Map<String, Object> formData = new HashMap<>();
		try {


			RespuestaDTO respuesta = iSaeService.deletePosFromSae(info);
			if(respuesta.getTipoMensaje().equals("S")) {
				formData.put("response",true);
				return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder()
							.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
							.mensaje(Mensajes.MSG_EXITO.getMensaje())
							.data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.OK);
			}

		} catch (Exception e) {
			log.error("Error en el servicio deletePosFromSae {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), info.toString(), folio);
			mensjae=e.getMessage();

		}
		formData.put("response",false);
		return new ResponseEntity<>(
				com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
						.mensaje(mensjae).data(formData)
						.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
				HttpStatus.BAD_REQUEST);
	}
	
	
	@GetMapping(value = "/resumenSaeBySae/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra resumenSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> resumenSaeBySae(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de resumenSaeBySae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("sae", iSaeService.resumenSaeBySae(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	
	
	@GetMapping(value = "/detalleSaeBySae/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra detalleSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> detalleSaeBySae(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de resumenSaeBySae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("detalleSae", iSaeService.detalleSaeBySae(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	@GetMapping(value = "/detalleSaeBySaeRev/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra detalleSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> detalleSaeBySaeRev(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de detalleSaeBySaeRev {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("detalleSae", iSaeService.detalleSaeBySaeRev(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			log.error(e.getMessage());
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	
	@GetMapping(value = "/detalleSaeBySaeLiberados/{folio}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio que muestra detalleSaeBySae de un SAE, parametros {folio}", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<?> detalleSaeBySaeLiberados(@PathVariable("folio") Long folio) {
		log.info("Inicia controller para obtencion de resumenSaeBySae {} , {}", folio != null ? folio : "-",
				Fechas.getHoraLogeo());
		try {
			String folioR = UUID.randomUUID().toString();
			Map<String, Object> formData = new HashMap<>();
			formData.put("detalleSae", iSaeService.detalleSaeBySaeLib(folio));

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folioR).data(formData)
					.build());
		} catch (Exception e) {
			Map<String, Object> formData = new HashMap<>();
			formData.put("msg", e.getMessage());
			return new ResponseEntity<>(
					com.truper.saen.commons.dto.ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
							.mensaje(Mensajes.MSG_ERROR.getMensaje()).data(formData)
							.folio(com.truper.saen.commons.dto.ResponseVO.getFolioActual()).build(),
					HttpStatus.BAD_REQUEST);

		}
	}
	
	@PutMapping( value = "/actualizarPrioridadDetalleSae", produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseVO> actualizarPrioridadDetalleSae(@RequestHeader("Authorization") String token, @RequestBody  UpdatePrioridadDTO info){
		log.info("[PUT /actualizarPrioridadDetalleSae/{}] | INICIO -  {} - { {} }", info.getIdSae(), info, JWUtil.extractUsername(token.substring(7)));
		RespuestaDTO respuesta = iSaeService.actualizarPrioridadDetalleSae(info);
		log.info("[PUT /actualizarPrioridadDetalleSae/{}] | FIN", info.getIdSae());
		return new ResponseEntity<>(respuesta,respuesta.getEstado());
	}
	
}
