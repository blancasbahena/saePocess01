package com.truper.saen.pos.api.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.SaeDetalleIdDTO;
import com.truper.saen.commons.entities.CatCentro;
import com.truper.saen.commons.entities.CatPrioridades;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleId;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.pos.api.dto.AddPosDTO;
import com.truper.saen.pos.api.dto.AddPosDetalleDTO;
import com.truper.saen.pos.api.dto.CatalogsPrioridad;
import com.truper.saen.pos.api.dto.DeletePosDTO;
import com.truper.saen.pos.api.dto.DeletePosDetalleDTO;
import com.truper.saen.pos.api.dto.DetalleSaeDTO;
import com.truper.saen.pos.api.dto.DetalleSaeRevDTO;
import com.truper.saen.pos.api.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.pos.api.dto.ResponseTokenCatalogDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;
import com.truper.saen.pos.api.dto.ResumenSaeDTO;
import com.truper.saen.pos.api.dto.SaeDetalleDTO;
import com.truper.saen.pos.api.dto.UpdatePosDTO;
import com.truper.saen.pos.api.dto.UpdatePosDetalleDTO;
import com.truper.saen.pos.api.dto.UpdatePrioridadDTO;
import com.truper.saen.pos.api.dto.User;
import com.truper.saen.pos.api.feign.clients.CatalogClient;
import com.truper.saen.pos.api.repository.CatPrioridadesRepository;
import com.truper.saen.pos.api.repository.CentroRepository;
import com.truper.saen.pos.api.repository.SaeDetalleRepository;
import com.truper.saen.pos.api.repository.SaeRepository;
import com.truper.saen.pos.api.repository.SaeRevisadosRepository;
import com.truper.saen.pos.api.service.IComunesService;
import com.truper.saen.pos.api.service.ISaeService;
import com.truper.saen.pos.api.util.UtilDates;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class SaeServiceImpl implements ISaeService {

	private final  ModelMapper mapper;
	private final SaeRepository saeRepository;
	private final CentroRepository centroRepository;
	private final SaeDetalleRepository saeDetalleRepository;
	private final CatPrioridadesRepository catPrioridadesRepository;
	private final SaeRevisadosRepository saeRevisado;
	private List<SaeDetalleRevisado> listaRevisados=null;
	@Autowired
	private IComunesService iComunesService; 
	
	@Value("${feing.catalog.user}")
	private String catUsername;

	@Value("${feing.catalog.pass}")
	private String catPassword;
	
	@Autowired
	private CatalogClient catalogsFeignClient;
	
	@Override
	public RespuestaDTO addPosToSae(AddPosDTO info) {

		log.info("[Service /addPosToSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());

		RespuestaDTO resp = new RespuestaDTO();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			Set<SaeDetalle> posDetalle = new HashSet<>();

			Set<SaeDetalleId> posDetalleAgregados = new HashSet<>();
			Set<SaeDetalleId> posDetalleNoAgregados = new HashSet<>();
			Map<String, Object> posDetalleResponse = new HashMap<>();

			for (AddPosDetalleDTO detallePO : info.getListPoDetalle()) {

				String tipoTemporal = "";
				
				
				if (sae.getCentros()==null) {
					CatCentro centro = centroRepository.findById(detallePO.getCentro()).orElse(null);
					if (centro!=null) {
						sae.setCentros(centro);	
						saeRepository.save(sae);
					}
				}

				if (sae.getTipo() == null || sae.getTipo().equals("")) {
					if (detallePO.getTipo().equals("ZCOM")) {
						sae.setTipo("N");
						tipoTemporal = "N";
					} else {
						sae.setTipo("M");
						tipoTemporal = "M";
					}
					
					
					saeRepository.save(sae);
				} else {
					if (detallePO.getTipo().equals("ZCOM")) {
						tipoTemporal = "N";
					} else {
						tipoTemporal = "M";
					}
				}
			

				Optional<SaeDetalle> deta = saeDetalleRepository
						.findById(SaeDetalleId.builder().idPO(detallePO.getNumeroOrden().trim())
								.idPosicion(detallePO.getPosicion().trim()).idSae(info.getIdSae()).build());

				if (tipoTemporal.equals(sae.getTipo()) && !deta.isPresent()) {

					SaeDetalle detalle = new SaeDetalle();
					SaeDetalleId detalleId = new SaeDetalleId();
					detalleId.setIdSae(info.getIdSae());
					detalleId.setIdPosicion(detallePO.getPosicion().trim());
					detalleId.setIdPO(detallePO.getNumeroOrden().trim());

					detalle.setIdDetalle(detalleId);
					detalle.setCondicionPago(detallePO.getCondicionPago());
					detalle.setMaterial(detallePO.getItem().trim());
					detalle.setCantidad(detallePO.getPoTotalQuantity());
					detalle.setPeso(detallePO.getPeso());
					detalle.setVolumen(detallePO.getVolumen());
					detalle.setPlanner(detallePO.getPlaneador());
					detalle.setCentro(detallePO.getCentro());
					detalle.setNumOrdenSecundaria(detallePO.getNumOrdenSecundaria());
					detalle.setCantidadUnidadMedida(detallePO.getCantidadUnidadMedida());
					detalle.setFactorCantidadUnidadMedida(detallePO.getFactorCantidadUnidadMedida());
					detalle.setDescripcionComplementoFactura(detallePO.getItemDescription());
					detalle.setOrigen(detallePO.getOrigen());
					detalle.setTipo(detallePO.getTipo());
					detalle.setCodigo(detallePO.getCodigo());
					detalle.setDescripcion(detallePO.getDescripcion());
					detalle.setPlaneadorProducto(detallePO.getPlaneadorProducto());
					detalle.setFamilia(detallePO.getFamilia());
					detalle.setMonto(detallePO.getMonto());
					detalle.setFechaEntrega(detallePO.getFechaEntrega());
					detalle.setUnidadMedidaProducto(detallePO.getUnidadMedidaProducto());
					detalle.setFechaPI(detallePO.getFechaPI());
					posDetalleAgregados.add(detalleId);
					posDetalle.add(detalle);

				} else {
					SaeDetalleId detalleId = new SaeDetalleId();
					detalleId.setIdSae(info.getIdSae());
					detalleId.setIdPosicion(detallePO.getPosicion().trim());
					detalleId.setIdPO(detallePO.getNumeroOrden().trim());
					posDetalleNoAgregados.add(detalleId);
				}

			}

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");

			if (!posDetalle.isEmpty()) {
				saeDetalleRepository.saveAll(posDetalle);
				fin = new Date();
				log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			}

			posDetalleResponse.put("added", posDetalleAgregados);
			posDetalleResponse.put("not-added", posDetalleNoAgregados);

			resp = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					null, "pos", posDetalleResponse);
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;

	}

	@Override
	public RespuestaDTO updatePosFromSae(UpdatePosDTO info) {

		log.info("[Service /updatePosFromSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());

		RespuestaDTO resp = new RespuestaDTO();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			List<SaeDetalle> listDetalle = new ArrayList<SaeDetalle>();
			List<SaeDetalleIdDTO> listDetalleActualizados = new ArrayList<SaeDetalleIdDTO>();
			List<SaeDetalleIdDTO> listDetalleNoActualizados = new ArrayList<SaeDetalleIdDTO>();
			Map<String, Object> detalleResponse = new HashMap<String, Object>();

			for (UpdatePosDetalleDTO detallePO : info.getListPoDetalle()) {
				SaeDetalleId saeKey = SaeDetalleId.builder().idPO(detallePO.getNumeroOrden().trim())
						.idPosicion(detallePO.getPosicion().trim()).idSae(info.getIdSae()).build();
				Optional<SaeDetalle> opt = saeDetalleRepository.findById(saeKey);
				if (opt.isPresent()) {
					opt.get().setCantidad(detallePO.getCantidad());
					opt.get().setPeso(detallePO.getPeso());
					opt.get().setVolumen(detallePO.getVolumen());
					listDetalle.add(opt.get());
					listDetalleActualizados.add(mapper.map(saeKey, SaeDetalleIdDTO.class));

				} else {
					listDetalleNoActualizados.add(mapper.map(saeKey, SaeDetalleIdDTO.class));

				}
			}

			if (!listDetalle.isEmpty()) {
				saeDetalleRepository.saveAll(listDetalle);
			}

			detalleResponse.put("updated", listDetalleActualizados);
			detalleResponse.put("not-updated", listDetalleNoActualizados);

			resp = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					null, "pos", detalleResponse);
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}

		return resp;
	}

	@Override
	public RespuestaDTO deletePosFromSae(DeletePosDTO info) {

		log.info("[Service /deletePosFromSae] | INICIO -  {} - HORA - {} ", info.toString(), UtilDates.getHora());

		RespuestaDTO resp = new RespuestaDTO();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - SELECT] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

		if (sae != null) {

			SaeDetalleId saeDetalleId = null;
			for (DeletePosDetalleDTO detallePO : info.getListPoDetalle()) {
				saeDetalleId = new SaeDetalleId();
				saeDetalleId.setIdSae(info.getIdSae());
				saeDetalleId.setIdPO(detallePO.getNumeroOrden().trim());
				saeDetalleId.setIdPosicion(detallePO.getPosicion().trim());
			}

			inicio = new Date();
			log.info("[INICIO - UPDATE] | SAE ");

			Optional<SaeDetalle> saeDetalle = saeDetalleRepository.findById(saeDetalleId);

			if (saeDetalle.isPresent()) {
				saeDetalleRepository.deleteById(saeDetalleId);
			} else {
				resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
				resp.setMensaje("Información de PO no encontrada");
				resp.setEstado(HttpStatus.NOT_FOUND);

				return resp;
			}

			fin = new Date();
			log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

			resp = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(),
					null, "status", "PO Eliminada de SAE");
			resp.setEstado(HttpStatus.OK);

		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;

	}

	@Override
	public List<ResumenSaeDTO> resumenSaeBySae(Long folio) {
		log.info("[Service /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		List<ResumenSaeDTO> sae = saeRepository.resumenSaeBySae(folio);
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return sae;
	}
	
	@Override
	public List<SaeDetalleDTO> detalleSaeBySaeLib(Long folio) {
		log.info("[Service /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		List<DetalleSaeDTO> detalleSae = saeRepository.detalleSaeBySaeLib(folio);
		List<SaeDetalleDTO> dataDetalle = new ArrayList<SaeDetalleDTO>();
		
		for (DetalleSaeDTO detalleSaeDTO : detalleSae) {
			Integer idPrioridad = detalleSaeDTO.getPrioridadDetalle()!=null?
					Integer.parseInt(detalleSaeDTO.getPrioridadDetalle()):null;
			CatPrioridades catPrioridad=null;
			if (idPrioridad!=null) {
				catPrioridad = catPrioridadesRepository.findById(idPrioridad).get();
			}
			
			Prioridad prioridad =iComunesService.getPrioridad(catPrioridad, detalleSaeDTO.getTipo(), detalleSaeDTO.getIdaMin().intValue());
			SaeDetalleDTO detalle = new SaeDetalleDTO(detalleSaeDTO,prioridad);
			dataDetalle.add(detalle);
			
		}
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return dataDetalle;
	} 
	
	@Override
	public List<SaeDetalleDTO> detalleSaeBySae(Long folio) {
		log.info("[Service /resumenSaeBySae] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		List<DetalleSaeDTO> detalleSae = saeRepository.detalleSaeBySae(folio);
		List<SaeDetalleDTO> dataDetalle = new ArrayList<SaeDetalleDTO>();
		
		List<CatalogsPrioridad> prioridades = getPrioridades();
		
		for (DetalleSaeDTO detalleSaeDTO : detalleSae) {
			Integer idPrioridad = detalleSaeDTO.getPrioridadDetalle()!=null?
					Integer.parseInt(detalleSaeDTO.getPrioridadDetalle()):null;
			CatPrioridades catPrioridad=null;
			if (idPrioridad!=null) {
				catPrioridad = catPrioridadesRepository.findById(idPrioridad).get();
			}
			Prioridad prioridad = new Prioridad();
			String tipoDetalle = detalleSaeDTO.getTipo() == null ? "" : detalleSaeDTO.getTipo();
			
			if( "M".equals(tipoDetalle) ) {
				prioridad =iComunesService.getPrioridadZMP(catPrioridad, detalleSaeDTO.getDiasConsumoDisponible(), prioridades);
			}else {
				 prioridad =iComunesService.getPrioridad(catPrioridad, detalleSaeDTO.getTipo(), detalleSaeDTO.getIdaMin().intValue());
			}
			
			SaeDetalleDTO detalle = new SaeDetalleDTO(detalleSaeDTO,prioridad);
			dataDetalle.add(detalle);
			
		}
		Date fin = new Date();
		log.info("[FIN - resumenSaeBySae] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return dataDetalle;
	} 

	@Override
	public List<DetalleSaeRevDTO> detalleSaeBySaeRev(Long folio) {
		listaRevisados=new ArrayList<SaeDetalleRevisado>();
		log.info("[Service /detalleSaeBySaeRev] | INICIO -  {} - HORA - {} ", folio, UtilDates.getHora());
		Date inicio = new Date();
		log.info("[INICIO - resumenSaeBySae] | SAE ");
		List<DetalleSaeDTO> detalleSaeBD = saeRepository.detalleSaeBySae(folio);
		Date fin = new Date();
		log.info("[FIN - detalleSaeBySaeRev] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		
		List<CatalogsPrioridad> prioridades = getPrioridades();
		
		List<DetalleSaeRevDTO> detalleSae = 
				detalleSaeBD.stream().map(det-> clonarARevisado(det,prioridades)).collect(Collectors.toList());
		Optional<SaeRevisado> optional= saeRevisado.findById(folio);
		
		if(optional.isPresent())
			if(!optional.get().getSaeDetalles().isEmpty())
				listaRevisados =optional.get().getSaeDetalles();
		if(!detalleSae.isEmpty()) {
			List<DetalleSaeRevDTO> detalleSaeNuevo =detalleSae.stream().map(det->{
				if(optional.isPresent()) {
					SaeDetalleRevisado saeDetalleRevisado =existeDetalleEnRevisado (listaRevisados,det); 
					if(saeDetalleRevisado!=null) {
						log.info("Detalle encontrado : "+
								saeDetalleRevisado.getIdDetalle().getIdSae()+"-"+
								saeDetalleRevisado.getIdDetalle().getIdPO()+"-"+
								saeDetalleRevisado.getIdDetalle().getIdPosicion());
						det.setEsModificado(saeDetalleRevisado.getEsModificado());
						det.setEsBorrado(saeDetalleRevisado.getEsBorrado());
						det.setEsNuevo(false);
						det.setCantidadModificado(saeDetalleRevisado.getCantidadModificado());
						det.setVolumenModificado(saeDetalleRevisado.getVolumenModificado());
						det.setPesoModificado(saeDetalleRevisado.getPesoModificado());
						saeDetalleRevisado.setEsModificado(saeDetalleRevisado.getEsModificado()!=null?saeDetalleRevisado.getEsModificado():false);
						saeDetalleRevisado.setEsBorrado(saeDetalleRevisado.getEsBorrado()!=null?saeDetalleRevisado.getEsBorrado():false);
						saeDetalleRevisado.setEsNuevo(saeDetalleRevisado.getEsNuevo()!=null?saeDetalleRevisado.getEsNuevo():false);
						det.setAccion(saeDetalleRevisado.getEsModificado()?"accion.modificado":
									(saeDetalleRevisado.getEsBorrado()?"accion.borrado":"accion.sinAccion"));
						listaRevisados.remove(saeDetalleRevisado);
						log.info("Detalle Removido de Revisados : "+
								saeDetalleRevisado.getIdDetalle().getIdSae()+"-"+
								saeDetalleRevisado.getIdDetalle().getIdPO()+"-"+
								saeDetalleRevisado.getIdDetalle().getIdPosicion());
					}
				}else {
					//No existe en Sae Revisado
					det.setEsModificado(false);
					det.setEsBorrado(false);
					det.setEsNuevo(false);
					det.setAccion("accion.sinAccion");
				}
				return det;
			}).collect(Collectors.toList());
			log.info("Detalles  de Revisados size : "+listaRevisados.size());
			if(!listaRevisados.isEmpty()) {
				listaRevisados.stream().forEach(detREvisado->{
					log.info("Detalle a clona de Revisados a DTO :"+
							detREvisado.getIdDetalle().getIdSae()+"-"+
							detREvisado.getIdDetalle().getIdPO()+"-"+
							detREvisado.getIdDetalle().getIdPosicion());
				detalleSaeNuevo.add(clonado(detREvisado));});
			}
			return detalleSaeNuevo;
		}	
		
		return detalleSae;
	}

	private DetalleSaeRevDTO clonarARevisado(DetalleSaeDTO det, List<CatalogsPrioridad> prioridades) {
		return DetalleSaeRevDTO.builder()
				.id(det.getId())
				.idPO(det.getIdPO())
				.posSap(det.getPosSap())
				.planner(det.getPlanner())
				.codigo(det.getCodigo())
				.descripcion(det.getDescripcion())
				.cantidad(det.getCantidad())
				.idaMin(det.getIdaMin())
				.ss(det.getSs())
				.bo(det.getBo())
				.os(det.getOs())
				.centro(det.getCentro())
				.picoPlan(det.getPicoPlan())
				.picoReal(det.getPicoReal())
				.monto(det.getMonto())
				.fechaPi(det.getFechaPi())		
				.diferenciaFecha(det.getDiferenciaFecha())
				.unidades(det.getUnidades())
				.etaSolicitada(det.getEtaSolicitada())
				.eta(det.getEta())
				.esNuevo(false)
				.esBorrado(false)	
				.esModificado(false)
				.cantidadModificado(det.getCantidadModificado())
				.pesoModificado(det.getPesoModificado())
				.volumenModificado(det.getVolumenModificado())
				.accion("accion.sinAccion")
				.prioridad(obtenerPrioridad(det,prioridades))
				.build();
	}
 
	private Prioridad obtenerPrioridad(DetalleSaeDTO det,List<CatalogsPrioridad> prioridades) {
		Integer idPrioridad = det.getPrioridadDetalle() != null ? Integer.parseInt(det.getPrioridadDetalle()) : null;
		CatPrioridades catPrioridad = null;
		if (idPrioridad != null) {
			catPrioridad = catPrioridadesRepository.findById(idPrioridad).get();
		}

		if ("M".equals(det.getTipo())) {
			return iComunesService.getPrioridadZMP(catPrioridad, det.getDiasConsumoDisponible(), prioridades);
		}
		
		return iComunesService.getPrioridad(catPrioridad, det.getTipo(), det.getIdaMin().intValue());

	}

	private DetalleSaeRevDTO clonado(SaeDetalleRevisado detRevisado) { 
		int dias = 0;
		if(detRevisado.getFechaPI()!=null && detRevisado.getFechaEntrega()!=null) {
			dias=(int) ((detRevisado.getFechaPI().getTime() - detRevisado.getFechaEntrega().getTime()));
		}
		return DetalleSaeRevDTO.builder()
		.id(detRevisado.getIdDetalle().getIdSae())
		.idPO(new Long(detRevisado.getIdDetalle().getIdPO()))
		.posSap(new Long(detRevisado.getIdDetalle().getIdPosicion()))
		.planner(detRevisado.getPlanner())
		.codigo(detRevisado.getCodigo())
		.descripcion(detRevisado.getDescripcion())
		.cantidad(detRevisado.getCantidad()!=null?detRevisado.getCantidad().longValue():0l)
		.idaMin(detRevisado.getIdaMin()!=null?detRevisado.getIdaMin().longValue():0l)
		.ss(detRevisado.getSs()!=null?detRevisado.getSs().longValue():0l)
		.bo(detRevisado.getBo())
		.os(detRevisado.getOs()!=null?detRevisado.getOs().longValue():0l)
		.centro(detRevisado.getCentro())
		.picoPlan(detRevisado.getPicoPlan()!=null?detRevisado.getPicoPlan().longValue():0l)
		.picoReal(detRevisado.getPicoReal()!=null?detRevisado.getPicoReal().longValue():0l)
		.monto(detRevisado.getMonto())
		.fechaPi(detRevisado.getFechaPI())		
		.diferenciaFecha(new Long(dias))
		.unidades(detRevisado.getCantidadUnidadMedida()!=null?detRevisado.getCantidadUnidadMedida().longValue():0l)
		.etaSolicitada(detRevisado.getFechaEntrega())
		.eta(detRevisado.getFechaEntrega())
		.esNuevo(true)
		.esBorrado(false)	
		.esModificado(false)
		.cantidadModificado(detRevisado.getCantidadModificado())
		.pesoModificado(detRevisado.getPesoModificado())
		.volumenModificado(detRevisado.getVolumenModificado())
		.accion("accion.nuevo")
		.build();
	}

	private SaeDetalleRevisado existeDetalleEnRevisado(List<SaeDetalleRevisado> lista, DetalleSaeRevDTO det) {
		if(!lista.isEmpty()) {
			Optional<SaeDetalleRevisado> optionalRevisado =
			lista.stream()
				.filter(d->
					d.getIdDetalle().getIdPO().equals(det.getIdPO().toString()) &&
					d.getIdDetalle().getIdPosicion().equals(det.getPosSap().toString())).findAny();
			if(optionalRevisado.isPresent()) {
				return optionalRevisado.get();
			}
		}
		return null;
	}


	@Override
	public RespuestaDTO actualizarPrioridadDetalleSae(UpdatePrioridadDTO info) {
		
		RespuestaDTO resp = new RespuestaDTO();
		Date inicio = new Date();
		log.info("[INICIO - SELECT] | SAE ");
		Sae sae = saeRepository.findById(info.getIdSae()).orElse(null);
		Date fin = new Date();
		log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		
		if (sae != null) {
			
			SaeDetalleId saeKey = SaeDetalleId.builder().idPO(info.getNumeroOrden().trim())
					.idPosicion(info.getPosicion().trim()).idSae(info.getIdSae()).build();
			
			Optional<SaeDetalle> opt = saeDetalleRepository.findById(saeKey);
			
			if (opt.isPresent()) {
				
				Optional<CatPrioridades> catPrioridad = catPrioridadesRepository.findById(info.getIdPrioridad());
				
				if (catPrioridad.isPresent()) {
					opt.get().setPrioridades(catPrioridad.get());
				}

				inicio = new Date();
				log.info("[INICIO - UPDATE] | SAE ");
				saeDetalleRepository.save(opt.get());
				fin = new Date();
				log.info("[FIN - UPDATE] | SAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));

				resp = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "sae",
						sae.getFolio());
				resp.setEstado(HttpStatus.OK);
				
			} else {
				resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
				resp.setMensaje("Información de PO no encontrada");
				resp.setEstado(HttpStatus.NOT_FOUND);
			}
			
		} else {

			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje("Información de SAE no encontrada");
			resp.setEstado(HttpStatus.NOT_FOUND);

		}
		return resp;
		
	}
	
	
	private List<CatalogsPrioridad> getPrioridades() {
		List<CatalogsPrioridad> prioridades = new ArrayList<>();
		
		User user = new User();
		user.setUsername(catUsername);
		user.setPassword(catPassword);
		ResponseTokenCatalogDTO token = catalogsFeignClient.getToken(user);
		if (token != null) {
		
			ResponseCatalogsPrioridadDTO response = catalogsFeignClient.getPrioridadByTipo("M","Bearer " + token.getData().getToken() );
			
			if(  response != null) {
				prioridades = response.getData().getPrioridad();
			}
			
		}
		
		return prioridades;
	}
}

































