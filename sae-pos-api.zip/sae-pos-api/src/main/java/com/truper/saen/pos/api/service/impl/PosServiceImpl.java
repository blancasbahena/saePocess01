package com.truper.saen.pos.api.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.ListProductosDto;
import com.truper.saen.commons.dto.ModificadoDTO;
import com.truper.saen.commons.dto.PoDetalleDto;
import com.truper.saen.commons.dto.Prioridad;
import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.commons.dto.SaeDetalleIdDTO;
import com.truper.saen.commons.dto.SaeDetalleRevisadoDto;
import com.truper.saen.commons.dto.SaeDto;
import com.truper.saen.commons.dto.SaeRevisadoDto;
import com.truper.saen.commons.entities.CatSaeStatus;
import com.truper.saen.commons.entities.Sae;
import com.truper.saen.commons.entities.SaeDetalle;
import com.truper.saen.commons.entities.SaeDetalleRevisado;
import com.truper.saen.commons.entities.SaeRevisado;
import com.truper.saen.commons.enums.Mensajes;
import com.truper.saen.commons.utils.Utils;
import com.truper.saen.pos.api.dto.CatalogsPrioridad;
import com.truper.saen.pos.api.dto.DataCatalogDto;
import com.truper.saen.pos.api.dto.ImportacionesDetalleOrdenDTO;
import com.truper.saen.pos.api.dto.PosDTO;
import com.truper.saen.pos.api.dto.ProductoTel;
import com.truper.saen.pos.api.dto.ResponseCatalogApi;
import com.truper.saen.pos.api.dto.ResponseCatalogsPrioridadDTO;
import com.truper.saen.pos.api.dto.ResponseImportacionesDetalleOrdenDTO;
import com.truper.saen.pos.api.dto.ResponseTokenCatalogDTO;
import com.truper.saen.pos.api.dto.ResponseTokenDTO;
import com.truper.saen.pos.api.dto.ResponseWsPosApiDTO;
import com.truper.saen.pos.api.dto.RespuestaDTO;
import com.truper.saen.pos.api.dto.SumatoriasDTO;
import com.truper.saen.pos.api.dto.User;
import com.truper.saen.pos.api.feign.clients.CatalogClient;
import com.truper.saen.pos.api.feign.clients.PosFeignClient;
import com.truper.saen.pos.api.repository.SaeRepository;
import com.truper.saen.pos.api.repository.SaeRevisadosRepository;
import com.truper.saen.pos.api.service.IComunesService;
import com.truper.saen.pos.api.service.IPosService;
import com.truper.saen.pos.api.service.ISaeRevisadosService;
import com.truper.saen.pos.api.util.UtilDates;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PosServiceImpl implements IPosService {

	@Autowired
	private ISaeRevisadosService serviceREvisados;
	@Autowired
	private PosFeignClient posFeignClient;

	@Autowired
	private CatalogClient catalogFeing;

	@Value("${pos-cp.user}")
	private String usuario;

	@Value("${pos-cp.password}")
	private String password;

	@Value("${query-parameters.id-status-number}")
	private Integer queryIdStatus;

	@Value("${query-parameters.tipo-conf}")
	private String tipoConf;

	@Value("${query-parameters.es-liberada}")
	private String esLiberada;

	@Value("${query-parameters.orden-cerrada}")
	private String ordenCerrada;

	@Value("${feing.catalog.user}")
	private String usuarioCatalog;

	@Value("${feing.catalog.pass}")
	private String passwordCatalog;

	@Autowired
	private SaeRepository saeRepository;

	@Autowired
	private SaeRevisadosRepository saeRevisadosRepository;

	private ResponseWsPosApiDTO dataPos = null;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private EntityManager em;
	
	@Autowired
	private IComunesService iComunesService; 

	@Override
	public Set<ResponseImportacionesDetalleOrdenDTO> getDataWsPosApi(PosDTO posDTO) throws Exception {

		log.info("[Service /getDataWsPosApi] | INICIO -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());

		User user = new User();
		user.setUsername(usuario);
		user.setPassword(password);

		List<SaeDetalle> listaGeneralDetalles = new ArrayList<SaeDetalle>();
		List<SaeDetalleRevisado> listaGeneralDetallesRevisados = new ArrayList<SaeDetalleRevisado>();
		List<ImportacionesDetalleOrdenDTO> listaPosRegresar = new ArrayList<ImportacionesDetalleOrdenDTO>();

		posDTO = llenarObjetoToWsPos(posDTO);

		try {

			ResponseTokenDTO token = posFeignClient.getToken(user);

			if (token.getToken() != null && !token.getToken().equals("")) {
				dataPos = posFeignClient.getDataFromWsPosApi(posDTO, "Bearer " + token.getToken());

				CatSaeStatus status = new CatSaeStatus();
				status.setIdSaeStatus(queryIdStatus);

				List<Sae> respuestaSae = saeRepository.findByIdProveedor(Integer.parseInt(posDTO.getClaveProveedor()));
				for (Sae obj2 : respuestaSae) {
					List<SaeDetalle> sae = obj2.getSaeDetalles();
					listaGeneralDetalles.addAll(sae);
				}

				List<SaeRevisado> respuestaRevisados = saeRevisadosRepository
						.findByIdProveedor(Integer.parseInt(posDTO.getClaveProveedor()));
				for (SaeRevisado obj3 : respuestaRevisados) {
					List<SaeDetalleRevisado> sae = obj3.getSaeDetalles();
					listaGeneralDetallesRevisados.addAll(sae);
				}

				listaPosRegresar = dataPos.getData().getPos().stream()
						.filter(pos -> notExist(pos, listaGeneralDetalles)).collect(Collectors.toList());

				listaPosRegresar = listaPosRegresar.stream()
						.filter(pos -> notExistRevisados(pos, listaGeneralDetallesRevisados))
						.collect(Collectors.toList());

				if (posDTO.getTipoPO() != null) {

					final String tipo = posDTO.getTipoPO();

					listaPosRegresar = listaPosRegresar.stream().filter(po -> po.getTipo().equals(tipo))
							.collect(Collectors.toList());
				}

			} else {
				log.error("Error al consultar el token del servicio WS-POS-API");
			}

		} catch (Exception e) {
			throw new Exception(e);
		}

		return agruparPorPo(listaPosRegresar);
	}

	private PosDTO llenarObjetoToWsPos(PosDTO posDTO) {
		posDTO.setEsLiberada(esLiberada);
		posDTO.setFechaFin(obtenerFechaCreacion(+1));
		posDTO.setFechaInicio(obtenerFechaCreacion(-1));
		posDTO.setOrdenCerrada(ordenCerrada);
		return posDTO;
	}

	private Date obtenerFechaCreacion(int digito) {

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, digito);

		String pattern = "yyyyMMdd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		Date date = calendar.getTime();
		String fecha = simpleDateFormat.format(date);
		try {
			date = simpleDateFormat.parse(fecha);
		} catch (ParseException e) {
			log.error("Error al formatear el parametro fecha para la consulta al WS-POS", e.getMessage());
		}

		return date;
	}

	private boolean notExist(ImportacionesDetalleOrdenDTO poTel, List<SaeDetalle> posSAE) {

		return !posSAE.stream().filter(m -> m.getIdDetalle().getIdPosicion().equals(poTel.getPosicion())
				&& m.getIdDetalle().getIdPO().equals(poTel.getNumeroOrden())).findFirst().isPresent();
	}

	private boolean notExistRevisados(ImportacionesDetalleOrdenDTO poTel, List<SaeDetalleRevisado> posSAERevisado) {

		return !posSAERevisado.stream().filter(m -> m.getIdDetalle().getIdPosicion().equals(poTel.getPosicion())
				&& m.getIdDetalle().getIdPO().equals(poTel.getNumeroOrden())).findFirst().isPresent();
	}

	private Set<ResponseImportacionesDetalleOrdenDTO> agruparPorPo(
			List<ImportacionesDetalleOrdenDTO> listaPosRegresar) {

		SortedSet<ResponseImportacionesDetalleOrdenDTO> setPos = new TreeSet<>();

		List<String> pos = listaPosRegresar.stream().map(po -> po.getNumeroOrden()).distinct()
				.collect(Collectors.toList());

		pos.stream().forEach(orden -> {
			ResponseImportacionesDetalleOrdenDTO responseImportaciones = new ResponseImportacionesDetalleOrdenDTO();
			responseImportaciones.setIdPo(orden);
			responseImportaciones.setPoDetalleDto(listaPosRegresar.stream()
					.filter(det -> det.getNumeroOrden().equals(orden)).collect(Collectors.toCollection(TreeSet::new)));
			setPos.add(responseImportaciones);
		});

		return setPos;
	}

	@Override
	public ResponseVO getDetalles(Long id) {
		log.info("getSAE - {} ", UtilDates.getHora());
		Date inicio = new Date();
		Map<String, Object> formData = new HashMap<>();
		Optional<Sae> optional = saeRepository.findById(id);
		Date fin = new Date();
		if (optional.isPresent()) {
			SaeDto dto = mapper.map(optional.get(), SaeDto.class);
			dto.setUserCreated(null);
			dto.setUserModified(null);
			SumatoriasDTO sumatorias = new SumatoriasDTO(0d, 0d, 0d, 0d);
			dto.getSaeDetalles().stream().forEach(m -> {
				sumatorias.setCantidad((m.getCantidad() != null ? m.getCantidad() : 0) + sumatorias.getCantidad());
				sumatorias.setMonto((m.getMonto() != null ? m.getMonto() : 0) + sumatorias.getMonto());
				sumatorias.setPeso((m.getPeso() != null ? m.getPeso() : 0) + sumatorias.getPeso());
				sumatorias.setVolumen((m.getVolumen() != null ? m.getVolumen() : 0) + sumatorias.getVolumen());
			});
			formData.put("sae", dto);
			formData.put("sumatorias", sumatorias);
			log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
			return ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).data(formData).folio(ResponseVO.getFolioActual()).build();
		}
		log.info("getSAE - {}", Utils.calcTiempoTranscurridoEnSegundos(inicio, fin));
		return ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
				.mensaje(Mensajes.MSG_NODATA.getMensaje()).folio(ResponseVO.getFolioActual()).build();
	}

	@Override
	public RespuestaDTO getPOsByIdSae(Long idSae) {

		RespuestaDTO respuesta = new RespuestaDTO();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SaeDetalle> cqDetalle = cb.createQuery(SaeDetalle.class);
		Root<SaeDetalle> rootDetalle = cqDetalle.from(SaeDetalle.class);

		Predicate predicado = cb.equal(rootDetalle.get("sae").get("folio"), idSae);
		cqDetalle.select(rootDetalle).where(predicado);

		List<SaeDetalle> pos = em.createQuery(cqDetalle).getResultList();

		if (!pos.isEmpty()) {

			List<PoDetalleDto> poDetalles = new ArrayList<>();
			List<String> codigos = new ArrayList<>();
			List<ProductoTel> productos = new ArrayList<>();

			for (SaeDetalle saeDetalle : pos) {
				codigos.add(saeDetalle.getCodigo());
			}

			if (!codigos.isEmpty()) {
				User user = new User();
				user.setUsername(usuarioCatalog);
				user.setPassword(passwordCatalog);
				ResponseTokenCatalogDTO token = catalogFeing.getToken(user);

				if (token.getData() != null && token.getData().getToken() != null
						&& !token.getData().getToken().equals("")) {

					ListProductosDto lista = new ListProductosDto();
					lista.setListaProductos(codigos);

					ResponseCatalogApi response = catalogFeing.getListaProductos(lista,
							"Bearer " + token.getData().getToken());

					DataCatalogDto data = response.getData();
					productos = data.getProductos();

				}
			}

			for (SaeDetalle saeDetalle : pos) {

				PoDetalleDto poDetalle = new PoDetalleDto();

				poDetalle.setCantidad(saeDetalle.getCantidad());
				poDetalle.setPeso(saeDetalle.getPeso());
				poDetalle.setVolumen(saeDetalle.getVolumen());
				poDetalle.setDescripcion(saeDetalle.getDescripcion());
				poDetalle.setCodigo(saeDetalle.getCodigo());

				for (ProductoTel producto : productos) {
					if (saeDetalle.getCodigo().equals(producto.getCodigo())) {

						poDetalle.setMasterCart(producto.getMasterCart());
						poDetalle.setPesoCart(producto.getPesoCart());
						poDetalle.setPesoMaster(producto.getPesoMaster());
						poDetalle.setVolumenCart(producto.getVolumenCart());
						poDetalle.setVolumenMaster(producto.getVolumenMaster());

					}
				}

				poDetalle.setCentro(saeDetalle.getCentro());

				SaeDetalleIdDTO idPO = new SaeDetalleIdDTO();

				idPO.setIdPO(saeDetalle.getIdDetalle().getIdPO());
				idPO.setIdPosicion(saeDetalle.getIdDetalle().getIdPosicion());
				idPO.setIdSae(saeDetalle.getIdDetalle().getIdSae());

				poDetalle.setIdDetalle(idPO);
				poDetalles.add(poDetalle);

			}

			respuesta = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(),
					ResponseMessage.MSG_EXITO.getMensaje(), null, "saeDetalle", poDetalles);
			respuesta.setEstado(HttpStatus.OK);

		} else {

			respuesta.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			respuesta.setMensaje("Información por filtros no encontrada");
			respuesta.setEstado(HttpStatus.NOT_FOUND);
		}

		return respuesta;
	}

	@Override
	public RespuestaDTO getPosRevisadosByIdSae(Long idSae) {

		RespuestaDTO respuesta = new RespuestaDTO();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SaeDetalleRevisado> cqDetalle = cb.createQuery(SaeDetalleRevisado.class);
		Root<SaeDetalleRevisado> rootDetalle = cqDetalle.from(SaeDetalleRevisado.class);

		Predicate predicado = cb.equal(rootDetalle.get("idDetalle").get("idSae"), idSae);
		cqDetalle.select(rootDetalle).where(predicado);

		List<SaeDetalleRevisado> pos = em.createQuery(cqDetalle).getResultList();
		
		List<CatalogsPrioridad> prioridades = new ArrayList<>();
		
		User user = new User();
		user.setUsername(usuarioCatalog);
		user.setPassword(passwordCatalog);
		ResponseTokenCatalogDTO token = catalogFeing.getToken(user);
		
		if (token != null) {
		
			ResponseCatalogsPrioridadDTO response = catalogFeing.getPrioridadByTipo("M","Bearer " + token.getData().getToken() );
			
			if(  response != null) {
				prioridades = response.getData().getPrioridad();
			}
			
		}

		if (!pos.isEmpty()) {

			List<SaeDetalleRevisadoDto> poDetalles = new ArrayList<>();
			List<String> codigos = new ArrayList<>();
			List<ProductoTel> productos = new ArrayList<>();

			for (SaeDetalleRevisado saeDetalle : pos) {
				codigos.add(saeDetalle.getCodigo());
			}

			if (!codigos.isEmpty()) {

				if (token.getData() != null && token.getData().getToken() != null
						&& !token.getData().getToken().equals("")) {

					ListProductosDto lista = new ListProductosDto();
					lista.setListaProductos(codigos);

					ResponseCatalogApi response = catalogFeing.getListaProductos(lista,
							"Bearer " + token.getData().getToken());

					DataCatalogDto data = response.getData();
					productos = data.getProductos();

				}
			}

			for (SaeDetalleRevisado saeDetalle : pos) {

				SaeDetalleRevisadoDto poDetalle = new SaeDetalleRevisadoDto();
				
				SaeDetalleIdDTO idPO = new SaeDetalleIdDTO();
				idPO.setIdPO(saeDetalle.getIdDetalle().getIdPO());
				idPO.setIdPosicion(saeDetalle.getIdDetalle().getIdPosicion());
				idPO.setIdSae(saeDetalle.getIdDetalle().getIdSae());
				poDetalle.setIdDetalle(idPO);
				
				poDetalle.setCondicionPago(saeDetalle.getCondicionPago() == null ? null : saeDetalle.getCondicionPago()  );
				poDetalle.setNumOrdenSecundaria(saeDetalle.getNumOrdenSecundaria() == null ? null : saeDetalle.getNumOrdenSecundaria() );
				poDetalle.setCantidadUnidadMedida(saeDetalle.getCantidadUnidadMedida() == null ? null : saeDetalle.getCantidadUnidadMedida());
				poDetalle.setFactorCantidadUnidadMedida(saeDetalle.getFactorCantidadUnidadMedida() == null ? null : saeDetalle.getFactorCantidadUnidadMedida());
				poDetalle.setDescripcionComplementoFactura(saeDetalle.getDescripcionComplementoFactura() == null ? null : saeDetalle.getDescripcionComplementoFactura());
				poDetalle.setOrigen(saeDetalle.getOrigen() == null ? null : saeDetalle.getOrigen());
				poDetalle.setTipo(saeDetalle.getTipo() == null ? null : saeDetalle.getTipo());
				poDetalle.setCodigo(saeDetalle.getCodigo() == null ? null : saeDetalle.getCodigo());
				poDetalle.setDescripcion(saeDetalle.getDescripcion() == null ? null : saeDetalle.getDescripcion());
				poDetalle.setPlaneadorProducto(saeDetalle.getPlaneadorProducto() == null ? null : saeDetalle.getPlaneadorProducto());
				poDetalle.setFamilia(saeDetalle.getFamilia() == null ?  null : saeDetalle.getFamilia());
				poDetalle.setPlanner(saeDetalle.getPlanner() == null ?  null : saeDetalle.getPlanner());;
				poDetalle.setCantidad(saeDetalle.getCantidad());
				poDetalle.setCentro(saeDetalle.getCentro() == null ?  null : saeDetalle.getCentro());
				poDetalle.setPicoPlan(saeDetalle.getPicoPlan() == null ? null : saeDetalle.getPicoPlan());
				poDetalle.setPicoReal(saeDetalle.getPicoReal() == null ? null : saeDetalle.getPicoReal() );
				poDetalle.setMonto(saeDetalle.getMonto() == null ? null : saeDetalle.getMonto());
				poDetalle.setFechaPI(saeDetalle.getFechaPI() == null ? null : saeDetalle.getFechaPI());
				poDetalle.setDifPIEvsETA(saeDetalle.getDifPIEvsETA() == null ? null : saeDetalle.getDifPIEvsETA());
				poDetalle.setMaterial(saeDetalle.getMaterial() == null ?  null : saeDetalle.getMaterial());
				poDetalle.setPeso(saeDetalle.getPeso());
				poDetalle.setVolumen(saeDetalle.getVolumen());
				poDetalle.setPesoModificado(saeDetalle.getPesoModificado());
				poDetalle.setVolumenModificado(saeDetalle.getVolumenModificado());
				poDetalle.setCantidadModificado(saeDetalle.getCantidadModificado());
				poDetalle.setFechaEntrega(saeDetalle.getFechaEntrega() == null ? null : saeDetalle.getFechaEntrega());
				poDetalle.setIdaMin(saeDetalle.getIdaMin()==null?0:saeDetalle.getIdaMin());
				poDetalle.setDiasConsumoDisponible(saeDetalle.getDiasConsumoDisponible());
				
				Prioridad p = null;
				String tipo = "";
				if (saeDetalle.getTipo().equals("ZCOM")) {
					tipo = "N";
					p = iComunesService.getPrioridad(null, tipo, poDetalle.getIdaMin());
				} else {
					tipo = "M";
					p = iComunesService.getPrioridadZMP(null, poDetalle.getDiasConsumoDisponible(),prioridades);
				}
				
				poDetalle.setPrioridad(p);
				
				if( saeDetalle.getEsBorrado() != null && saeDetalle.getEsBorrado() ) {
					poDetalle.setEsBorrado(saeDetalle.getEsBorrado());
					poDetalle.setAccion("PO Borrada");
				}else if( saeDetalle.getEsModificado() != null && saeDetalle.getEsModificado() ) {
					poDetalle.setAccion("PO Modificada");
					poDetalle.setEsModificado(saeDetalle.getEsModificado());
				}else if(saeDetalle.getEsNuevo() != null && saeDetalle.getEsNuevo()) {
					poDetalle.setAccion("PO Nueva");
					poDetalle.setEsNuevo(saeDetalle.getEsNuevo());
				}else {
					poDetalle.setAccion("Sin Cambios");
				}

				for (ProductoTel producto : productos) {
					if (saeDetalle.getCodigo().equals(producto.getCodigo())) {

						poDetalle.setMasterCart(producto.getMasterCart());
						poDetalle.setPesoCart(producto.getPesoCart());
						poDetalle.setPesoMaster(producto.getPesoMaster());
						poDetalle.setVolumenCart(producto.getVolumenCart());
						poDetalle.setVolumenMaster(producto.getVolumenMaster());

					}
				}

				poDetalles.add(poDetalle);

			}
			
		

			respuesta = new RespuestaDTO(ResponseMessage.TIPO_EXITO.getMensaje(),
					ResponseMessage.MSG_EXITO.getMensaje(), null, "saeDetalle", poDetalles);
			respuesta.setEstado(HttpStatus.OK);

		} else {

			respuesta.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			respuesta.setMensaje("Información por filtros no encontrada");
			respuesta.setEstado(HttpStatus.NOT_FOUND);
		}

		return respuesta;
	}

	private boolean isEqual(SaeDetalle saeDetalle, SaeDetalleRevisadoDto saeDetalleRevisado) {
		if (saeDetalle.getIdDetalle().getIdPO().equals(saeDetalleRevisado.getIdDetalle().getIdPO()) && saeDetalle
				.getIdDetalle().getIdPosicion().equals(saeDetalleRevisado.getIdDetalle().getIdPosicion())) {
			return true;
		}
		return false;
	}
}
