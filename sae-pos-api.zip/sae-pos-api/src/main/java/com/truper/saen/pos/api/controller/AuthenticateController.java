package com.truper.saen.pos.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.pos.api.configuration.JWUtil;
import com.truper.saen.pos.api.configuration.UserDetailsServices;
import com.truper.saen.pos.api.dto.User;
import com.truper.saen.pos.api.enums.Mensajes;
import com.truper.saen.pos.api.response.vo.ResponseTokenVO;

@RestController
public class AuthenticateController {

	@Autowired
	private UserDetailsServices userDetailsServices;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody User authenticationRequest) throws Exception {
		
		try {
			authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
		} catch(Exception e) {
			return ResponseEntity.ok(ResponseTokenVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_TOKEN_ERROR.getMensaje()).token("").build());
		}
		
		final UserDetails userDetails = userDetailsServices.loadUserByUsername(authenticationRequest.getUsername());

		final String token = JWUtil.generaToken(userDetails);

		return ResponseEntity.ok(ResponseTokenVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_TOKEN_EXITO.getMensaje()).token(token).build());
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
}
