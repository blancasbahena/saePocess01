package com.truper.saen.pos.cp;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.truper.saen.pos.cp.service.IPosService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class ValidaOrdenesItemTest {

	@Autowired
	private IPosService iPosService;

	@Test
	public void listarOrdenByItem() {
		log.info("entra listarOrdenByItem");
		try {
			List<Long> response = iPosService.getNumOrdenByItem(new Long("700267"));
			System.out.println("Encomtro: "+response.size());
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
