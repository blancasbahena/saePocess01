package com.truper.saen.pos.cp.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class PosDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotBlank(message = "La propiedad claveProveedor es obligatoria y no puede venir vacia")
	private String claveProveedor;

	@Past
	@NotNull(message = "La propiedad fechaInicio es obligatoria y no puede venir vacia")
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaInicio;

	@NotNull(message = "La propiedad fechaFin es obligatoria y no puede venir vacia")
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "America/Mexico_City")
	private Date fechaFin;

	@NotBlank(message = "La propiedad esLiberada es obligatoria y no puede venir vacia")
	@Pattern(regexp = "^true$|^false$", message = "Valores permitidos: true or false")
	private String esLiberada;

	@NotBlank(message = "La propiedad ordenCerrada es obligatoria y no puede venir vacia")
	@Pattern(regexp = "^true$|^false$", message = "Valores permitidos: true or false")
	private String ordenCerrada;

}
