package com.truper.saen.pos.cp.entities;

//import org.springframework.data.annotation.Id;

import lombok.Data;

@Data
public class ImportacionesNotificaciones {
	
	//@Id
	private Integer id;
	
	private String numeroOrden;
	private String posicion;
	
}
