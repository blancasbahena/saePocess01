package com.truper.saen.pos.cp.configuration;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServices implements UserDetailsService {

	@Value("${access.user}")
	private String user;

	@Value("${access.password}")
	private String password;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		password = "$2a$10$eJQ76QqNuNqvXg4t5PhxVuzq4sFgkt8tzVvydy3XZTCI4YxK71ZTW";

		if (username.equals(user)) {
			return new User(username, password, true, true, true, true, new ArrayList<>());
		}
		throw new UsernameNotFoundException("User not found with username: " + username);

	}

}
