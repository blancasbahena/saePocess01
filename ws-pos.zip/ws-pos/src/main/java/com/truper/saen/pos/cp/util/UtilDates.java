package com.truper.saen.pos.cp.util;

import java.util.Calendar;

/**
 * Clase de Utilerias
 * 
 */
public class UtilDates {
	
	public static String getHora() {
		Calendar calendario = Calendar.getInstance();
		String hour = String.format("%02d",calendario.get(Calendar.HOUR_OF_DAY));
		String minute = String.format("%02d",calendario.get(Calendar.MINUTE));
		String second = String.format("%02d",calendario.get(Calendar.SECOND));
		return hour + ":" + minute + ":" + second;
	}

}
