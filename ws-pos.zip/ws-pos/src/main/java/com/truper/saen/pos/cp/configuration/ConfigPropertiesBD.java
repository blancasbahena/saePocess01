package com.truper.saen.pos.cp.configuration;

import java.io.Serializable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "spring.datasource.tel")
@Validated
@Getter
@Setter
public class ConfigPropertiesBD implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -6090237390165638919L;
	private String jdbcUrl;
	private String username;
	private String password;
	private String driver_class_name;
}