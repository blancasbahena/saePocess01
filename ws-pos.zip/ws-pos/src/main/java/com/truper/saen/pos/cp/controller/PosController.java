package com.truper.saen.pos.cp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.pos.cp.dto.PosDTO;
import com.truper.saen.pos.cp.entities.ImportacionesDetalleOrden;
import com.truper.saen.pos.cp.enums.Mensajes;
import com.truper.saen.pos.cp.response.vo.ResponseVO;
import com.truper.saen.pos.cp.service.IPosService;
import com.truper.saen.pos.cp.util.UtilDates;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/pos")
@Api("Servicio para obtener las POs")
@CrossOrigin(value = { "*" }, exposedHeaders = { "Content-Disposition" })
public class PosController {

	@Autowired
	private IPosService iPosService;

	@PostMapping
	@ApiOperation(value = "Servicio para obtener las POs de la BD de Tel", notes = "Obtiene las POs de la BD de TEL")
	public ResponseEntity<ResponseVO> obtenerPosCp(@Valid @RequestBody PosDTO posDTO, Errors error) {

		log.info("[POST /obtenerPosCp] | INICIO -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());

		String folio = UUID.randomUUID().toString();

		try {

			if (error.hasErrors()) {
				throw new Exception(error.toString());
			}

			List<ImportacionesDetalleOrden> response = iPosService.obtenerPosConCP(posDTO);
			
			Map<String, Object> formData = new HashMap<>();
			formData.put("pos", response);

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folio).data(formData).build());

		} catch (Exception e) {
			log.error("Error en el servicio obtenerPosCp {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), posDTO.toString(), folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage()).folio(folio).build(),
					HttpStatus.BAD_REQUEST);

		} finally {
			log.info("[POST /obtenerPosCp] | FIN -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());
		}

	}

	@PostMapping(path = "/getNumOrdenByItem/", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Servicio para obtener las numeros de la BD de Tel", notes = "Obtiene los numeros de orden por item de la BD de TEL")
	public ResponseEntity<ResponseVO> getNumOrdenByItem(@RequestBody long item) {
		String folio = UUID.randomUUID().toString();
		try {
			List<Long> response = iPosService.getNumOrdenByItem(item);

			Map<String, Object> formData = new HashMap<>();
			formData.put("ordenes", response);

			return ResponseEntity.ok(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
					.mensaje(Mensajes.MSG_EXITO.getMensaje()).folio(folio).data(formData).build());

		} catch (Exception e) {
			log.error("Error en el servicio obtenerPosCp {} a las {} con parametros {} y folio {}", e.getMessage(),
					UtilDates.getHora(), item, folio);

			return new ResponseEntity<>(ResponseVO.builder().tipoMensaje(Mensajes.TIPO_ERROR.getMensaje())
					.mensaje(Mensajes.MSG_ERROR.getMensaje()).descripcionError(e.getMessage()).folio(folio).build(),
					HttpStatus.BAD_REQUEST);

		} finally {
			log.info("[POST /obtenerPosCp] | FIN -  {} - HORA - {} ", item, UtilDates.getHora());
		}

	}

}
