package com.truper.saen.pos.cp.service;

import java.util.List;

import com.truper.saen.pos.cp.dto.PosDTO;
import com.truper.saen.pos.cp.entities.ImportacionesDetalleOrden;

public interface IPosService {
	
	List<ImportacionesDetalleOrden> obtenerPosConCP(PosDTO posDTO) throws Exception;
	
	List<Long> getNumOrdenByItem(long item) throws Exception;
	
}
