package com.truper.saen.pos.cp.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class PersistenceConfig {
	
	@Autowired
	private ConfigPropertiesBD configPropertiesBD;

	@Bean
	public DataSource mysqlDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(configPropertiesBD.getDriver_class_name());
		dataSource.setUrl(configPropertiesBD.getJdbcUrl());
		dataSource.setUsername(configPropertiesBD.getUsername());
		dataSource.setPassword(configPropertiesBD.getPassword());

		return dataSource;
	}

	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}
}