package com.truper.saen.pos.cp.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.truper.saen.pos.cp.dto.PosDTO;
import com.truper.saen.pos.cp.entities.ImportacionesDetalleOrden;
import com.truper.saen.pos.cp.service.IPosService;
import com.truper.saen.pos.cp.util.UtilDates;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PosServiceimpl implements IPosService {
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public List<ImportacionesDetalleOrden> obtenerPosConCP(PosDTO posDTO) throws Exception {
		
		log.info("[Service /obtenerPosConCP] | INICIO -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());

		MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
		mapSqlParameterSource.addValue("esLiberada", posDTO.getEsLiberada());
		mapSqlParameterSource.addValue("ordenCerrada", posDTO.getOrdenCerrada());
		mapSqlParameterSource.addValue("claveProveedor", posDTO.getClaveProveedor());
		mapSqlParameterSource.addValue("fechaInicio", obtenerFechaCreacion(posDTO.getFechaInicio()));
		mapSqlParameterSource.addValue("fechaFin", obtenerFechaCreacion(posDTO.getFechaFin()));
		
		try {

			List<ImportacionesDetalleOrden> objeto = namedParameterJdbcTemplate.query(
					"select ido.condicionPago, ido.numeroOrden, ido.posicion, ido.material as item, ido.cantidad as poTotalQuantity, ido.planeador,\r\n"
							+ "ido.centro, ido.numOrdenSecundaria, ido.cantidadUnidadMedida, ido.factorCantidadUnidadMedida,\r\n"
							+ "ido.descripcionComplementoFactura as itemDescription, p.origen, case when p.origen = 'I' then 'ZCOM' when p.origen = 'M' then 'ZMP' end as tipo, p.codigo, p.descripcion, p.planeador as planeadorProducto, p.familia, \r\n"
							+ "p.familia, p.masterCart, p.volumenCart, p.volumenMaster, p.pesoCart, p.pesoMaster, in2.fecha as shippingDate, ido.unidadMedida as unidadMedidaProducto, ido.fechaProforma as fechaProforma \r\n"
							+ "from ImportacionesNotificaciones in2 left join ImportacionesDetalleOrden ido on ido.numeroOrden = in2.numeroOrden and in2.posicion = ido.posicion \r\n"
							+ "inner join productos p on ido.material = p.codigo \r\n"
							+ "where in2.estado = 1 and ido.esLiberada = :esLiberada and ido.ordenCerrada = :ordenCerrada and ido.proformaSAP is not NULL and ido.proformaSAP > 0 \r\n"
							+ "and in2.fecha = (select MAX(fecha) from ImportacionesNotificaciones as algo where algo.numeroOrden = in2.numeroOrden and algo.posicion = in2.posicion) \r\n"
							+ "and ido.claveProveedor = :claveProveedor and (in2.fecha >= :fechaInicio and in2.fecha <= :fechaFin) order by in2.numeroOrden, in2.posicion",
					mapSqlParameterSource,
					(rs, rowNum) -> new ImportacionesDetalleOrden(rs.getString("condicionPago"),
							rs.getString("numeroOrden") != null ? rs.getString("numeroOrden").trim() : rs.getString("numeroOrden"), 
							rs.getString("posicion") != null ? rs.getString("posicion").trim() : rs.getString("posicion"),
							rs.getString("item") != null ? rs.getString("item").trim() : rs.getString("item"), 
							rs.getDouble("poTotalQuantity"), rs.getString("planeador"),
							rs.getString("centro") != null ? rs.getString("centro").trim() : rs.getString("centro"), 
							rs.getString("numOrdenSecundaria") != null ? rs.getString("numOrdenSecundaria").trim() : rs.getString("numOrdenSecundaria"),
							rs.getDouble("cantidadUnidadMedida"), rs.getDouble("factorCantidadUnidadMedida"),
							rs.getString("itemDescription") != null ? rs.getString("itemDescription").trim() : rs.getString("itemDescription"),
							rs.getString("origen"), 
							rs.getString("tipo") != null ? rs.getString("tipo").trim() : rs.getString("tipo"),
							rs.getString("codigo") != null ? rs.getString("codigo").trim() : rs.getString("codigo"), 
							rs.getString("descripcion") != null ? rs.getString("descripcion").trim() : rs.getString("descripcion"), 
							rs.getString("planeadorProducto") != null ? rs.getString("planeadorProducto").trim() : rs.getString("planeadorProducto"), 
							rs.getString("familia") != null ? rs.getString("familia").trim() : rs.getString("familia"), 
							rs.getInt("masterCart"), rs.getDouble("volumenCart"), rs.getDouble("volumenMaster"), 
							rs.getDouble("pesoCart"), rs.getDouble("pesoMaster"), rs.getString("shippingDate"),
							rs.getString("unidadMedidaProducto"),rs.getString("fechaProforma")));
			
			calcularPesoVolumen(objeto);
			return objeto;
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			log.info("[Service /obtenerPosConCP] | FIN -  {} - HORA - {} ", posDTO.toString(), UtilDates.getHora());
		}
	}
	
	@Override
	public List<Long> getNumOrdenByItem(long item) throws Exception{
		log.info("[Service /getNumOrdenByItem] | INICIO -  {} - HORA - {} ", item, UtilDates.getHora());
		List<Long> numerosOrdenes = new ArrayList<Long>();
		MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
		mapSqlParameterSource.addValue("item", item);
		
		try {

			List<Object> objeto = namedParameterJdbcTemplate.query(
					"select\r\n" + 
					"	ido.numeroOrden\r\n" + 
					"from\r\n" + 
					"	ImportacionesNotificaciones in2\r\n" + 
					"left join ImportacionesDetalleOrden ido on\r\n" + 
					"	ido.numeroOrden = in2.numeroOrden\r\n" + 
					"	and in2.posicion = ido.posicion\r\n" + 
					"inner join productos p on\r\n" + 
					"	ido.material = p.codigo\r\n" + 
					"where ido.material =:item",
					mapSqlParameterSource,
					(rs, rowNum) -> numerosOrdenes.add(rs.getLong("numeroOrden") != 0 ? rs.getLong("numeroOrden"): 0)
						);
			return numerosOrdenes;
			
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			log.info("[Service /obtenerPosConCP] | FIN -  {} - HORA - {} ", item, UtilDates.getHora());
		}
	}
	
	private List<ImportacionesDetalleOrden> calcularPesoVolumen(List<ImportacionesDetalleOrden> importacionesDetalleOrden) {
		
		for(ImportacionesDetalleOrden poDetalleDto : importacionesDetalleOrden) {
			
			double volPedido = 0; 
			double pesoPedido = 0;	
			
			if (poDetalleDto.getMasterCart() != 0 && poDetalleDto.getPoTotalQuantity() >= poDetalleDto.getMasterCart()) {
				if(poDetalleDto.getVolumenMaster() > 0) {
					double numMasters = poDetalleDto.getPoTotalQuantity() / poDetalleDto.getMasterCart();
					volPedido += poDetalleDto.getVolumenMaster() * numMasters;
				}else {
					double piezasSueltas = poDetalleDto.getPoTotalQuantity() / poDetalleDto.getMasterCart();
					volPedido += poDetalleDto.getVolumenCart() * piezasSueltas ;
				}
			} else {
				volPedido = poDetalleDto.getVolumenCart() * poDetalleDto.getPoTotalQuantity();
			}
			
			BigDecimal bd = new BigDecimal(volPedido /1000000.00).setScale(2, RoundingMode.HALF_UP);
			poDetalleDto.setVolumenCalculado( bd.doubleValue());
			

			if (poDetalleDto.getMasterCart() != 0 && poDetalleDto.getPoTotalQuantity() >= poDetalleDto.getMasterCart()) {
				if(poDetalleDto.getPesoMaster()> 0) {
					double numMasters = poDetalleDto.getPoTotalQuantity() / poDetalleDto.getMasterCart();
					pesoPedido += poDetalleDto.getPesoMaster() * numMasters;
				}else {
					double piezasSueltas = poDetalleDto.getPoTotalQuantity() / poDetalleDto.getMasterCart();
					pesoPedido += poDetalleDto.getPesoCart() * piezasSueltas;
				}			
				
			} else {
				pesoPedido += poDetalleDto.getPesoCart() * poDetalleDto.getPoTotalQuantity();
			}
			
			bd = new BigDecimal(pesoPedido).setScale(2, RoundingMode.HALF_UP);
			poDetalleDto.setPesoCalculado( bd.doubleValue() );

		}
		return importacionesDetalleOrden;
		
	}

	private static String obtenerFechaCreacion(Date fechaParametro) {
		
		String pattern = "yyyyMMdd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String fecha = simpleDateFormat.format(fechaParametro);
		return fecha;
	}
}
