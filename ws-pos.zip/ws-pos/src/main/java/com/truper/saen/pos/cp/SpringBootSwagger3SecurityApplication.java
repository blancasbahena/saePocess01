package com.truper.saen.pos.cp;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSwagger3SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSwagger3SecurityApplication.class, args);
//		UserDetailsServices service = new UserDetailsServices();
//		UserDetails principal_2 = service.loadUserByUsername("example");
//		JWUtil jwutil = new JWUtil();
//		System.out.println("token :: " + jwutil.generaToken(principal_2));
		
	}

}