package com.truper.saen.pos.cp.controller;

import javax.servlet.ServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.truper.saen.pos.cp.enums.Mensajes;
import com.truper.saen.pos.cp.response.vo.ResponseTokenVO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;

@Controller
@RequestMapping("/test")
public class TestSecurityController {
	@RequestMapping(value = "/request", method = RequestMethod.GET)
	@ApiOperation(value = "Url de prueba validacion de token", authorizations = @Authorization(value = "Bearer"))
	public ResponseEntity<ResponseTokenVO> decipherToken(ServletRequest request) 
	{

		return ResponseEntity.ok(ResponseTokenVO.builder()
				.tipoMensaje(Mensajes.TIPO_EXITO.getMensaje())
				.mensaje(Mensajes.MSG_TOKEN_EXITO.getMensaje())
				.build());	
	}
}
