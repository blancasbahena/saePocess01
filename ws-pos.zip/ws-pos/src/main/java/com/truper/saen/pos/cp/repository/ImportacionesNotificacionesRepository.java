package com.truper.saen.pos.cp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.truper.saen.pos.cp.entities.ImportacionesNotificaciones;

@Repository
public interface ImportacionesNotificacionesRepository extends CrudRepository<ImportacionesNotificaciones, Integer> {

}
