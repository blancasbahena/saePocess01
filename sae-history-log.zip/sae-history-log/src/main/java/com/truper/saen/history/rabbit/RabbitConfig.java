package com.truper.saen.history.rabbit;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@EnableRabbit
@Configuration
public class RabbitConfig {

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private Integer port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.exchange}")
	private String EXCHANGE_NAME;

	@Value("${spring.rabbitmq.virtual-host}")
	private String vhost;

	@Value("${spring.rabbitmq.durable}")
	private Boolean IS_DURABLE;

	@Value("${spring.rabbitmq.exclusive}")
	private Boolean exclusive;

	@Value("${spring.rabbitmq.autoDelete}")
	private Boolean autoDelete;

	@Value("${spring.rabbitmq.queueHistory}")
	private String QUEUE_NAME;

	@Value("${spring.rabbitmq.rKeyHistory}")
	private String ROUTING_KEY;

	
	@Bean
    Queue queue() {
		return new Queue(QUEUE_NAME, IS_DURABLE, exclusive, autoDelete);
    }
	
	@Bean
	DirectExchange exchange() {
		return new DirectExchange(EXCHANGE_NAME, IS_DURABLE, autoDelete);
    }
	
	@Bean
	  public Binding binding(Queue queue, DirectExchange exchange) {
	    return BindingBuilder.bind(queue).to(exchange).with(ROUTING_KEY);
	  }
	
	@Bean
	  public MessageConverter jsonMessageConverter() {
	    ObjectMapper objectMapper = new ObjectMapper();
	    return new Jackson2JsonMessageConverter(objectMapper);
	  }
	
	
	@Bean
	public SimpleRabbitListenerContainerFactory customRabbitListenerContainerFactory() throws Exception {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory());
		factory.setMessageConverter(jsonMessageConverter());
		return factory;
	}
	
	
    @Bean
    Receiver receiver() {
        return new Receiver();
    }
 
    @Bean
    MessageListenerAdapter listenerAdapter(Receiver receiver) {
        return new MessageListenerAdapter(receiver, Receiver.RECEIVE_METHOD_NAME);
    }
    
	@Bean
	public ConnectionFactory connectionFactory() {
		final CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
		connectionFactory.setVirtualHost(vhost);
	    connectionFactory.setHost(host);
	    connectionFactory.setPort(port);
	    connectionFactory.setUsername(username);
	    connectionFactory.setPassword(password);
		return connectionFactory;
	}
	@Bean
	  public AmqpAdmin amqpAdmin() {
	    return new RabbitAdmin(connectionFactory());
	  }
}
