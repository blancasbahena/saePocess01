package com.truper.saen.history.service;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RabbitServiceSender {

	@Autowired
	private RabbitTemplate   rabbitTemplate;
	
	@Value("${spring.rabbitmq.queueHistory}")
	private String queueHistory;
	
	@Value("${spring.rabbitmq.rKeyHistory}")
	private String ROUTING_KEY;
	
	@Value("${spring.rabbitmq.exchange}")
	private String EXCHANGE_NAME;
	
	
	public void enviarMensaje( String mensaje ) {

		rabbitTemplate.convertAndSend(EXCHANGE_NAME, ROUTING_KEY, mensaje);
	    
	}
	
}
