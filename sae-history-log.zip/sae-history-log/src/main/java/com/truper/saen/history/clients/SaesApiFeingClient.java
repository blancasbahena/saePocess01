package com.truper.saen.history.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.truper.saen.commons.dto.ResponseVO;

@FeignClient(contextId = "saeApi", name = "${sae.api.service-id}", path = "${sae.api.path}" )
public interface SaesApiFeingClient {
	
	@GetMapping( value = "${sae.api.getSae}", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<ResponseVO> getSaeById(@RequestHeader("Authorization") String token, @PathVariable Long idSae);

}
