package com.truper.saen.history.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.truper.saen.commons.dto.ResponseMessage;
import com.truper.saen.commons.entities.HistoryLog;
import com.truper.saen.history.common.Respuesta;
import com.truper.saen.history.dao.HistoryLogDao;
import com.truper.saen.history.dto.HistoryDTO;
import com.truper.saen.history.service.HistoryLogService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class HistoryLogServiceImpl implements HistoryLogService{

	@Autowired
	private HistoryLogDao historyLogDao;
	
	
	@Override
	public Respuesta getHistoryLogByIdSae(Long idSae) {
		Respuesta resp = new Respuesta(); 
		
		List<HistoryLog> history = historyLogDao.findByIdSaeOrderByIdLogDesc(idSae);
		
		if( !history.isEmpty() ) {
			
			List<HistoryDTO> historyDto = this.HistoryLogToHistoryDTO(history);
			
			resp = new Respuesta(ResponseMessage.TIPO_EXITO.getMensaje(), ResponseMessage.MSG_EXITO.getMensaje(), "history", historyDto);
			resp.setEstado(HttpStatus.OK);
		}else {
			resp.setTipoMensaje(ResponseMessage.TIPO_WARNING.getMensaje());
			resp.setMensaje(ResponseMessage.MSG_WARNING.getMensaje());
			resp.setEstado(HttpStatus.NOT_FOUND);
		}
		
		return resp;
	}

	@Override
	public Respuesta getHistoryLogByIdPO(String PO) {
		
		return null;
	}

	
	private List<HistoryDTO> HistoryLogToHistoryDTO( List<HistoryLog> historyList){
		List<HistoryDTO> historyDTO = new ArrayList<>();
		
		for (HistoryLog history : historyList) {
			
			HistoryDTO hiDto = new HistoryDTO();
			
			hiDto.setIdLog(history.getIdLog());
			hiDto.setIdSae(history.getIdSae());
			hiDto.setAccion(history.getAccion().getAccion());
			hiDto.setEstatus(history.getEstatus());
			hiDto.setProveedor(history.getProveedor());
			hiDto.setNombreProveedor(history.getNombreProveedor());
			hiDto.setTipoSae(history.getTipoSae());
			hiDto.setUserName(history.getUserName());
			hiDto.setEta(history.getEta());
			hiDto.setTipoUnidad(history.getTipoUnidad());
			hiDto.setConfirmador(history.getConfirmador());
			hiDto.setCreateDate(history.getCreateDate());
			hiDto.setComentarios(history.getComentarios());
			hiDto.setUnidades(history.getUnidades());
			hiDto.setMonto(history.getMonto());
			hiDto.setTotalCodigos(history.getTotalCodigos());
			hiDto.setCentro(history.getCentro());
			historyDTO.add(hiDto);
			
		}
		
		return historyDTO;
	}
	
}
