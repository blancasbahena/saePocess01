package com.truper.saen.history.rabbit;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;


import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RabbitMQConsumer {


	@RabbitListener(queues = "${spring.rabbitmq.queueHistory}")
	public void recievedMessage(byte [] responseMQ) throws IOException, InterruptedException, ExecutionException {
		String responseString = new String(responseMQ);
		
		log.info("Recieved Message From RabbitMQ: " + responseString);

	}
}
