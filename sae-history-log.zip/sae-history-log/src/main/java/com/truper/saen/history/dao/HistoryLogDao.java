package com.truper.saen.history.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truper.saen.commons.entities.HistoryLog;

public interface HistoryLogDao extends JpaRepository<HistoryLog, Long>{

	List<HistoryLog> findByIdSaeOrderByCreateDateDesc(Long idSae);
	
	List<HistoryLog> findByIdSaeOrderByIdLogDesc(Long idSae);
	
}
