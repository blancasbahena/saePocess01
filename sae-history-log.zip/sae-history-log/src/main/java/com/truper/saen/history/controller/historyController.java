package com.truper.saen.history.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.HistoryDto;
import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.history.common.Respuesta;
import com.truper.saen.history.configuration.JWUtil;
import com.truper.saen.history.service.HistoryLogService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/history-log")
public class historyController {

	@Autowired
	private HistoryLogService historyService;
	
	@ApiOperation(value = "Recupera el historico por ID del Sae",
			response = Respuesta.class,
			notes = "Regresa un arreglo de historico guardado para el folio consultado")
	@ApiResponses( value = {
			@ApiResponse(code = 200, message = "Consulta exitosa",response = Respuesta.class),
			@ApiResponse(code = 404, message = "No se encontraron registros para el Folio consultado")
	})
	@GetMapping(value = "/{idSae}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> getHistoryByIdSae(@RequestHeader("Authorization") String token, @PathVariable Long idSae  ){
		log.info("[GET /history-log/{}] | INICIO -  {} ",idSae,JWUtil.extractUsername(token.substring(7)));
	
		Respuesta respuesta = historyService.getHistoryLogByIdSae(idSae);
		
		log.info("[GET /history-log/{}] | FIN",idSae);
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
		
	}
	
	
	@GetMapping(value = "/PO/{idPO}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> getHistoryByPO(@RequestHeader("Authorization") String token, @PathVariable String idPO ){
		log.info("[GET /history-log/PO/{}] | INICIO -  {} ",idPO,JWUtil.extractUsername(token.substring(7)));
		Respuesta respuesta = new Respuesta();
		respuesta.setEstado(HttpStatus.OK);
		
		log.info("[GET /history-log/PO/{}] | FIN",idPO);
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
		
	}
	
}
