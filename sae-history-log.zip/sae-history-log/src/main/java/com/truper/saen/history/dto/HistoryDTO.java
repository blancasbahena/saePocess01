package com.truper.saen.history.dto;

import java.util.Date;

import lombok.Data;

@Data
public class HistoryDTO {

	private Long idLog;
	private Long idSae;
	private String accion;
	private String estatus;
	private String proveedor;
	private String nombreProveedor;
	private String tipoSae;
	private String userName;
	private Date eta;
	private String tipoUnidad;
	private String confirmador;
	private Date createDate;
	private String comentarios;
	private Integer unidades;
	private Double monto;
	private Integer totalCodigos;
	private String centro;
	
}
