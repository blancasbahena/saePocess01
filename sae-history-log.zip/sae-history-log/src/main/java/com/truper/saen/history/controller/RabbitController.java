package com.truper.saen.history.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truper.saen.commons.dto.ResponseVO;
import com.truper.saen.history.common.Respuesta;
import com.truper.saen.history.configuration.JWUtil;
import com.truper.saen.history.service.RabbitServiceSender;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/rabbit")
public class RabbitController {

	@Autowired
	private RabbitServiceSender rabbitSender;
	
	@PutMapping(value = "/send", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> setHistoryLogById(@RequestHeader("Authorization") String token, @RequestBody String mensaje ){
		log.info("[PUT /send] | INICIO -  {}",JWUtil.extractUsername(token.substring(7)));
		
		Respuesta respuesta = new Respuesta();
		rabbitSender.enviarMensaje(mensaje);
		
		respuesta.setEstado(HttpStatus.OK);
		
		log.info("[PUT /send | FIN");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	
}
