package com.truper.saen.history.service;

import com.truper.saen.commons.dto.HistoryDto;
import com.truper.saen.history.common.Respuesta;

public interface HistoryLogService {

	Respuesta getHistoryLogByIdSae(Long idSae);
	
	Respuesta getHistoryLogByIdPO(String PO);
	
}
