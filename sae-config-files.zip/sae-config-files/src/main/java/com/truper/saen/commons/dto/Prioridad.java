package com.truper.saen.commons.dto;

import java.io.Serializable;

import lombok.Data;

@Data 
public class Prioridad implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer idPrioridad;
	private String descripcion;
	private String color;

}
