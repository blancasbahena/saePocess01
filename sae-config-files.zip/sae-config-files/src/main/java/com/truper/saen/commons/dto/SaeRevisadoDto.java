package com.truper.saen.commons.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SaeRevisadoDto implements Serializable {

	private static final long serialVersionUID = 857104511648450435L;

	private Long folio;
	
	private Date eta;
	
	private Date etaSolicitada;
	
	private Integer unidades;
	
	private CatTipoDeUnidadDTO tipoDeUnidad;
	
	private Date created;
	
	private UserDTO userCreated; 
	
	private String tipo;
	
	private Integer idProveedor;
	
	private List<SaeDetalleRevisadoDto> saeDetalles;
	
}
