package com.truper.saen.commons.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "mensajes_emails")
public class MensajesEmails {
	
	@Id
	@Column(name = "id_actividad")
	private Integer idActividad;
	
	@Column(name = "subject_email")
	private String subjectEmail;

	@Column(name = "cc")
	private String cc;
	
	@Column(name = "plantilla")
	private String plantilla;
	
}
