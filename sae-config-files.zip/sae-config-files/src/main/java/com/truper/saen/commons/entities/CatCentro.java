package com.truper.saen.commons.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "catCentros")
public class CatCentro {

	@Id
	@Column(name = "idCentro",length = 3)
	private String idCentro;
	
	@Column(name = "descripcion", length = 15)
	private String descripcion;

	@Column(name = "tipo", length = 1)
	private String tipo;
	
	@JsonIgnore
	@Column(name = "activo")
	private Boolean activo;
}
