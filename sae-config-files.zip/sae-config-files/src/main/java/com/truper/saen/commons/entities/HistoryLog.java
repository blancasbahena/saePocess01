package com.truper.saen.commons.entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "historyLogSae")
public class HistoryLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idLog")
	private Long idLog;
	
	@Column(name = "idSae")
	private Long idSae;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "idAccion",referencedColumnName = "idAccion")
	private CatAcciones accion;
	
	@Column(name = "estatus", length = 30)
	private String estatus;
	
	@Column(name = "proveedor", length = 100)
	private String proveedor;
	
	@Column(name = "nombreProveedor", length = 80)
	private String nombreProveedor;
	
	@Column(name = "tipoSae", length = 1)
	private String tipoSae;
	
	@Column(name = "userName", length = 20)
	private String userName;
	
	@Column(name = "eta")
	private Date eta;
	
	@Column(name = "tipoUnidad", length = 10)
	private String tipoUnidad;
	
	@Column(name = "confirmador", length = 20)
	private String confirmador;
	
	@Column(name = "createDate")
	private Date createDate;
	
	@Column(name = "comentarios")
	private String comentarios;
	
	@Column(name = "unidades")
	private Integer unidades;
	
	@Column(name = "monto")
	private Double monto;
	
	@Column(name = "totalCodigos")
	private Integer totalCodigos;
	
	@Column(name = "centro")
	private String centro;
}
