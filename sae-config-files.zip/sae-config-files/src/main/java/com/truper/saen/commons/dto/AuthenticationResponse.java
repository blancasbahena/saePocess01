package com.truper.saen.commons.dto;

import java.io.Serializable;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor 
public class AuthenticationResponse  implements Serializable{
	private final String jwt;
	private String folio;
	
	public static String getFolioActual() {
		return  UUID.randomUUID().toString();
	}
}
