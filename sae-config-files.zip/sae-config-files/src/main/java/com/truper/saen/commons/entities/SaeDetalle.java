package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "SaeDetalle")
public class SaeDetalle implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SaeDetalleId idDetalle;
	
	@Column(name = "condicionPago")
	private String condicionPago;
	
	@Column(name = "numOrdenSecundaria")
	private String numOrdenSecundaria;
	
	@Column(name = "cantidadUnidadMedida")
	private Double cantidadUnidadMedida;
	
	@Column(name = "factorCantidadUnidadMedida")
	private Double factorCantidadUnidadMedida;
	
	@Column(name = "descripcionComplementoFactura")
	private String descripcionComplementoFactura;
	
	@Column(name = "origen")
	private String origen;
	
	@Column(name = "tipo")
	private String tipo;
	
	@Column(name = "codigo")
	private String codigo;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "planeadorProducto")
	private String planeadorProducto;
	
	@Column(name = "familia")
	private String familia;
	
	@Column(name = "planner")
	private String planner;
	
	@Column(name = "cantidad")
	private Double cantidad;
	
	@Column(name = "centro")
	private String centro;
	
	@Column(name = "picoPlan")
	private Integer picoPlan;
	
	@Column(name = "picoReal")
	private Integer picoReal;
	
	@Column(name = "monto")
	private Double monto;
	
	@Column(name = "fechaPI")
	private Date fechaPI;
	
	@Column(name = "difPIEvsETA")
	private Short difPIEvsETA;

	@Column(name = "material")
	private String material;
	
	@Column(name = "peso")
	private Double peso;
	
	@Column(name = "volumen")
	private Double volumen;
	
	@JsonIgnore
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "idSae", insertable = false, updatable = false)
	private Sae sae;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "prioridadDetalle", referencedColumnName = "idPrioridad")
	private CatPrioridades prioridades;
	
	@Column(name = "BO")
	private Double bo;
	
	@Column(name = "OS")
	private Double os;
	
	@Column(name = "SS")
	private Double ss;
	
	@Column(name = "IDAMin")
	private Integer idaMin;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fechaEntrega")
	private Date fechaEntrega;
	
	@Column(name = "unidadMedidaProducto")
	private String unidadMedidaProducto;
	
	@Column(name = "diasConsumoDisponible")
	private Integer diasConsumoDisponible;
	
	//?
	//private String BO;
	//?
	//private String IDA;
	//?
	//private String OS;
}
