package com.truper.saen.commons.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class ListProductosDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4711040654834205914L;
	private List<String> listaProductos;
	
}
