package com.truper.saen.commons.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TokenDTO  implements Serializable{
	private static final long serialVersionUID = 1391418548784412659L;
	private Long id;
	private String name;
	private String email;
	private List<TokenRoleDTO> roles;
	private List<TokenPermisoDTO> permisos;
	
}
