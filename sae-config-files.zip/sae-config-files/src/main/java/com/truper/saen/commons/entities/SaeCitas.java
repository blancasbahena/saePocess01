package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "sae_citas")
@Data
@NoArgsConstructor
public class SaeCitas implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    
    @Basic(optional = false)
    @Column(name = "fecha_cita")
    @Temporal(TemporalType.DATE)
    private Date fechaCita;
    
    @Column(name = "fecha_confirmacion")
    @Temporal(TemporalType.DATE)
    private Date fechaConfirmacion;
    
    @Column(name = "confirmada")
    private Boolean confirmada;
    
    @JoinColumn(name = "id_status", referencedColumnName = "id_status")
    @ManyToOne(optional = false)
    private CatStatusCita idStatus;

    
    @JoinColumn(name = "id_sae", referencedColumnName = "folio")
    @ManyToOne(optional = false)
    private Sae idSae;
    
    @JoinColumn(name = "user_confirma", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private User userConfirma;
    
    @Column(name = "fechaReprogramada")
    @Temporal(TemporalType.DATE)
    private Date fechaReprogramada;

}
