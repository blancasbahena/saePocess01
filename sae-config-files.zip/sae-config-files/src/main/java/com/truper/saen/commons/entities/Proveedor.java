package com.truper.saen.commons.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="ext_supplier")
@Getter
@Setter
public class Proveedor implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3015322913564208039L;

	@Id
	@Column(name = "claveProveedor", length = 6)
	private String claveProveedor;

	@Column(name = "nombre",length = 80)
	private String nombre;
	
	@Column(name ="email", length = 132)
	private String email;

	@Column(name = "contacto", length = 15)
	private String contacto;
	
	@Column(name = "RFC", length = 30)
	private String RFC;
	
	@Column(name = "bloqueado")
	private Boolean bloqueado;
	
}
