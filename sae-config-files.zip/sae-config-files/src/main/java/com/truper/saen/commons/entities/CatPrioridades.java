package com.truper.saen.commons.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "catPrioridades")
public class CatPrioridades {

	@Id
	@Column(name = "idPrioridad")
	private Integer idPrioridad;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "rangoMin")
	private Integer rangMin;
	
	@Column(name = "rangoMax")
	private Integer rangoMax;
	
	@Column(name = "color")
	private String color;
	
	@Column(name = "tipo")
	private String tipo;
	
}
