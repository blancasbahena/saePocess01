package com.truper.saen.commons.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class SaeDetalleRevisadoId implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9114728820970336468L;

	@Column(name = "idSae")
	private Long idSae;
	
	@Column(name = "idPO")
	private String idPO;
	
	@Column(name = "idPosicion")
	private Integer idPosicion;
	
}
