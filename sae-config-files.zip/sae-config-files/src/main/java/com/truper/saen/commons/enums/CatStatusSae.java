package com.truper.saen.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CatStatusSae {
	SAE_CREADO(1,"SAE Creado"),
	SAE_CANCELADO(3,"SAE Cancelado"),
	SAE_RECHAZA_PLANEACION(5,"SAE se rechaza planeacion zcom/zmp"),
	SAE_ENVIADO_PARA_APROBACION(10,"SAE Enviado para Aprobación"),
	SAE_APRUEBA_CANCEL_PLANEACION(43,"SAE se aprueba en planeacion can zcom/zmp"),
	SAE_ENVIADO_A_REVISION(14,"SAE enviado a Revisión"),
	SAE_APRUEBA_PLANEACION(20,"SAE se aprueba planeacion zcom/zmp"),
	SAE_ENVIADO_PARA_RECHAZO_GTE_APROBACION(10,"SAE Enviado para Aprobación"),  //<--- Cambiar valor
	SAE_RECHAZA_GTE_PLANEACION(10,"SAE se rechaza gerente planeacion"),
	
	SAE_APRUEBA_GTE_PLANEACION(30,"SAE se aprueba gte planeacion zcom/zmp"),
	
	SAE_RECHAZA_OVER_STOCK_STATUS25(25,"SAE se rechaza desde overStock"),		//<--- Cambiar valor ?
	SAE_RECHAZA_OVER_STOCK_STATUS26(26,"SAE se rechaza desde overStock"),
	
	SAE_RECHAZADO_LIBERACION(35,"SAE Rechazado en Liberación"),
	SAE_RECHAZADO_REVISADOS(36,"SAE Rechazado en Revisados"),
    SAE_CANCELADO_LIBERACION(42,"SAE Cancelado en Liberación"),
	SAE_APRUEBA_OVER_STOCK(40,"SAE se aprueba over stock zcom/zmp"),
	SAE_APROBADO_LIBERACION(50,"SAE Aprobado en Liberación"),
	SAE_CON_CITA_REPROGRAMADA(52,"SAE con Cita Reprogramada"),
	SAE_CON_CITA_CANCELADA(55,"SAE con Cita Cancelada"),
	SAE_CON_CITA_CONFIRMADA(60,"SAE con Cita Confirmada"),
	SAE_ENTREGADO(70,"SAE Entregado"),
	SAE_NOENTREGADO(71,"SAE Entregado");


	
	private int id;
	private String status;
}
