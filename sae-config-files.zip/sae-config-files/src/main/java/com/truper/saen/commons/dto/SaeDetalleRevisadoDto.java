package com.truper.saen.commons.dto;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
@Data
public class SaeDetalleRevisadoDto  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private SaeDetalleIdDTO idDetalle;
	
	private String condicionPago;
	
	private String numOrdenSecundaria;
	
	private Double cantidadUnidadMedida;
	
	private Double factorCantidadUnidadMedida;
	
	private String descripcionComplementoFactura;
	
	private String origen;
	
	private String tipo;
	
	private String codigo;
	
	private String descripcion;
	
	private String planeadorProducto;
	
	private String familia;
	
	private String planner;
	
	private Double cantidad;
	
	private String centro;
	
	private Integer picoPlan;
	
	private Integer picoReal;
	
	private Double monto;
	
	private Date fechaPI;
	
	private Short difPIEvsETA;

	private String material;
	
	private Double peso;
	
	private Double volumen;

	private Boolean esNuevo;

	private Boolean esBorrado;

	private Boolean esModificado;

	private Double pesoModificado;

	private Double volumenModificado;

	private Double cantidadModificado;
	
	private Date created;
	
	private UserDTO userCreated;
	
    private Integer masterCart;

    private Double volumenCart;

    private Double pesoCart;

    private Double pesoMaster;

    private Double volumenMaster;
    
    private String accion;
	
	private Date fechaEntrega;
	
	private Integer idaMin;
	
	private Prioridad prioridad;
}
