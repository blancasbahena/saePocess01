package com.truper.saen.commons.dto;

import lombok.Data;

@Data
public class StatusDto {

	private Integer idSaeStatus;
	private String estatus;
}
