package com.truper.saen.commons.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "SaeDetalleRevisado")
public class SaeDetalleRevisado implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SaeDetalleId idDetalle;
	
	@Column(name = "condicionPago")
	private String condicionPago;
	
	@Column(name = "numOrdenSecundaria")
	private String numOrdenSecundaria;
	
	@Column(name = "cantidadUnidadMedida")
	private Double cantidadUnidadMedida;
	
	@Column(name = "factorCantidadUnidadMedida")
	private Double factorCantidadUnidadMedida;
	
	@Column(name = "descripcionComplementoFactura")
	private String descripcionComplementoFactura;
	
	@Column(name = "origen")
	private String origen;
	
	@Column(name = "tipo")
	private String tipo;
	
	@Column(name = "codigo")
	private String codigo;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "planeadorProducto")
	private String planeadorProducto;
	
	@Column(name = "familia")
	private String familia;
	
	@Column(name = "planner")
	private String planner;
	
	@Column(name = "cantidad")
	private Double cantidad;
	
	@Column(name = "centro")
	private String centro;
	
	@Column(name = "picoPlan")
	private Integer picoPlan;
	
	@Column(name = "picoReal")
	private Integer picoReal;
	
	@Column(name = "monto")
	private Double monto;
	
	@Column(name = "fechaPI")
	private Date fechaPI;
	
	@Column(name = "difPIEvsETA")
	private Short difPIEvsETA;

	@Column(name = "material")
	private String material;
	
	@Column(name = "peso")
	private Double peso;
	
	@Column(name = "volumen")
	private Double volumen;
	
	@JsonIgnore
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "idSae", insertable = false, updatable = false)
	private SaeRevisado sae;
	
	@Column(name = "BO")
	private Double bo;
	
	@Column(name = "OS")
	private Double os;
	
	@Column(name = "SS")
	private Double ss;
	
	@Column(name = "IDAMin")
	private Integer idaMin;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fechaEntrega")
	private Date fechaEntrega;
		
	@Column(name = "esNuevo")
	private Boolean esNuevo;
	
	@Column(name = "esBorrado")
	private Boolean esBorrado;
	
	@Column(name = "esModificado")
	private Boolean esModificado;
	
	@Column(name = "pesoModificado")
	private Double pesoModificado;
	
	@Column(name = "volumenModificado")
	private Double volumenModificado;
	
	@Column(name = "cantidadModificado")
	private Double cantidadModificado;
	
	@Column(name = "created")
	private Date created;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userCreated", referencedColumnName = "id")
    private User userCreated;
	
	@Column(name = "diasConsumoDisponible")
	private Integer diasConsumoDisponible;
}
