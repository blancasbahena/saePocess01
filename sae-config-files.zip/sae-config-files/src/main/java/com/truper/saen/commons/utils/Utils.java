package com.truper.saen.commons.utils;

import java.text.DecimalFormat;
import java.util.Date;

public class Utils {

	public static String calcTiempoTranscurridoEnSegundos( Date inicio, Date fin ) {
		String transcurrido = null;
		if( inicio != null && fin != null ) {
			long ttl = (fin.getTime() - inicio.getTime());
			Double tt =  (double) (ttl / 1000.0); 
			DecimalFormat formatter = new DecimalFormat("#.##s");
			transcurrido = formatter.format(tt);
		}
		
		return transcurrido;
	}
	
}
