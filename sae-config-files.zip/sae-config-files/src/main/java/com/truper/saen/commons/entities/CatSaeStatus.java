package com.truper.saen.commons.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "catSaeStatus")
public class CatSaeStatus {

	@Id
	@Column(name = "idSaeStatus")
	private Integer idSaeStatus;
	
	@Column(name = "estatus")
	private String estatus;
	
}
