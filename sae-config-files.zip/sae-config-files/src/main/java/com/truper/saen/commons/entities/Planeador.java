package com.truper.saen.commons.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "catPlaneador")
public class Planeador {

	@Id
	@Column(name = "idPlaneador")
	private Integer idPlaneador;
	
	@Column(name = "nombre")
	private String nombre;
	
}
