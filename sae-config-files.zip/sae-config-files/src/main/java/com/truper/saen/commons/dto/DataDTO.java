package com.truper.saen.commons.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DataDTO {
	private String to;
	private String folio;
	private String company;
	private String proveedor;
	private String service;
	private String pod;
	private String etd;
	private String supplier;
	private String vessel;
	private String voyage;
	private String tcontainer;
	private String comments;
	private List<Pos>  pos;
	private String volume;
	private String weight;
	private boolean debug;
	private String eta;
	private String planing;
	private String userReject;
	private String msgReject;
	private String cita;
	private String fechaCita;
	private String cc;
	private String nuevaCita;
	private String dias;
	private List<String> folios;
}
