package com.truper.saen.commons.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SaeDetalleIdDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8246413418231708447L;

	private Long idSae;
	 
	private String idPO;

	private String idPosicion;
}
